import cv2 as cv
import numpy as np
from sklearn.cluster import KMeans


def seg_thresh(img, thresh=100, maxval=255, thresh_type=cv.THRESH_OTSU, normalize=True, use_filter=True):
    """
    基于OpenCV的阈值分割进行图像分割
    @param img: 图像，灰度值应为0~255
    @param thresh: 分割阈值
    @param maxval: 对应OpenCV的参数
    @param thresh_type: 对应OpenCV的参数
    @param normalize: 是否对图像做归一化(归一化为0~255)
    @param use_filter: 对应OpenCV的参数
    @return:
    """
    if normalize:
        img = img / img.max() * 255
    img = img.astype(np.uint8)
    ret, mask = cv.threshold(img, thresh, maxval, thresh_type)
    if use_filter:
        kernel = np.ones((5, 5), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)
        kernel = np.ones((5, 5), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, kernel)
    return mask


def seg_cluster_train(img, method='kmeans', cluster_num=2):
    if len(img.shape) < 3 or img.shape[2] == 1:
        img_flat = img.reshape([-1, 1])
    else:
        img_flat = img.reshape([-1, img.shape[2]])
    model = None
    if method == 'kmeans':
        model = KMeans(n_clusters=cluster_num, random_state=0).fit(img_flat)
    return model


def seg_cluster(img, model):
    # 通过聚类分割
    if len(img.shape) < 3 or img.shape[2] == 1:
        img_flat = img.reshape([-1, 1])
    else:
        img_flat = img.reshape([-1, img.shape[2]])
    pred = model.predict(img_flat)
    img_pred = pred.reshape([img.shape[0], img.shape[1]])
    return img_pred


def split_roi(img, mask, roi_shape='mask', split_mode=cv.RETR_EXTERNAL, split_method=cv.CHAIN_APPROX_SIMPLE,
              rect_factor=0.6, roi_length=(100, 1000)):
    """
    输入图像和分割的掩膜，返回切割后的ROI。
    @param imgs: 多/高光谱数据
    @param mask: 分割的掩膜，将基于此进行轮廓提取
    @param roi_shape: roi的形状，mask表示连通轮廓，rect表示内部矩形；
    @param split_mode: findContours的参数
    @param split_method: findContours的参数
    @param rect_factor: roi选择内部矩形时的比例
    @param roi_length: 目标ROI周长范围
    @return: rois,roi列表，roi结构:[mask, boundRect(x,y,w,h)]，roi掩膜以及roi的包围矩形；
    @return: preview_img预览图像，在原图上显示出roi的信息；
    """
    preview_img = np.copy(img)
    preview_img = (preview_img / preview_img.max() * 200).astype(np.uint8)
    target_rois = []
    contours, hierarchy = cv.findContours(mask, split_mode, split_method)
    for cont in contours:
        perimeter = cv.arcLength(cont, True)
        if perimeter < roi_length[0] or perimeter > roi_length[1]:
            # 过滤过小的单位
            continue
        roi_mask = np.zeros_like(np.squeeze(img))
        bx, by, bw, bh = cv.boundingRect(cont)
        if roi_shape == 'mask':
            cv.drawContours(roi_mask, [cont], 0, (255, 255, 255), -1)
            cv.drawContours(preview_img, [cont], 0, (255, 255, 255), -1)
        elif roi_shape == 'rect':
            x, y, w, h = int(bx + bw * (1 - rect_factor) / 2), int(by + bh * (1 - rect_factor) / 2), int(
                bw * rect_factor), int(bh * rect_factor)
            roi_mask[y:y + h, x:x + w] = 255
            cv.rectangle(preview_img, (x, y), (x + w, y + h), (255, 255, 255), 3)

        target_rois.append((roi_mask.astype(bool), (bx, by, bw, bh)))
        cv.rectangle(preview_img, (bx, by), (bx + bw, by + bh), (128, 0, 0), 3)
    return target_rois, preview_img


if __name__ == '__main__':
    f = '/Users/gordon/data/chenpi/国创/data/3/3_2_20230605_175021/3_2_20230605_175021.hdr'
    import spectral
    msi = spectral.open_image(f).load()
    img = msi[:, :, 0]
    # img = (msi[:, :, 0] / 4).astype(np.uint8)
    mask = seg_thresh(img, 80, )
    cv.imshow('mask', mask)
    cv.waitKey(0)
    rois, im = split_roi(img, mask, 'mask')
    cv.imshow('preview', im)
    cv.waitKey(0)
