import cv2
import numpy as np
from skimage.feature import greycomatrix, greycoprops


def calc_texture(image, props=['contrast', 'energy']):
    """
    计算图像样本的纹理特征
    :param x: numpy.array, 图像数据,形状为[h,w]，要求是单通道的灰度图像
    :param props: [],纹理属性,可选的包括contrast、dissimilarity、homogeneity、ASM、energy、correlation
    :return:
    :result []纹理特征，大小与props一致
    """
    g = greycomatrix(image, [1], [0], levels=256)
    result = [greycoprops(g, p)[0] for p in props]
    return np.array(result)


if __name__ == '__main__':
    img = cv2.imread('../samples/chenpi/s1/cube1/png/Cwl_713.png', 0)
    print(img.shape)
    print(calc_texture(img))
