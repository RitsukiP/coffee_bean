import random
import numpy as np
import cv2 as cv

import spectral

from gx_spectral.config import code_msg
from gx_spectral.config.api_exception import ApiException
from gx_spectral.preprocess.spectrum import msc, snv


def calc_area_spectrum(spec_images, target_rois, method='mean', percent=50):
    """按照区域进行光谱特征提取
    给出多光谱图像的ROI，根据不同方法计算出光谱
    @param spec_images: 多光谱或高光谱图像
    @param target_rois: 目标ROI
    @param method: 特征计算方法，mean平均值，median中位数，percent百分数, msc多源散射校正，SNV标准正态化
    @param percent: 百分数，method为percent才生效
    @return: 提取后的光谱特征，维度与波段数相等
    """
    preview_img = spec_images[:, :, spec_images.shape[2] // 2]
    preview_img = (preview_img / preview_img.max() * 200).astype(np.uint8)
    specs = [[] for _ in range(len(target_rois))]
    for i, (roi_mask, roi_rect) in enumerate(target_rois):
        spec = specs[i]
        preview_img[roi_mask] = 255
        for k in range(spec_images.shape[2]):
            img = np.squeeze(spec_images[:, :, k])
            spec.append(_fetch_spec(img[roi_mask], method, percent))
        spec = np.array(spec)
        if method == 'msc':
            spec = np.transpose(spec, (1,0))
            specs[i] = msc(spec)
        elif method == 'snv':
            spec = np.transpose(spec, (1,0))
            specs[i] = snv(spec)
    return specs, preview_img


def _fetch_spec(pixel_specs, method, percent):
    if method == 'mean':
        return np.mean(pixel_specs)
    elif method == 'median':
        return np.median(pixel_specs)
    elif method == 'percent':
        return np.percentile(pixel_specs, percent)
    elif method in ['msc', 'snv']:
        return pixel_specs


def calc_grid_spectrum(spec_images, target_rois, method='mean', percent=50, grid_size=50):
    """按照小网格进行光谱特征提取
    给出多光谱图像的ROI，根据不同方法计算出光谱
    @param spec_images: 多光谱或高光谱图像
    @param target_rois: 目标ROI
    @param method: 特征计算方法，mean平均值，median中位数，percent百分数
    @param percent: 百分数，method为percent才生效
    @param grid_size: 网格大小
    @return: 提取后的光谱特征，维度与波段数相等
    """
    preview_img = spec_images[:, :, spec_images.shape[2] // 2]
    preview_img = (preview_img / preview_img.max() * 200).astype(np.uint8)
    specs = [[] for _ in range(len(target_rois))]
    for spec, (roi_mask, roi_rect) in zip(specs, target_rois):
        bx, by, bw, bh = roi_rect
        # cv.rectangle(preview_img, (bx, by), (bx + bw, by + bh), (255, 255, 255), 1)
        x1, y1 = bx, by
        for i in range(bh // grid_size):
            x1 = bx
            for j in range(bw // grid_size):
                sp = []
                flag = True
                mask = roi_mask[y1:y1 + grid_size, x1:x1 + grid_size]
                for k in range(spec_images.shape[2]):
                    img = np.squeeze(spec_images[:, :, k])
                    target = img[y1:y1 + grid_size, x1:x1 + grid_size][mask]
                    if len(target) == 0:
                        flag = False
                        break
                    sp.append(_fetch_spec(target, method, percent))
                if not flag:
                    x1 += grid_size
                    continue
                cv.rectangle(preview_img, (x1, y1), (x1 + grid_size, y1 + grid_size), (255, 255, 255), 1)
                spec.append(sp)
                x1 += grid_size
            y1 += grid_size
    return specs, preview_img


def calc_random_grid_spectrum(spec_images, target_rois, method='mean', spec_num=20, percent=50, grid_size=50):
    """按照随机选取的小网格进行光谱特征提取
    给出多光谱图像的ROI，根据不同方法计算出光谱
    @param spec_images: 多光谱或高光谱图像
    @param target_rois: 目标ROI
    @param spec_num: 每个目标随机选取的光谱数
    @param method: 特征计算方法，mean平均值，median中位数，percent百分数
    @param grid_size: 网格大小
    @param percent: 百分数，method为percent才生效
    @return: 提取后的光谱特征，维度与波段数相等
    """
    specs = [[] for _ in range(len(target_rois))]
    preview_img = spec_images[:, :, spec_images.shape[2] // 2]
    preview_img = (preview_img / preview_img.max() * 200).astype(np.uint8)
    for spec, (roi_mask, roi_rect) in zip(specs, target_rois):
        bx, by, bw, bh = roi_rect
        if grid_size >= bw + 20 or grid_size >= bh + 20:
            raise ApiException(code_msg.COMMON_PARAM_INVALID, '网格区域参数太大')
        cnt = 0
        # 限制最多重复的次数，防止特殊情况下死循环
        for i in range(spec_num * 50):
            rx, ry = random.randint(bx, bx + bw - grid_size), random.randint(by, by + bh - grid_size)
            sp = []
            flag = True
            mask = roi_mask[ry:ry + grid_size, rx:rx + grid_size]
            for k in range(spec_images.shape[2]):
                img = np.squeeze(spec_images[:, :, k])
                target = img[ry:ry + grid_size, rx:rx + grid_size][mask]
                if target.size == 0:
                    flag = False
                    break
                sp.append(_fetch_spec(target, method, percent))
            if not flag:
                continue
            cv.rectangle(preview_img, (rx, ry), (rx + grid_size, ry + grid_size), (255, 255, 255), 1)
            spec.append(sp)
            cnt += 1
            if cnt >= spec_num:
                break
    return specs, preview_img


if __name__ == '__main__':
    f = '/Users/gordon/data/chenpi/国创/data/3/3_2_20230605_175021/3_2_20230605_175021.hdr'
    msi = spectral.open_image(f).load()
    from gx_spectral.feature.roi import *

    img = (msi[:, :, 0] / 4).astype(np.uint8)
    mask = seg_thresh(img, 40)
    rois, im = split_roi(img, mask, 'rect')
    cv.imshow('preview1', im)
    cv.waitKey(0)
    specs, im = calc_area_spectrum(msi, rois, 'snv')
    # specs, im = calc_random_grid_spectrum(msi, rois, 'mean')
    cv.imshow('preview', im)
    cv.waitKey(0)
    print('specs:', len(specs))
    for spec in specs:
        print(np.array(spec).shape)

    # print('median:', calc_spectrum(roi_images, 'median'))
    # print('percent50:', calc_spectrum(roi_images, 'percent'))
    # print('percent70:', calc_spectrum(roi_images, 'percent', 70))
