import PIL
import matplotlib as mpl
from PIL.Image import Image
from PIL.ImageDraw import ImageDraw
from PIL.ImageFont import ImageFont
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.patches as mpatches
import numpy as np
import cv2 as cv

# 字体可能不同电脑有差异，根据自己的电脑调整，确保能显示中文
# plt.rcParams['font.sans-serif'] = ['Heiti TC']  # 步骤一（替换sans-serif字体）
plt.rcParams['font.sans-serif'] = ['SimHei']  # 步骤一（替换sans-serif字体）
plt.rcParams['axes.unicode_minus'] = False  # 步骤二（解决坐标轴负数的负号显示问题）
# plt.rcParams['font.family'] = ['Heiti TC']
plt.rcParams['font.family'] = ['SimHei']

DPI = 128


def _get_regre_colormap(labels):
    cmaps = mpl.cm.jet
    if len(np.unique(labels)) < 3:
        norm1 = mpl.colors.Normalize(vmin=np.min(labels) * 0.9, vmax=np.max(labels) * 1.1)
    else:
        norm1 = mpl.colors.Normalize(vmin=np.min(labels), vmax=np.max(labels))
    mappable = mpl.cm.ScalarMappable(norm=norm1, cmap=cmaps)
    return mappable


def _combine_legend():
    handles, labels = plt.gca().get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    plt.legend(by_label.values(), by_label.keys())


def _trans_plt2np(fig):
    # 将plt图像转为numpy数组
    fig.canvas.draw()
    w, h = fig.canvas.get_width_height()
    buf_ndarray = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    res_img = buf_ndarray.reshape(h, w, 3)
    res_img = cv.cvtColor(res_img, cv.COLOR_BGR2RGB)
    return res_img


def show_specs_class(spec_pos, specs, labels, title='光谱分布', title2='平均光谱', class_names=None):
    """
    展示分类任务的光谱分布
    @param spec_pos: 光谱波长坐标；
    @param specs: 光谱数据，形状为[n,spec]
    @param labels: 标签数据，形状为[n]
    @param title: 图表标题
    @param class_names: dict,类别名称,key为类别标签,value为名称,可用中文
    @return: np.ndarray，光谱分布图,平均光谱分布图
    """
    if len(specs.shape) < 2:
        specs = np.reshape(specs, (1, -1))
        labels = np.array([labels])
    print(labels)
    labels_set = np.unique(labels).tolist()
    class_num = len(labels_set)
    cmaps = plt.get_cmap('rainbow')(np.linspace(0, 1, class_num))
    fig = plt.figure(figsize=(5, 4), dpi=DPI)
    class_map = {}
    for spec, lb in zip(specs, labels):
        color = cmaps[labels_set.index(lb)]
        if lb not in class_map:
            class_map[lb] = []
        class_map[lb].append(spec)
        if class_names is not None:
            lb = class_names[lb]
        plt.plot(spec_pos, spec, linewidth=1, c=color, label=lb, alpha=0.5)
    plt.title(title)
    plt.legend(loc='best')
    if len(spec_pos) < 20:
        plt.xticks(spec_pos)
    plt.grid()
    # 合并同一标签的图例
    _combine_legend()
    res_img = _trans_plt2np(fig)
    fig2 = plt.figure(figsize=(5, 4), dpi=DPI)
    for lb, sp in class_map.items():
        color = cmaps[labels_set.index(lb)]
        if class_names is not None:
            lb = class_names[lb]
        plt.plot(spec_pos, np.mean(sp, axis=0), linewidth=1, c=color, label=lb, alpha=0.5)
    plt.title(title2)
    plt.legend(loc='best')
    if len(spec_pos) < 20:
        plt.xticks(spec_pos)
    plt.grid()
    res_img2 = _trans_plt2np(fig2)
    return res_img, res_img2


def show_specs_regre(spec_pos, specs, labels, title='光谱分布'):
    """
    展示回归任务的光谱分布
    @param spec_pos: 光谱波长坐标；
    @param specs: 光谱数据，形状为[n,spec]
    @param labels: 标签数据，形状为[n]
    @param title: 图表标题
    @return: np.ndarray，光谱分布图
    """
    if len(specs.shape) < 2:
        specs = specs.reshape((1, -1))
        labels = labels.reshape((1, -1))
    mappable = _get_regre_colormap(labels)
    fig, ax = plt.subplots(figsize=(5, 4), dpi=DPI)
    for spec, lb in zip(specs, labels):
        color = mappable.to_rgba(lb)
        plt.plot(spec_pos, spec, linewidth=1, c=color, alpha=0.5)
    plt.title(title)
    fig.colorbar(
        mappable, orientation='vertical', ax=ax,
        ticks=np.linspace(np.min(labels), np.max(labels), 10),
        label='指标分布'
    )
    if len(spec_pos) < 20:
        plt.xticks(spec_pos)
    plt.grid()
    res_img = _trans_plt2np(fig)
    return res_img


def show_dimension_reduction(specs, labels, label_type=1, title='降维分布', class_names=None):
    """
    展示特征降维的结果
    @param specs: 光谱数据，形状为[n,spec]
    @param labels: 标签数据，形状为[n]
    @param label_type: 标签类型，1分类，2回归，3分割
    @param title: 图表标题
    @return: np.ndarray，光谱分布图
    """
    from sklearn.decomposition import PCA
    from sklearn import preprocessing
    pca = PCA(n_components=2)
    data_x_pca = pca.fit_transform(specs)
    # 归一化处理
    scaler = preprocessing.MinMaxScaler(feature_range=(-1, 1))
    data_x_pca = scaler.fit_transform(data_x_pca)

    # 可视化展示
    fig = plt.figure(figsize=(5, 4))
    # ax = fig.add_subplot(projection='3d')
    ax = fig.add_subplot(1, 1, 1)
    ax.set_title(title)
    plt.xlim((-1.1, 1.1))
    plt.ylim((-1.1, 1.1))
    # plt.zlim((-1.1, 1.1))
    # for i in range(len(result)):
    #     plt.text(result[i,0], result[i,1], str(y[i]),
    #              color=color[y[i]], fontdict={'weight': 'bold', 'size': 9})
    if label_type == 1:
        labels_set = np.unique(labels).tolist()
        class_num = len(labels_set)
        cmaps = plt.get_cmap('rainbow')(np.linspace(0, 1, class_num))
    elif label_type == 2:
        mappable = _get_regre_colormap(labels)
        plt.colorbar(
            mappable, orientation='vertical',
            label='指标分布',
            ax=ax
        )
    for x, lb in zip(data_x_pca, labels):
        if label_type == 1:
            color = cmaps[labels_set.index(lb)]
            if class_names is not None:
                lb = class_names[lb]
        elif label_type == 2:
            color = mappable.to_rgba(lb)
        ax.scatter(x[0], x[1], color=color, s=10, label=lb)
    if label_type == 1:
        _combine_legend()
    # from sklearn.cluster import KMeans
    # from scipy.spatial.distance import cdist
    # ax = fig.add_subplot(1, 2, 2)
    # distortions = []
    # K = range(1, 10)
    # for k in K:
    #     kmeanModel = KMeans(n_clusters=k, n_init=10).fit(data_x_pca)
    #     # 计算每个K值对应的cost,用于K值选取的参考
    #     distortions.append(
    #         sum(np.min(cdist(data_x_pca, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / data_x_pca.shape[0])
    # plt.plot(K, distortions, 'bx-')
    # plt.grid()
    # plt.xlabel('k')
    # plt.xticks(K)
    # plt.ylabel('Distortion')
    # plt.title('聚类指标')
    # 合并同一标签的图例
    res_img = _trans_plt2np(fig)
    return res_img


def show_confusion_matrix(y_label, y_pred, class_names=None):
    """
    展示分类结果的混淆矩阵
    @param y_label: 真实值
    @param y_pred: 预测值
    @param class_names: 标签名称映射
    @return: res_img：array,混淆矩阵图；
    @return: report:dict，分类检测报告
    """
    if type(class_names) is dict:
        class_names = class_names.values()
    report = classification_report(y_label, y_pred, output_dict=True)
    proportion = []
    cm = confusion_matrix(y_label, y_pred)
    length = len(cm)
    for i in cm:
        for j in i:
            temp = j / (np.sum(i))
            proportion.append(temp)
    pshow = []
    for i in proportion:
        pt = "%.2f%%" % (i * 100)
        pshow.append(pt)
    fig = plt.figure(figsize=(5, 4), dpi=DPI)
    proportion = np.array(proportion).reshape(length, length)  # reshape(列的长度，行的长度)
    pshow = np.array(pshow).reshape(length, length)
    plt.imshow(proportion, interpolation='nearest', cmap=plt.cm.Blues)  # 按照像素显示出矩阵
    # plt.colorbar()
    if class_names is None or len(class_names) != len(cm):
        class_names = [i for i in range(len(cm))]
    tick_marks = np.arange(len(class_names))
    plt.xticks(tick_marks, class_names, fontsize=12)
    plt.yticks(tick_marks, class_names, fontsize=12)
    thresh = cm.max() / 2.
    iters = np.reshape([[[i, j] for j in range(length)] for i in range(length)], (cm.size, 2))
    for i, j in iters:
        if (i == j):
            plt.text(j, i - 0.12, format(cm[i, j]), va='center', ha='center', fontsize=10, color='black',
                     weight=5)  # 显示对应的数字
            plt.text(j, i + 0.12, pshow[i, j], va='center', ha='center', fontsize=10, color='black')
        else:
            plt.text(j, i - 0.12, format(cm[i, j]), va='center', ha='center', fontsize=10)  # 显示对应的数字
            plt.text(j, i + 0.12, pshow[i, j], va='center', ha='center', fontsize=10)

    plt.ylabel('真实值', fontsize=16)
    plt.xlabel('预测值', fontsize=16)
    plt.tight_layout()
    res_img = _trans_plt2np(fig)
    return res_img, report


def show_result_detect(spec_images, target_rois, result, title='检测结果', class_names=None):
    """
    展示分类任务的检测效果图
    @param spec_images: 多光谱或高光谱数据
    @param target_rois: 分割后的目标ROI
    @param result: 模型预测的结果，数量应与ROI的数量一致
    @param title: 图表标题
    @param class_names: 类别名称映射
    @return: 展示效果图
    """
    assert len(target_rois) == len(result)
    vis_img = spec_images[:, :, spec_images.shape[2] // 2]
    vis_img = (vis_img / vis_img.max() * 200).astype(np.uint8)
    vis_img = cv.cvtColor(vis_img, cv.COLOR_BGR2RGB)
    fig = plt.figure(figsize=(5, 4), dpi=DPI)
    plt.axis('off')
    for roi, label in zip(target_rois, result):
        roi_mask, roi_rect = roi
        bx, by, bw, bh = roi_rect
        # cv.rectangle(vis_img, (bx, by), (bx + bw, by + bh), (255, 255, 255), 1)
        rectangle = plt.Rectangle((bx, by), bw, bh, fill=False, color='red')
        plt.gca().add_patch(rectangle)
        if class_names is not None and label in class_names:
            label = class_names[label]
        # (fw, fh), bh = cv.getTextSize(label, cv.FONT_HERSHEY_SIMPLEX, 2, 2)
        # tx, ty = bx + (bw - fw) // 2, by - fh - 5
        # 中文会有乱码
        # cv.putText(vis_img, label, (tx, ty), cv.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv.LINE_AA)
        box = {
            'facecolor': '.75',
            'edgecolor': 'k',
            'boxstyle': 'round',
        }
        plt.text(bx + bw // 2, by + bh // 2, label, ha='center', va='center', bbox=box)
    plt.imshow(vis_img)
    vis_img = _trans_plt2np(fig)
    return vis_img


def show_result_segmentation_class(spec_images, target_rois, result, title='检测结果', class_names=None):
    """
    展示分割任务的检测效果图
    @param spec_images:多光谱或高光谱数据
    @param target_rois: 分割后的目标ROI
    @param result: 模型预测的结果，数量应与ROI的数量一致
    @param title: 图表标题
    @param class_names: 类别名称映射
    @return: 展示效果图
    """
    assert len(target_rois) == len(result)
    # 取中间波段的图像进行展示
    vis_img = np.zeros_like(spec_images[:, :, spec_images.shape[2] // 2])
    values = set([0])
    if class_names is not None and 0 not in class_names:
        class_names[0] = '背景'
    labels_set = np.unique(result).tolist()
    labels_set.insert(0, 0)
    for roi, label in zip(target_rois, result):
        mask = roi[0]
        idx = labels_set.index(label)
        vis_img[mask] = idx
        values.add(label)
    fig = plt.figure(figsize=(5, 4), dpi=DPI)
    im = plt.imshow(vis_img, interpolation='none')
    colors = [im.cmap(im.norm(value)) for value in values]
    patches = [mpatches.Patch(color=colors[v],
                              label=f"{class_names[v] if class_names is not None else v}") for
               i, v in
               enumerate(values)]
    # put those patched as legend-handles into the legend
    plt.legend(handles=patches, bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    plt.axis('off')
    fig.tight_layout(pad=1)
    res_img = _trans_plt2np(fig)
    return res_img


def show_label_dist(labels, bins=5, title='指标分布统计'):
    """
    展示标签的统计分布直方图
    @param labels: 标签
    @param bins: 分组数
    @param title: 标题
    @return: 统计直方图
    """
    fig = plt.figure(figsize=(5, 4), dpi=DPI)
    bins = min(len(np.unique(labels)), bins)
    # plt.hist(labels, 5, color='steelblue', edgecolor='k')
    plt.hist(labels, bins, alpha=0.5)
    plt.title('指标分布直方图')
    plt.xlabel('指标分布')
    plt.ylabel('样本数量(个)')
    plt.grid(alpha=0.5)
    fig.tight_layout(pad=1)
    res_img = _trans_plt2np(fig)
    return res_img


def show_result_regre(y_true, y_pred, title='检测结果'):
    """
    展示回归任务的拟合结果
    @param y_true: 真实标签
    @param y_labels: 预测标签
    @param title: 标题
    @return: 展示图片
    """
    fig = plt.figure(figsize=(5, 4), dpi=DPI)
    plt.scatter(y_true, y_pred)
    ymax, ymin = 1.05 * max(y_true.max(), y_pred.max()), 0.95 * min(y_true.min(), y_pred.min()),
    line0 = np.linspace(ymin, ymax, 50)
    plt.grid()
    plt.plot(line0, line0)
    plt.title(title)
    plt.xlabel('真实值')
    plt.ylabel('预测值')
    fig.tight_layout(pad=1)
    res_img = _trans_plt2np(fig)
    return res_img


if __name__ == '__main__':
    f = '/Users/gordon/data/chenpi/国创/data/3/3_2_20230605_175021/3_2_20230605_175021.hdr'
    import spectral

    msi = spectral.open_image(f).load()
    from gx_spectral.feature.roi import *

    img = (msi[:, :, 0] / 4).astype(np.uint8)
    mask = seg_thresh(img, 40)
    rois, im = split_roi(img, mask, 'rect')
    from gx_spectral.feature.spectrum import calc_random_grid_spectrum

    specs, im = calc_random_grid_spectrum(msi, rois, 'mean', spec_num=20)
    labels = []
    labels.extend([1] * 20)
    labels.extend([2] * 20)
    ss = []
    ss.extend(specs[0])
    ss.extend(specs[1])
    spec_pos = [713 + 23 * i for i in range(10)]
    class_names = {1: '白板', 2: '陈皮'}
    img, img2 = show_specs_class(spec_pos, ss, labels, '光谱分布表', class_names)
    # labels = [i / 10 for i in range(40)]
    # img = show_specs_regre(spec_pos, ss, labels)
    img = show_dimension_reduction(ss, labels, 1, class_names=class_names)
    # img, report = show_confusion_matrix([1, 2, 3], [2, 2, 3], ['啊', '反倒是', '反倒是2'])
    # print(report)
    # img = show_result_segmentation_class(msi, rois, [1, 2], '陈皮年份检测', class_names=class_names)
    # img = show_result_detect(msi, rois, [1, 2], '陈皮年份检测', class_names=class_names)
    cv.imshow('img', img)
    cv.waitKey(0)
    cv.imshow('img2', img2)
    cv.waitKey(0)
