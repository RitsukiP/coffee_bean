
# 优尼科光谱相机相关参数
class UniSpecDevice:
    width = 1280
    height = 1024
    spec_resolution = 23
    bands = [713, 736, 759, 782, 805, 828, 851, 874, 897, 920]


