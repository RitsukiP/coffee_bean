
# 设备类型：1优尼科
DEVICE_TYPE_UNISPEC = 1
