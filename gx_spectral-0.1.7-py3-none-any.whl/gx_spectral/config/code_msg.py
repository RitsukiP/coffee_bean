class CodeMsg:
    def __init__(self, code, msg):
        self.code = code
        self.msg = msg


SUCCESS = CodeMsg(0, "")
COMMON_INTERNAL_ERROR = CodeMsg(100000, "程序内部异常")
COMMON_PARAM_INVALID = CodeMsg(100001, "参数异常")
COMMON_FILE_INVALID = CodeMsg(100002, "文件异常")
COMMON_DATASET_INVALID = CodeMsg(100003, "数据集规范异常")
