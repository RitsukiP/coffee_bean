from gx_spectral.config.code_msg import CodeMsg


class ApiException(Exception):
    code = 100000
    msg = "程序内部异常"
    content = ''

    def __init__(self, code_msg: CodeMsg, content=''):
        self.code = code_msg.code
        self.msg = code_msg.msg
        self.content = content

    def to_result(self):
        return {'code': self.code, 'msg': self.msg, 'content': self.content}

    def __str__(self):
        return str({'code': self.code, 'msg': self.msg, 'content': self.content})
