# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Time    : 2020/9/20 
# @Author  : my_name_is_BUG
# @FileName: SPA.py
# @Software: PyCharm
# @Cnblogs ：https://blog.csdn.net/qq2512446791

# python: Python 3.7.3
# pandas: pandas 0.25.3
# numpy : numpy  1.16.2
# scipy : scipy  1.4.1
# progress:progress    1.5

import pandas as pd
import numpy as np
from scipy.linalg import qr, inv, pinv
import scipy.stats
import scipy.io as scio
# from progress.bar import Bar
from matplotlib import pyplot as plt

import pdb  # 调试器


class SPA:

    def _projections_qr(self, X, k, M):
        '''
        原版连续投影算法使用MATLAB内置的QR函数
        该版本改用scipy.linalg.qr函数
            https://docs.scipy.org/doc/scipy-0.14.0/reference/generated/scipy.linalg.qr.html
        X : 预测变量矩阵
        k ：投影操作的初始列的索引
        M : 结果包含的变量个数  # M指筛选波长的列数

        return ：由投影操作生成的变量集的索引
        '''

        X_projected = X.copy()

        # 计算各个列向量模的平方和
        norms = np.sum((X ** 2), axis=0)
        # 找到norms中数值最大列的平方和，即最大模值的向量
        norm_max = np.amax(norms)

        # 缩放第K列 使其成为“最大的”列。修改光谱矩阵的第k列，放大一定倍数，使得第k个向量的模值最大。目的是为了QR分解时，qr()函数自动选中第k列作为初始化列。这样做并不会造成投影结果向量发生改变，因为投影方向向量伸缩倍数不影响投影结果。
        X_projected[:, k] = X_projected[:, k] * 2 * norm_max / norms[k]

        # 矩阵分割，order为返回的列交换索引
        _, __, order = qr(X_projected, 0, pivoting=True)  # 变量_, __分别指Q和R矩阵。overwrite_a = 0表示不覆盖原矩阵。order是一维数组。
        #         print(_.shape, __.shape) # (14, 14)、(14, 2048)
        return order[:M].T  # 选择光谱矩阵前M列的位置

    def _validation(self, Xcal, ycal, var_sel, Xval=None, yval=None):
        '''
        [yhat,e] = validation(Xcal,var_sel,ycal,Xval,yval) -->  使用单独的验证集进行验证
        [yhat,e] = validation(Xcal,ycalvar_sel) --> 交叉验证
        '''
        N = Xcal.shape[0]  # N 测试集的个数
        if Xval is None:  # 判断是否使用验证集
            NV = 0
        else:
            NV = Xval.shape[0]  # 验证集的样本个数

        yhat = e = None

        # 若有验证集（预测集），则使用该集合计算RMSE，否则使用留一交叉验证对数据集的每一个样本计算预测值，然后求整个输入集合的RMSE
        # 使用单独的验证集进行验证
        if NV > 0:
            Xcal_ones = np.hstack(
                [np.ones((N, 1)), Xcal[:, var_sel].reshape(N, -1)])  # np.ones((N, 1)作为多元线性回归的偏置项

            # 对偏移量进行多元线性回归
            b = np.linalg.lstsq(Xcal_ones, ycal, rcond=None)[0]  # least square，b返回来的模型参数
            # 对验证集进行预测
            np_ones = np.ones((NV, 1))
            Xval_ = Xval[:, var_sel]
            X = np.hstack([np.ones((NV, 1)), Xval[:, var_sel]])
            yhat = X.dot(b)
            # 计算误差
            e = yval - yhat
        else:
            # 为yhat 设置适当大小
            yhat = np.zeros((N, 1))
            for i in range(N):
                # 从测试集中 去除掉第 i 项
                cal = np.hstack([np.arange(i), np.arange(i + 1, N)])  # N个样本中除去第i个样本
                # X = Xcal[cal, var_sel.astype(int)]  # 报错
                X = Xcal[cal, :]
                X = X[:, var_sel.astype(int)]
                y = ycal[cal]
                xtest = Xcal[i, var_sel]  # 第i个样本
                # ytest = ycal[i]
                X_ones = np.hstack([np.ones((N - 1, 1)), X.reshape(N - 1, -1)])
                xtest = np.hstack([np.ones((1, 1)), xtest.reshape(1, -1)])  # (1, ?)
                # 对偏移量进行多元线性回归
                b = np.linalg.lstsq(X_ones, y, rcond=None)[0]
                # 对验证集进行预测
                # yhat[i] = np.hstack([np.ones(1), xtest]).dot(b)  # 报错
                yhat[i] = xtest.dot(b)
            # 计算误差
            e = ycal - yhat

        return yhat, e

    def spa(self, Xcal, ycal, m_min=1, m_max=None, Xval=None, yval=None, autoscaling=1, show_img=False):
        '''
        [var_sel,var_sel_phase2] = spa(Xcal,ycal,m_min,m_max,Xval,yval,autoscaling) --> 使用单独的验证集进行验证
        [var_sel,var_sel_phase2] = spa(Xcal,ycal,m_min,m_max,autoscaling) --> 交叉验证

        如果 m_min 为空时， 默认 m_min = 1
        如果 m_max 为空时：
            1. 当使用单独的验证集进行验证时， m_max = min(N-1, K)  # N指光谱矩阵的样本个数
            2. 当使用交叉验证时，m_max = min(N-2, K)

        autoscaling : 是否使用自动刻度 yes = 1，no = 0, 默认为 1

        '''

        assert (autoscaling == 0 or autoscaling == 1), "请选择是否使用自动计算"

        N, K = Xcal.shape

        if m_max is None:
            if Xval is None:
                m_max = min(N - 1, K)  # 筛选的波长数不超过矩阵的秩
            else:
                m_max = min(N - 2, K)

        # assert (m_max < min(N - 1, K)), "m_max 参数异常"  # 报错

        # 第一步： 对训练集进行投影操作
        normalization_factor = None
        if autoscaling == 1:
            normalization_factor = np.std(
                Xcal, ddof=1, axis=0).reshape(1, -1)[0]  # ddof=1表示无偏标准差（除以n-1）。np.std()默认是除以n。
        else:
            normalization_factor = np.ones((1, K))[0]

        Xcaln = np.empty((N, K))
        for k in range(K):
            x = Xcal[:, k]
            Xcaln[:, k] = (x - np.mean(x)) / normalization_factor[k]  # 对训练集进行标准化

        SEL = np.zeros((m_max, K))  # 存储参数网格搜索的结果（筛选波长数、初始化列向量的位置）

        # 进度条
        # with Bar('Projections :', max=K) as bar:
        for k in range(K):  # 对参数k进行网格搜索
            SEL[:, k] = self._projections_qr(Xcaln, k,
                                             m_max)  # SEL.shape=(m_max, K)。初始化向量为第k列，得到最佳的前m_max个特征波长索引。固定m_max，作为全集。
        #        bar.next()

        # 第二步： 使用验证集进行评估，初步筛选变量
        PRESS = float('inf') * np.ones((m_max + 1, K))

        # with Bar('Evaluation of variable subsets :', max=(K) * (m_max - m_min + 1)) as bar:
        for k in range(K):  # 对参数k、m进行网格搜索。当k=k时，前几个波长对应的误差最小？
            for m in range(m_min, m_max + 1):  # m的可能性为[m_min, m_max]
                var_sel = SEL[:m, k].astype(int)  # 0:m表示前m列（在全集SEL里选择子集）
                _, e = self._validation(Xcal, ycal, var_sel, Xval, yval)  # 拟合训练集、验证集
                #                 print(e)
                PRESS[m, k] = np.conj(e).T.dot(e)  # 误差平方和。PRESS.shape=(m_max-m_min+1, K)
        #            bar.next()

        PRESSmin = np.min(PRESS, axis=0)  # 任意初始化向量，对应的最小误差
        m_sel = np.argmin(PRESS, axis=0)  # 任意初始化向量，最小误差对应的筛选波长数
        k_sel = np.argmin(PRESSmin)  # 全局最佳的初始化向量的位置

        # 第k_sel波段为初始波段时最佳，波段数目为m_sel
        var_sel_phase2 = SEL[:m_sel[k_sel], k_sel].astype(
            int)  # k_sel是全局最佳的初始化列位置，m_sel[k_sel]就是k_sel对应的最佳波段数量m。var_sel_phase2是网格搜索后，得到最佳的各个的波段索引。

        # 第三步： 进一步筛选变量。根据各个变量的权重及前几个变量。
        # 计算相关指数（各特征波长的权重）
        #         pdb.set_trace()  # 调试
        Xcal2 = np.hstack([np.ones((N, 1)), Xcal[:, var_sel_phase2]])  # 从Xcal选出有效波长。
        b = np.linalg.lstsq(Xcal2, ycal, rcond=None)[0]  # b.shape=(Xcal2.shape[0],)，一维数组。b是多元线性回归模型的参数
        std_deviation = np.std(Xcal2, ddof=1, axis=0)  # std_deviation.shape=(Xcal2.shape[0],)，一维数组

        b = np.squeeze(np.array(b))  # 一维数组
        # relev = np.abs(b * std_deviation.T)  # 报错
        relev = np.abs(b * std_deviation)  # relev.shape=(Xcal2.shape[0],)，一维数组
        relev = relev[
                1:]  # relev.shape=(var_sel_phase2.shape[0],)。除去偏置项的相关指数，因为偏置项的相关指数是0（标准差为0）。因为b[index]越大，说明该变量占的比重越大，std_deviation越大，说明该变量的离散程度越大、差异性越大。

        index_increasing_relev = np.argsort(relev, axis=0)
        index_decreasing_relev = index_increasing_relev[::-1].reshape(1, -1)[0]  # 相关指数降序排列

        PRESS_scree = np.empty(len(var_sel_phase2))
        yhat = e = None
        for i in range(len(var_sel_phase2)):
            var_sel = var_sel_phase2[index_decreasing_relev[:i + 1]]  # 根据相关指数降序排序后，再进一步筛选特征
            _, e = self._validation(Xcal, ycal, var_sel, Xval, yval)  # 为什么还要拟合一次？

            PRESS_scree[i] = np.conj(e).T.dot(e)  # 误差平方和

        RMSEP_scree = np.sqrt(
            PRESS_scree / len(e))  # PRESS_scree.shape=(var_sel_phase2.shape[0], )，一维数组。1/ len(e)表示误差平方和的平均值。

        # 分析前几个变量组合时的重要性。找到数组PRESS_scree比PRESS_crit小的位置（对应变量数），再找到最小的位置
        # F-test验证，确定阈值
        PRESS_scree_min = np.min(PRESS_scree)
        alpha = 0.25
        dof = len(e)
        fcrit = scipy.stats.f.ppf(1 - alpha, dof, dof)  # 标量
        PRESS_crit = PRESS_scree_min * fcrit  # 标量

        i_crit = np.min(
            np.nonzero(PRESS_scree < PRESS_crit))  # PRESS_crit作为阈值。在数组中找到小于阈值的各个元素，再求这些元素对应的最小下标i_crit。i_crit>=0
        i_crit = max(m_min - 1, i_crit)  # 要求筛选的特征数至少有2个，i_crit是数组下标

        var_sel = var_sel_phase2[index_decreasing_relev[:i_crit + 1]]  # (i_crit+1)是最终筛选的特征数

        if show_img:
            plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
            plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
            fig1 = plt.figure()
            plt.xlabel('Number of variables included in the model')
            plt.ylabel('RMSE')
            plt.title('Final number of selected variables:{}(RMSE={})'.format(len(var_sel), RMSEP_scree[i_crit]))
            plt.plot(RMSEP_scree)
            plt.scatter(i_crit, RMSEP_scree[i_crit], marker='s', color='r')
            plt.grid(True)

            fig2 = plt.figure()
            plt.plot(Xcal[0, :])
            plt.scatter(var_sel, Xcal[0, var_sel], marker='s', color='r')
            plt.legend(['First calibration object', 'Selected variables'])
            plt.xlabel('Variable index')
            plt.ylabel('Absorbance(scaled)')  # 尺度化后
            plt.grid(True)
            plt.show()

        return var_sel, var_sel_phase2

    def __repr__(self):
        return "SPA()"


from sklearn.base import BaseEstimator, TransformerMixin
import numpy as np
from sklearn.model_selection import GridSearchCV, train_test_split, cross_val_predict


class SpaTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, n=0):
        self.n = n

    def fit(self, X, y=None):
        gx_spa = SPA()
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=10)
        if self.n == 0:
            n_min = 2
            n_max = 30
        else:
            n_min = n_max = self.n
        self.var_sel, self.var_sel_phase2 = gx_spa.spa(Xcal=X_train, ycal=y_train, m_min=n_min, m_max=n_max,
                                                       Xval=X_test,
                                                       yval=y_test)
        return self

    def transform(self, X):
        # 应用自定义的转换，例如将所有值减去均值
        return X[:, self.var_sel]


if __name__ == "__main__":
    data = pd.read_excel(r"F:\实验\data\all.xlsx")
    data = pd.read_excel(r"F:\实验\data\all.xlsx")
    x = data.drop(['names', 'labels'], axis=1)
    y = data.loc[:, 'labels']

    absorbances = x.columns.values

    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import MinMaxScaler

    Xcal, Xval, ycal, yval = train_test_split(x, y, test_size=0.4, random_state=0)

    min_max_scaler = MinMaxScaler(feature_range=(-1, 1))  # 这里feature_range根据需要自行设置，默认（0,1）

    Xcal = min_max_scaler.fit_transform(Xcal)
    Xval = min_max_scaler.transform(Xval)

    var_sel, var_sel_phase2 = SPA().spa(
        Xcal, ycal, m_min=2, m_max=50, Xval=Xval, yval=yval, autoscaling=1)
    print(absorbances[var_sel])
