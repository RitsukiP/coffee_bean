import os
import numpy as np
import scipy.linalg as sl
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.linear_model import LinearRegression
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import train_test_split


class DS(TransformerMixin, BaseEstimator):
    """直接校正（DS）算法: y = X×F
    Ref: 田静. 基于光谱标准化的小麦粉品质 NIR 模型跨仪器共享的研究, P27-28
    """

    def __init__(self):
        self.F = None

    def fit(self, X, y):
        """计算变换矩阵F = X^(-1)×y, X^(-1)为X的广义逆矩阵
        根据从仪器、主仪器分别采集的标样光谱矩阵X和y,计算转换矩阵F
        :param X:从仪器采集的光谱矩阵, shape=(n,p)    n为光谱数, p为波长(变量)数
        :param y:主仪器采集的光谱, shape=(n,p)
        :return: self
        """
        assert X.shape == y.shape
        self.F = np.matmul(sl.pinv(X), y)  # F = X^(-1)×y
        return self

    def transform(self, X):
        return np.matmul(X, self.F)


class PDS(TransformerMixin, BaseEstimator):
    """分段直接校正（PDS）算法，基于线代方法实现
    Ref: 田静. 基于光谱标准化的小麦粉品质 NIR 模型跨仪器共享的研究, P28-29
    """

    def __init__(self, win_size=5):
        self.win_size = win_size
        self.F = None

    def fit(self, X, y):
        """
        :param X:从仪器采集的光谱矩阵, shape=(n,p)    n为光谱数, p为波长(变量)数
        :param y:主仪器采集的光谱, shape=(n,p)
        """
        p = X.shape[1]
        w = round(self.win_size / 2)
        self.F = np.zeros((p, p))
        for i in range(p):
            y_i = y[:, i]  # shape=(n,1)
            X_i = X[:, max(0, i - w):min(p, i + w)]  # shape=(n,k), k=2w+1 or k<2w+1
            # y_i=X_i×b_i, b_i=X_i^(-1)×y_i             # b_i.shape=(k,1)
            b_i = np.matmul(sl.pinv(X_i), y_i)
            # F = diag(b1^T, b2^T, ..., bp^T)           # F.shape=(p,p)
            self.F[i, max(0, i - w):min(p, i + w)] = b_i.T

        return self

    def transform(self, X):
        """y=x×F, F.shape=(p,p)"""
        return np.matmul(X, self.F)


class PDS2(TransformerMixin, BaseEstimator):
    """分段直接校正（PDS）算法，基于PLS方法实现
    Ref: https://blog.csdn.net/qq_51320133/article/details/137503042
    """

    def __init__(self, win_size=5, n_components=5):
        self.win_size = win_size
        self.w = round(self.win_size / 2)
        self.n_components = n_components
        self.regs = None
        self.p = None

    def fit(self, X, y):
        """
        :param X:从仪器采集的光谱矩阵, shape=(n,p)    n为光谱数, p为波长(变量)数
        :param y:主仪器采集的光谱, shape=(n,p)
        """
        self.regs = []
        self.p = X.shape[1]
        for i in range(self.p):
            y_i = y[:, i]  # shape=(n,1)
            X_i = X[:, max(0, i - self.w):min(self.p, i + self.w)]  # shape=(n,k), k=2w+1 or k<2w+1
            # y_i = X_i × b_i + e_i     # 多元回归，用PLS拟合
            if X_i.shape[1] <= self.n_components:
                n_components = X_i.shape[1]
            else:
                n_components = self.n_components
            pls = PLSRegression(n_components=n_components)
            pls.fit(X_i, y_i)
            self.regs.append(pls)
        return self

    def transform(self, X):
        p = X.shape[1]
        y = X.copy()
        assert p == self.p
        for i in range(self.p):
            pls = self.regs[i]
            X_i = X[:, max(0, i - self.w):min(self.p, i + self.w)]
            y_i = pls.predict(X_i)
            y[:, i] = y_i
        return y


class SLRDS(TransformerMixin, BaseEstimator):
    """一元线性回归直接标准化算法SLRDS
    Ref: 田静. 基于光谱标准化的小麦粉品质 NIR 模型跨仪器共享的研究, P29-30
    """

    def __init__(self):
        self.B = None
        self.p = None

    def fit(self, X, y):
        """
        :param X:从仪器采集的光谱矩阵, shape=(n,p)    n为光谱数, p为波长(变量)数
        :param y:主仪器采集的光谱, shape=(n,p)
        """
        self.B = []
        self.reg = LinearRegression()
        n, self.p = X.shape
        for j in range(self.p):
            X_j = X[:, j].reshape(-1, 1)
            y_j = y[:, j]
            self.reg.fit(X_j, y_j)  # y_j = b0 + b·X_j
            b = self.reg.coef_[0]
            b0 = self.reg.intercept_
            self.B.append((b, b0))
        return self

    def transform(self, X):
        y = X.copy()
        n, p = X.shape
        assert p == self.p
        for j in range(p):
            b, b0 = self.B[j]
            x_j = X[:, j]
            y_j = b0 + b * x_j
            y[:, j] = y_j
        return y


class SLRDS2(TransformerMixin, BaseEstimator):
    """一元线性回归直接标准化算法SLRDS
    Ref: 田静. 基于光谱标准化的小麦粉品质 NIR 模型跨仪器共享的研究, P29-30
    """

    def __init__(self):
        self.regs = None
        self.p = None

    def fit(self, X, y):
        """
        :param X:从仪器采集的光谱矩阵, shape=(n,p)    n为光谱数, p为波长(变量)数
        :param y:主仪器采集的光谱, shape=(n,p)
        """
        self.regs = []
        n, self.p = X.shape
        for j in range(self.p):
            X_j = X[:, j].reshape(-1, 1)
            y_j = y[:, j]
            reg = LinearRegression()
            reg.fit(X_j, y_j)  # y_j = b0 + b·X_j
            self.regs.append(reg)
        return self

    def transform(self, X):
        y = X.copy()
        n, p = X.shape
        assert p == self.p
        for j in range(p):
            reg = self.regs[j]
            x_j = X[:, j].reshape(-1, 1)
            y_j = reg.predict(x_j)
            y[:, j] = y_j
        return y


def eval_similarity(X, X_mian, method='distance_ou', **kwargs):
    """计算光谱集X和Y之间的光谱拟合度
    :param X_mian:主仪器采集的光谱矩阵, shape=(n,p)    n为光谱数, p为波长(变量)数
    :param X:从仪器采集的光谱, shape=(n,p)
    :param method:拟合度评估的方法
    """
    assert X_mian.shape == X.shape
    n, p = X_mian.shape
    if method == 'distance_ou':  # 欧氏距离，数值越小表明光谱间差异越小
        D_mean = np.mean(np.sqrt(np.sum(np.square(X_mian - X), axis=1)))
        D_max = np.max(np.sqrt(np.sum(np.square(X_mian - X), axis=1)))
        return {'distance_ou_mean': D_mean, 'distance_ou_max': D_max}
    elif method == 'SSER':  # 光谱标准化误差率, 数值越小表明光谱间的差异越小
        SSER = np.sum((np.abs(X - X_mian) / np.abs(X + X_mian)), axis=1)
        SSER_mean = np.mean(SSER)
        SSER_max = np.max(SSER)
        return {'SSER_mean': SSER_mean, 'SSER_max': SSER_max}
    elif method == 'spec_angle':  # 光谱角，数值越小表明光谱间差异越小
        angles = []
        for i in range(n):
            spec_x = X_mian[i, :]
            spec_y = X[i, :]
            cosine = np.dot(spec_x, spec_y) / (np.linalg.norm(spec_x) * (np.linalg.norm(spec_y)))
            angle_rad = np.arccos(cosine)
            angle_deg = np.degrees(angle_rad)
            # print(cosine, angle_rad, angle_deg)
            angles.append(angle_deg)
        angles = np.array(angles)
        angle_mean = np.mean(angles)
        angle_max = np.max(angles)
        return {'angle_mean': angle_mean, 'angle_max': angle_max}
    else:
        return None


if __name__ == '__main__':
    # 数据生成与划分
    X = np.random.random(size=(10, 225)) * 10  # 生成从仪器的光谱数据，10条光谱，每条225个波长（特征/变量）
    y = X * 5 + np.random.random(size=(10, 225)) * 0.1
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)

    # 算法调用
    ds = DS()
    pds = PDS(win_size=5)
    pds2 = PDS2(win_size=5, n_components=2)
    slred = SLRDS()
    slred2 = SLRDS2()
    mts = [ds, pds, pds2, slred, slred2]
    mts_names = ['ds', 'pds', 'pds2', 'slred', 'slred2']
    methods = ['distance_ou', 'SSER', 'spec_angle']

    # 算法拟合
    for i, mt in enumerate(mts):
        mt.fit(X_train, y_train)
        print(mts_names[i])
        # 算法测试
        Y_test = mt.transform(X_test)
        for method in methods:
            result = eval_similarity(Y_test, y_test, method=method)
            print(result)
        # print(Y - y)
        # print(np.max(Y_test))
        # print(np.max(y_test))
        # print(np.max(Y_test - y_test))
