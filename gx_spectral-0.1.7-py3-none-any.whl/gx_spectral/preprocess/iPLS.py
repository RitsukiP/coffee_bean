import numpy as np
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import cross_validate


def FiPLS(X, y, n_subrange, cv=3, min_component=2, max_component=3):
    """向前向后间隔偏最小二乘
    根据训练集和标签，使用FiPLS选择各个最佳入选的子区间，每次迭代都得到最佳的联合区间
    @param X: 数据集，shape=(num_sample, num_wavelength)
    @param y: 标签，shape=(num_sample,)
    @param n_subrange: 划分的子区间个数
    @param cv: k折交叉验证，k=cv
    @param min_component: PLS回归时的主成分数
    @param max_component: PLS回归时的主成分数
    @return union_subrange_arr: 各次迭代的最佳联合区间
    @return rmse_arr: 各次迭代的最佳联合区间对应的误差
    @return k_sel: 选择的子区间编号
    """

    # 划分区间数
    num_wavelength = X.shape[1]
    wavelength_idx = np.arange(num_wavelength)
    width_per_subrange = round(num_wavelength/n_subrange)  # 各个子区间包括的波长点数

    # 划分子区间
    subrange_list = []
    for i in range(n_subrange):
        start = i * width_per_subrange
        end = start + width_per_subrange
        if i == n_subrange-1:  # 最后一个子区间剩余的波长点
            end = None
        subrange_list.append(wavelength_idx[start:end].tolist())  # 二维数组
    
    # 初始化已选子区间、未选子区间编号
    k_sel = []  # k_sel、to_sel存储的索引是相对原始的数据集
    to_sel = np.arange(n_subrange)
    to_sel = to_sel.tolist()

    # 对各个子区间进行PLSR回归
    union_subrange_list = []
    n_component_list = []
    rmse_list = []
    while(True):  # 某次迭代
        if len(to_sel) == 0:
            break
        
        # 确定已选子区间、未选子区间具体的内容
        k_sel_subrange = [item for idx in k_sel for item in subrange_list[idx]]  # 二维列表展开为一维列表

        n_component_list_tmp = []  # 最佳主成分数
        cv_result_list_tmp = []  # 不同子区间交叉验证结果
        for i in range(len(to_sel)):  # 对i，k网格搜索
            current_subrange = subrange_list[to_sel[i]]  # 一维数组
            sel_subrange = k_sel_subrange + current_subrange  # 一维数组

            cv_result_k_list_tmp = []  # 不同主成分数交叉验证结果
            k_range = np.arange(min_component, max_component + 1)
            for k in k_range:
                cv_result_k = fit_sel_subrange(X, y, sel_subrange, cv, k)  # 对k参数交叉验证结果
                cv_result_k_list_tmp.append(cv_result_k)  # 一维数组
            cv_result_k_temp = np.asarray(cv_result_k_list_tmp)
            idx_k = np.argmin(cv_result_k_temp)
            k = k_range[idx_k]  # 最佳主成分数
            cv_result = cv_result_k_temp[idx_k]
            n_component_list_tmp.append(k)
            cv_result_list_tmp.append(cv_result)

        # 联合区间内容
        cv_result_temp = np.asarray(cv_result_list_tmp)
        best_component_tmp = np.asarray(n_component_list_tmp)
        idx_best_subrange = np.argmin(cv_result_temp)  # 最佳入选子区间
        best_subrange = subrange_list[to_sel[idx_best_subrange]]
        union_subrange = k_sel_subrange + best_subrange
        union_subrange_list.append(np.asarray(union_subrange))  # 二维数组，内层数组大小不同，逐渐递增
        # 对应的主成分数
        best_component = best_component_tmp[idx_best_subrange]
        n_component_list.append(best_component)  # 一维数组
        # 对应的误差
        best_rmse = cv_result_temp[idx_best_subrange]
        rmse_list.append(best_rmse)  # 最佳入选子区间对应的联合区间的RMSE。最终shape=(n_subrange,)
        k_sel.append(to_sel[idx_best_subrange])  # 更新入选的子区间编号
        to_sel.remove(to_sel[idx_best_subrange])  # 更新剩余的子区间编号
    # while循环结束
    union_subrange_arr = np.asarray(union_subrange_list, dtype=object)  # 二维数组
    rmse_arr = np.asarray(rmse_list)  # 一维数组

    return union_subrange_arr, rmse_arr, k_sel, n_component_list


def BiPLS(X, y, n_subrange, cv=3, min_component=2, max_component=3):
    """向后间隔偏最小二乘
    根据训练集和标签，使用BiPLS去除无用子区间，每次迭代都得到保留的最佳联合区间
    @param X: 数据集，shape=(num_sample, num_wavelength)
    @param y: 标签，shape=(num_sample,)
    @param n_subrange: 划分的子区间个数
    @param cv: k折交叉验证，k=cv
    @param min_component: PLS回归时的主成分数
    @param max_component: PLS回归时的主成分数
    @return union_subrange_arr: 每次迭代最佳保留的联合区间
    @return rmse_arr: 每次迭代最佳保留的联合区间对应的误差
    @return k_del: 每次迭代删除选择的子区间编号
    """

    # 划分区间数
    num_wavelength = X.shape[1]
    wavelength_idx = np.arange(num_wavelength)
    width_per_subrange = round(num_wavelength/n_subrange)  # 各个子区间包括的波长点数

    # 划分子区间
    subrange_list = []
    for i in range(n_subrange):
        start = i * width_per_subrange
        end = start + width_per_subrange
        if i == n_subrange-1:  # 最后一个子区间剩余的波长点
            end = None
        subrange_list.append(wavelength_idx[start:end].tolist())
    
    # 初始化已删子区间编号、未删子区间编号
    k_del = []  # k_del、to_del存储的索引是相对原始的数据集
    to_del = np.arange(n_subrange)
    to_del = to_del.tolist()
    
    union_subrange_list = []
    n_component_list = []
    rmse_list = []

    # 对全部子区间进行回归   
    sel_subrange = [item for idx in to_del for item in subrange_list[idx]]
    cv_result = fit_sel_subrange(X, y, sel_subrange, cv, max_component)
    k_del.append(-99)  # 假设表示没有删除子区间号，用于占位
    union_subrange_list.append(np.asarray(sel_subrange))
    rmse_list.append(cv_result)
    
    # 对删除后保留的子区间进行PLSR回归（保留n-1、n-2、...、1个子区间）
    while(True):  # 某次迭代
        if len(to_del) == 1:  # 若删除后剩余0个子区间，不需要删除
            break  # 跳出while循环

        n_component_list_tmp = []
        cv_result_list_tmp = []
        for idx_del in to_del:  # len(to_del) >= 2
            sel_subrange = [item for idx_keep in to_del if idx_keep != idx_del for item in subrange_list[idx_keep]]

            cv_result_k_list_tmp = []  # 不同主成分数交叉验证结果
            k_range = np.arange(min_component, max_component + 1)
            for k in k_range:
                cv_result_k = fit_sel_subrange(X, y, sel_subrange, cv, k)  # 对k参数交叉验证结果
                cv_result_k_list_tmp.append(cv_result_k)  # 一维数组
            cv_result_k_temp = np.asarray(cv_result_k_list_tmp)
            idx_k = np.argmin(cv_result_k_temp)
            k = k_range[idx_k]  # 最佳主成分数
            cv_result = cv_result_k_temp[idx_k]
            n_component_list_tmp.append(k)
            cv_result_list_tmp.append(cv_result)

        cv_result_temp = np.asarray(cv_result_list_tmp)
        n_component_tmp = np.asarray(n_component_list_tmp)

        idx_best_del = np.argmin(cv_result_temp)
        # 保留的各区间内容
        sel_subrange = [item for idx_keep in to_del if idx_keep != to_del[idx_best_del] for item in subrange_list[idx_keep]]
        union_subrange_list.append(np.asarray(sel_subrange))  # 二维数组，内层数组大小不同，逐渐递减
        # 对应的主成分数
        n_component_list.append(n_component_tmp[idx_best_del])
        # 对应的误差
        rmse_list.append(np.min(cv_result_temp))  # 最佳剩余的联合区间对应的RMSE。最终大小为（n_subrange,）

        k_del.append(to_del[idx_best_del])  # 更新被删除的子区间编号。最终大小为（n_subrange-1,）
        to_del.remove(to_del[idx_best_del])  # 更新未删除的子区间编号
    # while循环结束
    union_subrange_arr = np.asarray(union_subrange_list, dtype=object)  # 二维数组
    rmse_arr = np.asarray(rmse_list)  # 一维数组
    
    return union_subrange_arr, rmse_arr, k_del, n_component_list


def FBiPLS(X, y, n_subrange, cv=3, min_component=2, max_component=3):
    """向前向后间隔偏最小二乘
     根据训练集和标签，同时使用FiPLS、BiPLS选择有用子区间、去除无用子区间，每次迭代得到最佳的联合区间。
     当入选子区间编号与删除子区间编号一致时，入选优先级大于删除优先级。
     @param X: 数据集，shape=(num_sample, num_wavelength)
     @param y: 标签，shape=(num_sample,)
     @param n_subrange: 划分的子区间个数
     @param cv: k折交叉验证，k=cv
     @param min_component: PLS回归时的主成分数
     @param max_component: PLS回归时的主成分数
     @return union_subrange_arr: 每次迭代最佳保留的联合区间
     @return rmse_arr: 每次迭代最佳保留的联合区间对应的误差
     @return k_del: 每次迭代删除选择的子区间编号
     """

    # 划分区间数
    num_wavelength = X.shape[1]
    wavelength_idx = np.arange(num_wavelength)
    width_per_subrange = round(num_wavelength/n_subrange)

    # 划分子区间
    subrange_list = []
    for i in range(n_subrange):
        start = i * width_per_subrange
        end = start + width_per_subrange
        if i == n_subrange-1:
            end = None
        subrange_list.append(wavelength_idx[start:end].tolist())  # 二维数组
    
    # 对于FiPLS、BiPLS，初始化已删子区间编号、未删子区间编号
    # FiPLS
    k_sel = []  # k_sel、to_sel存储的索引是相对原始的数据集
    to_sel = np.arange(n_subrange)
    to_sel = to_sel.tolist()
    # BiPLS
    k_del = []  # k_del、to_del存储的索引是相对原始的数据集
    to_del = np.arange(n_subrange)
    to_del = to_del.tolist()

    # FiPLS最佳入选的子区间，联合BiPLS最佳删除后保留的子区间，去重后，进行PLSR回归
    union_subrange_list = []
    n_componet_list = []
    rmse_list = []
    union_sel_list = []
    while(True):
        if len(to_sel) == 0 or len(to_del) == 1:
            break

        # *************************FiPLS*************************
        # 确定已选子区间、未选子区间具体的内容
        k_sel_subrange = [item for idx in k_sel for item in subrange_list[idx]]  # 二维列表展开为一维列表

        n_component_FiPLS_list_tmp = []
        cv_result_FiPLS_list_temp = []
        for i in range(len(to_sel)):
            current_subrange = subrange_list[to_sel[i]]  # 一维数组
            sel_subrange = k_sel_subrange + current_subrange  # 一维数组

            cv_result_k_list_tmp = []  # 不同主成分数交叉验证结果
            k_range = np.arange(min_component, max_component + 1)
            for k in k_range:
                cv_result_k = fit_sel_subrange(X, y, sel_subrange, cv, k)  # 对k参数交叉验证结果
                cv_result_k_list_tmp.append(cv_result_k)  # 一维数组
            cv_result_k_temp = np.asarray(cv_result_k_list_tmp)
            idx_k = np.argmin(cv_result_k_temp)
            k_FiPLS = k_range[idx_k]  # 最佳主成分数
            cv_result_FiPLS = cv_result_k_temp[idx_k]
            n_component_FiPLS_list_tmp.append(k_FiPLS)
            cv_result_FiPLS_list_temp.append(cv_result_FiPLS)  # 一维数组

        cv_result_FiPLS_temp = np.asarray(cv_result_FiPLS_list_temp)
        idx_best_subrange = np.argmin(cv_result_FiPLS_temp)
        k_sel.append(to_sel[idx_best_subrange])  # 更新入选的子区间
        to_sel.remove(to_sel[idx_best_subrange])  # 更新剩余的子区间
        
        # *************************BiPLS*************************
        n_component_BiPLS_list_tmp = []
        cv_result_BiPLS_list_temp = []
        for idx_del in to_del:            
            sel_subrange = [item for idx_keep in to_del if idx_keep != idx_del for item in subrange_list[idx_keep]]
            cv_result_k_list_tmp = []  # 不同主成分数交叉验证结果
            k_range = np.arange(min_component, max_component + 1)
            for k in k_range:
                cv_result_k = fit_sel_subrange(X, y, sel_subrange, cv, k)  # 对k参数交叉验证结果
                cv_result_k_list_tmp.append(cv_result_k)  # 一维数组
            cv_result_k_temp = np.asarray(cv_result_k_list_tmp)
            idx_k = np.argmin(cv_result_k_temp)
            k_BiPLS = k_range[idx_k]  # 最佳主成分数
            cv_result_BiPLS = cv_result_k_temp[idx_k]
            n_component_BiPLS_list_tmp.append(k_BiPLS)
            cv_result_BiPLS_list_temp.append(cv_result_BiPLS)  # 一维数组

        cv_result_BiPLS_temp = np.asarray(cv_result_BiPLS_list_temp)
        idx_best_del = np.argmin(cv_result_BiPLS_temp)
        k_del.append(to_del[idx_best_del])  # 更新被删除的子区间编号
        to_del.remove(to_del[idx_best_del])  # 更新未删除的子区间编号

        # *************************对to_sel、to_del集合相互删除重复的子区间，联合及拟合*************************
        if k_del[-1] != k_sel[-1]:  # -1指最后一个元素
            to_sel = remove_duplicate(to_sel, k_del[-1])  # 根据最后删除的子区间，删除重复的区间，更新to_sel集合
            to_del = remove_duplicate(to_del, k_sel[-1])  # 根据最后入选的子区间，删除重复的区间，更新to_del集合
        union_sel = k_sel + to_del  # 不会出现重复的子区间，因为相互删除了

        union_subrange = [item for idx in union_sel for item in subrange_list[idx]]
        cv_result_union = fit_sel_subrange(X, y, union_subrange, cv, max_component)
        best_rmse = cv_result_union
        # 联合区间内容
        union_subrange_list.append(np.asarray(union_subrange))  # 二维数组，内层数组大小不同，逐渐递增
        union_sel_list.append(union_sel)
        # 对应的主成分数
        n_componet = k_FiPLS + k_BiPLS  # TODO
        n_componet_list.append(n_componet)
        # 对应的误差
        rmse_list.append(best_rmse)  # 最佳子区间对应的联合区间的RMSE
    # while循环结束
    union_subrange_arr = np.asarray(union_subrange_list, dtype=object)  # 二维数组
    rmse_arr = np.asarray(rmse_list)  # 一维数组

    return union_subrange_arr, rmse_arr, union_sel_list, n_componet_list  # , k_sel, k_del


def fit_sel_subrange(X, y, sel_subrange, cv, n_components):
    """拟合最新入选联合区间的子区间
    使用k折交叉验证来评估
    @param X: 数据集，shape=(num_sample, ?)
    @param y: 标签，shape=(num_sample,)
    @param sel_subrange: 当前的联合区间
    @param cv: k折交叉验证，k=cv
    @param n_components: PLS回归时的主成分数
    @return mean_cv_result: k折交叉验证对应的误差
    """

    X_sel = X[:, sel_subrange]
    plsr = PLSRegression(n_components=n_components, scale=False, tol=1e-06, copy=True)
    cv_result = cross_validate(plsr, X_sel, y, cv=cv, scoring="neg_root_mean_squared_error")  # 评估指标：负的均方根误差
    mean_cv_result = -1*np.mean(cv_result["test_score"])
    return mean_cv_result


def remove_duplicate(list_, element):
    """
    从数组中删除和指定元素相同的元素
    """
    if element in list_:
        list_.remove(element)
    return list_


if __name__ == "__main__":
    from gx_spectral.preprocess import iPLS
    np.random.seed(1)
    X = np.random.randint(0, 200, (100, 50))
    y = np.random.randint(0, 200, (100, ))
    print(X.shape, y.shape)

    union_subrange_arr, rmse_arr, k_sel, n_component_list = iPLS.FiPLS(X, y, 5, cv=3, min_component=2, max_component=4)
    # union_subrange_arr, rmse_arr, k_del, n_component_list = iPLS.BiPLS(X, y, 5, cv=3, min_component=2, max_component=4)
    # union_subrange_arr, rmse_arr, union_sel, n_component_list = iPLS.FBiPLS(X, y, 5, cv=3, min_component=2, max_component=4)

    print(union_subrange_arr.shape, rmse_arr.shape, len(k_sel), len(n_component_list))
    # print(union_subrange_arr.shape, rmse_arr.shape, len(union_sel), len(n_component_list))
    print(union_subrange_arr)
    print(rmse_arr, k_sel, n_component_list)
    print(rmse_arr, n_component_list)
    # print(*union_sel, sep='\n')
















