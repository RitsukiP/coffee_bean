import cv2

"""
图像裁剪
自动裁剪(auto_cropping):输入裁剪比例即可按相应比例裁剪图像中间区域
手动裁剪(manual_cropping):手动选择裁剪区域
"""


def _auto_cropping(images, ratio):
    """
    :param images: shape:(1024,1280,10)，传入10张图片的三维numpy矩阵以及裁剪比例
    :return: 裁剪后的三维numpy矩阵
    """
    height = images.shape[0]
    width = images.shape[1]
    w1 = ratio * width
    h1 = ratio * height
    w11 = round((width - w1) / 2)
    w12 = round(w1 + (width - w1) / 2)
    h11 = round((height - h1) / 2)
    h12 = round(h1 + (height - h1) / 2)
    result = images[h11:h12, w11:w12, :]
    return result


def _manual_cropping(images):
    """
    :param images: 传入10张图片的三维numpy矩阵，shape:(1024,1280,10)
    :return: 裁剪后的三维numpy矩阵
    """
    img = images[:, :, -2]
    roi = cv2.selectROI('Select cropping area', img, showCrosshair=False, fromCenter=False)
    xmin, ymin, w, h = roi  # 矩形裁剪区域 (ymin:ymin+h, xmin:xmin+w) 的位置参数
    result = images[ymin:ymin + h, xmin:xmin + w, :]  # 切片获得裁剪后保留的图像区域
    return result


def cropping(images, ratio, mode=1):
    """裁剪图片
    传入图片numpy矩阵和裁剪比例，完成图片裁剪
    @param images: 传入10张图片的三维numpy矩阵，shape:(1024,1280,10)
    @param ratio: 裁剪比例
    @param mode: 裁剪模式，1自动，2手动
    @return: 裁剪后的图片矩阵
    """
    if mode == 1:
        return _auto_cropping(images, ratio)
    elif mode == 2:
        return _manual_cropping(images)


if __name__ == '__main__':
    from gx_spectral.utils import samples

    images = samples.read_unispec_sample()
    result = cropping(images, 0.8)
    for i in range(result.shape[2]):
        cv2.imwrite(f'../../tmp/{i}.png', result[:, :, i])
