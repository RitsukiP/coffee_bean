import numpy as np
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import KFold


class UVE:
    def __int__(self):
        pass

    def uvepls(self, X, y, n_component=3, noise_order=1e-10, seed=1):
        """
        UVE-PLS无信息变量消除法
        @param noise_order: 噪声数量级
        @return var_sel: 筛选的变量索引
        """

        n, m = X.shape
        np.random.seed(seed)
        R = np.random.random((n, m))*10*noise_order
        XR = np.c_[X, R]  # (n, 2m)

        if n_component > n or n_component > m:
            n_component = np.min([n, m])
        model = PLSRegression(n_components=n_component, scale=False)

        kFold = KFold(n_splits=n)  # 留一交叉验证
        idx = np.arange(n)
        temp = np.reshape(np.arange(2*m), [-1,1])
        for [cal_idx, val_idx], i in zip(kFold.split(idx), idx):
            XR_cal = XR[cal_idx,:]
            # XR_val = XR[val_idx,:]
            y_cal = y[cal_idx]
            # y_val = y[val_idx]
            model.fit(XR_cal, y_cal)
            # y_pred_cal = model.predict(XR_cal)
            # y_pred_val = model.predict(XR_val)
            coef_ = model.coef_  # (2m, 1)
            if i==0:
                coef = np.c_[temp, coef_]
            else:
                coef = np.c_[coef, coef_]
        coef = np.delete(coef, [0], axis=1)  # (2m, n)
        # print('111', coef.shape)
        mean_coef = np.mean(coef, axis=1)  # (2m, )
        std_coef = np.std(coef, axis=1, ddof=1)  # (2m, )
        confidence = mean_coef/std_coef  # 每个变量的可信度
        confidence_R = confidence[m:]
        confidence_X = confidence[:m]
        thres = np.max(np.abs(confidence_R))
        var_sel = np.abs(confidence_X) > thres  # 可信度高的变量索引

        return var_sel, confidence_X


if __name__ == "__main__":
    from UVE import UVE
    np.random.seed(1)
    X = np.random.randint(0, 200, (100, 50))
    y = np.random.randint(0, 200, (100,))
    print(X.shape, y.shape)

    uve = UVE()
    var_sel = uve.uvepls(X,y,3,noise_order=1e-10)
    print(var_sel.shape, var_sel)