import numpy as np

from scipy.stats import pearsonr
import itertools as it


class TwoWaveComb:
    def __int__(self):
        pass

    def two_wave_comb(self, X, y, n_sel):
        """
        双波段组合法提取pearson相关系数最优的前几个特征

        params
            X：训练集
            y：某一种物质的标签
            n_sel：选择的特征波长数
        return
            X_sel
            e_sel：选择的双波段名称，[(x2,x1),(x5,x3)]
            m_type_sel：双波段名称对应的组合方法
        """

        row = X.shape[0]
        col = X.shape[1]
        n_combination = col * (col - 1) / 2  # 45、36
        x0 = np.arange(col) + 1
        x = np.arange(n_combination) + 1
        n_method = 4
        # color = ['red', 'green', 'blue', 'black', 'cyan', 'rosybrown', 'deepskyblue', 'darkorange', 'burlywood', 'pink',
        #          'cadetblue', 'chartreuse', 'chocolate', 'coral', 'cornflowerblue', 'cornsilk', 'crimson', 'darkgray',
        #          'darkgreen', 'darkkhaki', 'darkmagenta', 'darkolivegreen']
        # m_type_name = ['subtract', 'add', 'divide', 'normalized']

        r_list_temp1 = []
        e_list_temp1 = []
        m_type_list_temp1 = []
        # 单波段
        for i in range(col):
            r, p = pearsonr(X[:, i], y)
            r_list_temp1.append(r)
            e_list_temp1.append(i)
            m_type_list_temp1.append(-1)  # 假设-1表示单波段的方法

        # 双波段组合
        for j in range(0, n_method):  # 4种方法。某一种方法：(0, 1)、(1, 2)、(2, 3)、(3, 4)

            r_list_temp2 = []
            e_list_temp2 = []
            m_type_list_temp2 = []
            for e in it.combinations(np.arange(col), 2):  # 波段组合可能性，e是元祖(x1,x2)
                if j == 0:  # 差值
                    combination = X[:, e[1]] - X[:, e[0]]
                if j == 1:  # 和值
                    combination = X[:, e[1]] + X[:, e[0]]
                if j == 2:  # 比值
                    combination = X[:, e[1]] / (X[:, e[0]] + np.finfo(float).eps)
                if j == 3:  # 归一化
                    combination = (X[:, e[1]] - X[:, e[0]]) / (X[:, e[1]] + X[:, e[0]] + np.finfo(float).eps)

                r, p = pearsonr(combination, y)
                r_list_temp2.append(r)
                e_list_temp2.append(e)
                m_type_list_temp2.append(j)

            # 从单波段开始拼接
            r_list_temp1 = r_list_temp1 + r_list_temp2
            e_list_temp1 = e_list_temp1 + e_list_temp2
            m_type_list_temp1 = m_type_list_temp1 + m_type_list_temp2

            # 画图
        #         plt.subplot(1,1,1)
        #         plt.plot(x, r_list_temp2, color=color[j], marker='.', linestyle='-', label=m_type_name[j])
        #         plt.xlabel('combination feature')
        #         plt.ylabel('pearsonr')
        #         plt.legend(bbox_to_anchor=(1.05, 0), loc=3, borderaxespad=0)

        r_temp1 = np.array(r_list_temp1)
        e_temp1 = np.array(e_list_temp1, dtype='object')
        m_type_temp1 = np.array(m_type_list_temp1)

        idx_sorted = np.argsort(-np.abs(r_list_temp1))
        r_sorted = r_temp1[idx_sorted]  # 从大到小排序
        e_sorted = e_temp1[idx_sorted]
        m_type_sorted = m_type_temp1[idx_sorted]

        r_sel = r_sorted[0:n_sel]
        e_sel = e_sorted[0:n_sel]
        m_type_sel = m_type_sorted[0:n_sel]

        X_sel = np.zeros([row, n_sel])
        for e, m_type, i in zip(e_sel, m_type_sel, np.arange(n_sel)):
            if m_type == -1:  # 单波段法
                X_sel[:, i] = X[:, e]
            if m_type == 0:  # 差值法
                X_sel[:, i] = X[:, e[1]] - X[:, e[0]]
            if m_type == 1:  # 和值法
                X_sel[:, i] = X[:, e[1]] + X[:, e[0]]
            if m_type == 2:  # 比值法
                X_sel[:, i] = X[:, e[1]] / (X[:, e[0]] + np.finfo(float).eps)
            if m_type == 3:  # 归一化法
                X_sel[:, i] = (X[:, e[1]] - X[:, e[0]]) / (X[:, e[1]] + X[:, e[0]] + np.finfo(float).eps)

        return X_sel, e_sel, m_type_sel, r_sel

    def calc_combination(self, X, n_sel, e_sel, m_type_sel):
        """
        双波段组合法提取pearson相关系数最优的前几个特征

        params
            X：测试集
            e_sel：选择的双波段名称，[(x2,x1),(x5,x3)]
            m_type_sel：双波段名称对应的组合方法

        return
            X_sel
        """

        X_sel = np.zeros([X.shape[0], n_sel])
        for e, m_type, i in zip(e_sel, m_type_sel, np.arange(n_sel)):
            if m_type == -1:  # 单波段法
                X_sel[:, i] = X[:, e]
            if m_type == 0:  # 差值法
                X_sel[:, i] = X[:, e[1]] - X[:, e[0]]
            if m_type == 1:  # 和值法
                X_sel[:, i] = X[:, e[1]] + X[:, e[0]]
            if m_type == 2:  # 比值法
                X_sel[:, i] = X[:, e[1]] / X[:, e[0]]
            if m_type == 3:  # 归一化法
                X_sel[:, i] = (X[:, e[1]] - X[:, e[0]]) / (X[:, e[1]] + X[:, e[0]])

        return X_sel


if __name__ == "__main__":
    # X = np.random.randint(0, 200, (100, 20))
    # y = np.random.randint(0, 200, 100)
    # print(X.shape, y.shape)

    import pandas as pd
    root = '../../samples/nir'
    s1 = pd.read_csv(f'{root}/1.csv', header=None, names=['position', 'value'], sep='\t')
    print(s1)
    s2 = pd.read_csv(f'{root}/2.csv', header=None, names=['position', 'value'], sep='\t')
    X = np.array([s1['value'].to_numpy(), s2['value'].to_numpy(), s1['value'].to_numpy(), s2['value'].to_numpy(), s1['value'].to_numpy()])
    noise = np.random.random((X.shape[0], X.shape[1]))
    X = X + noise
    X = X[:, 0:100]
    y = np.random.randint(0, 100, X.shape[0])
    print(X.shape, y.shape)

    two_wave_comb = TwoWaveComb()
    n_sel = 3
    X_sel, e_sel, m_type_sel, r_sel = two_wave_comb.two_wave_comb(X, y, n_sel)
    print(X_sel.shape, e_sel.shape, m_type_sel.shape, r_sel.shape)
    print(e_sel, m_type_sel, r_sel)