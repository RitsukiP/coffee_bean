import cv2 as cv
import glob
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.model_selection import cross_val_score, GridSearchCV, train_test_split, cross_val_predict

# 近红外光谱批量预处理(仅用于光谱分析软件)
from gx_spectral.data import data_split
from gx_spectral.preprocess import SPA, hsi_batch
from gx_spectral.preprocess.spectrum import _pre_specs
from gx_spectral.visualization import drawer
from sklearn.svm import SVC, SVR
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.cross_decomposition import PLSRegression

from sklearn.pipeline import make_pipeline

from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

from sklearn.model_selection import train_test_split
from sklearn import metrics
import os


def load_nirs_N1(root, device_type='“NIR-REF-1325'):
    """
    读取N1系列光谱仪的数据集
    @param root: 数据集根目录
    @param device_type: 设备类型，支持“NIR-REF-1325”（默认）和“NIR-FIB-9017”
    @return: specs光谱，names名称，spec_pos光谱波长
    """
    data_fs = sorted(glob.glob(fr'{root}/*.csv'))
    if device_type == 'NIR-REF-1325':
        dfs = []
        df_names = None
        for f in data_fs:
            df = pd.read_csv(f)
            if df_names is None:
                #         统一一下坐标，方便拼接
                df_names = df.columns
            df.columns = df_names
            dfs.append(df)
        data_df = pd.concat(dfs, ignore_index=True)
        # 光谱坐标,最后一列为空
        spec_pos = np.array(data_df.columns[4:-1].values, dtype=float)
        # 转为波长
        spec_pos = 1e7 / (spec_pos)
        specs = np.array(data_df.iloc[0:, 4:-1].values, dtype=float)
        names = data_df['Sample Name'].values.astype(str)
    elif device_type == 'NIR-FIB-9017':
        spec_pos = None
        names = []
        specs = []
        for f in data_fs:
            df = pd.read_csv(f, header=29, names=['pos', 'abs', 'ref', 'sam'])
            if spec_pos is None:
                spec_pos = df['pos'].values
            name = os.path.basename(f)
            # 前缀为命名
            name = name[:name.index('_')] if '_' in name else name[:-4]
            names.append(name)
            specs.append(df['abs'].values)
        specs = np.array(specs)
        names = np.array(names)
    return specs, names, spec_pos


def load_labels(label_f, names):
    """
    读取标签文件
    @param label_f: 标签文件路径
    @param names: 样品名称
    @return: 样品对应的标签
    """
    if label_f.endswith('.xlsx'):
        data_pd = pd.read_excel(label_f, names=['names', 'labels'], header=0).set_index('names')
    elif label_f.endswith('.csv'):
        data_pd = pd.read_csv(label_f, names=['names', 'labels'], header=0, dtype={'names': str}).set_index('names')
    labels = data_pd.loc[names].values.reshape(-1)
    return labels


def batch_preprocess(specs, labels, spec_pos, band_type, bands, pre_methods=[], extra_param={}):
    """
    对数据集的样品进行批量的预处理，返回特征列表(n, features)
    @param specs:array-原始光谱
    @param labels:array-标签
    @param spec_pos:array-光谱波长
    @param band_type:str-波段选择类型，full全波段,self自定义
    @param bands:list-波段范围，当band_type为self时才有效，表示起始和终止
    @param pre_methods:list-光谱预处理方法,包括sg/snv/d1/d2;
    @param extra_param:dict-扩展参数
    @return:特征，标签
    """
    if band_type == 'full':
        features = specs
    elif band_type == 'self':
        features = specs[:, (spec_pos >= bands[0]) & (spec_pos < bands[1])]
        if 'mean_spec' in extra_param:
            mean_sp = extra_param['mean_spec'][(spec_pos >= bands[0]) & (spec_pos < bands[1])]
            extra_param = extra_param.copy()
            extra_param['mean_spec'] = mean_sp
    else:
        raise Exception('PARAM INVALID')
    features = _pre_specs(features, pre_methods, extra_param)
    # if dim_reduction['method'] == 'pca':
    #     pca = PCA(n_components=dim_reduction['num'])
    #     features = pca.fit_transform(features, labels)
    # elif dim_reduction['method'] == 'spa':
    #     gx_spa = SPA.SPA()
    #     X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=10)
    #     n = dim_reduction['num']
    #     if n == 0:
    #         n_min = 2
    #         n_max = 30
    #     else:
    #         n_min = n_max = n
    #     var_sel, var_sel_phase2 = gx_spa.spa(Xcal=X_train, ycal=y_train, m_min=n_min, m_max=n_max, Xval=X_test,
    #                                          yval=y_test)
    #     features = features[:, var_sel]

    return features, labels


def preview_features(features, labels):
    """
    预览光谱特征，返回两张图片，总体光谱图和平均光谱图
    @param features:特征
    @param labels:标签
    @return:总体光谱图，平均光谱图
    """
    spec_pos = np.arange(1, len(features[0]) + 1)
    if labels.dtype == float:
        img1 = drawer.show_specs_regre(spec_pos, features, labels, title='特征预览')
        img2 = img1
    else:
        img1, img2 = drawer.show_specs_class(spec_pos, features, labels, title='特征预览图', title2='平均特征预览')
    return img1, img2


def _fetch_model(task_type, algorithm, dim_reduction={}, alg_param={}):
    models = []
    if dim_reduction['method'] == 'pca':
        pca = PCA(n_components=dim_reduction['num'])
        models.append(pca)
    elif dim_reduction['method'] == 'spa':
        gx_spa = SPA.SpaTransformer(dim_reduction['num'])
        models.append(gx_spa)
    if algorithm == 'SVM':
        models.append(SVR(**alg_param) if task_type == 'regre' else SVC(**alg_param))
    elif algorithm == 'Linear':
        models.append(LinearRegression(**alg_param) if task_type == 'regre' else LogisticRegression(**alg_param))
    elif algorithm == 'RF':
        models.append(
            RandomForestRegressor(**alg_param) if task_type == 'regre' else RandomForestClassifier(**alg_param))
    elif algorithm == 'KNN':
        models.append(
            KNeighborsRegressor(**alg_param) if task_type == 'regre' else KNeighborsClassifier(**alg_param))
    elif algorithm == 'DT':
        models.append(
            DecisionTreeRegressor(**alg_param) if task_type == 'regre' else DecisionTreeClassifier(**alg_param))
    elif algorithm == 'PLS':
        models.append(PLSRegression(**alg_param))
    return make_pipeline(*models)


def generate_model(features, labels, task_type, target_range, split_method, train_ratio, algorithm, dim_reduction={},
                   alg_param={}):
    """
    传入数据和配置参数，生成算法模型,返回模型文件、评估指标等；
    @param features:array-预处理后的数据特征
    @param labels:array-每个特征对应的标签,可以是分类或回归
    @param task_type:str-任务类别,class代表分类,regre代表回归
    @param target_range:list-目标的范围,如果分类，则表示子类别列表,如[1,2,3];如果回归,则表示目标的范围,如[0,50]；
    @param split_method:str-数据划分的方法,支持'Random','KS','SPXY'
    @param train_ratio:float-训练集的比例, 0~1
    @param algorithm:算法模型,支持'SVM','Linear','RF','KNN', 'DT', 'PLS'
    @param dim_reduction:dict-降维配置
                    method字段为降维的方法，支持none,pca,spa,
                    num字段为目标维数;0表示自适应
    @param alg_param:算法模型的参数,以dict形式传入，每个算法支持的参数有一定区别。
    如下所示，格式为{算法模型}:{参数}(中文名,类型,内容)
    SVM:kernel(核函数,str,linear/poly/rbf/sigmoid,默认rbf)
    Linear:无
    RF:n_estimators(树的数量,int,0~200,默认100)
    KNN:n_neighbors‌(K值,int,0~50,默认5),weights‌(权重,str,uniform/distance,默认uniform),algorithm‌(近邻计算,str,auto/ball_tree/kd_tree,默认auto)
    DT:criterion(度量标准,str,poisson/absolute_error/squared_error/friedman_mse,默认squared_error),splitter‌(拆分策略,best/random,默认best)
    PLS:n_components‌(主成分数,int,2~30,默认2),scale‌(缩放,bool,True/False,默认True),max_iter‌(最大迭代次数,int,50~1000,默认500)
    @return:(model, pic, stats)模型，模型指标图，评估指标
    """
    model = _fetch_model(task_type, algorithm, dim_reduction, alg_param)
    if train_ratio >= 1:
        train_ratio = 0.99
    if algorithm == 'PLS' and task_type == 'class':
        # 如果是用PLS进行分类，需要对标签进行转化
        labels = pd.get_dummies(labels)
    if split_method == 'Random':
        X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=(1 - train_ratio),
                                                            random_state=1)
    elif split_method == 'KS':
        X_train, X_test, y_train, y_test = data_split.ks(features, labels, test_size=(1 - train_ratio))
    elif split_method == 'SPXY':
        X_train, X_test, y_train, y_test = data_split.spxy(features, labels, test_size=(1 - train_ratio))
    elif split_method == 'Cross':
        # 交叉验证时，用全部数据训练并返回。评估指标上则用交叉验证的结果
        X_train, X_test, y_train, y_test = features, features, labels, labels
    else:
        raise Exception('Param Invalid')
    model = model.fit(X_train, y_train)
    if split_method == 'Cross':
        y_pred = cross_val_predict(model, features, labels, cv=10)
    else:
        y_pred = model.predict(X_test)
    if algorithm == 'PLS' and task_type == 'class':
        y_pred = np.array([np.argmax(i) for i in y_pred])
    if task_type == 'regre':
        scores = [metrics.r2_score(y_test, y_pred)]
        scores.append(metrics.mean_absolute_error(y_test, y_pred))
        scores.append(metrics.explained_variance_score(y_test, y_pred))
        metric_img = drawer.show_result_regre(y_test, y_pred)
    else:
        scores = [metrics.accuracy_score(y_test, y_pred)]
        scores.append(metrics.precision_score(y_test, y_pred, average='macro'))
        scores.append(metrics.recall_score(y_test, y_pred, average='macro'))
        metric_img = drawer.show_confusion_matrix(y_test, y_pred)[0]
    return model, metric_img, scores


def batch_test(processor, specs, labels, task_type, target_range):
    """
    传入模型和数据，用模型对数据进行测试，输出评估结果
    @param processor: 处理器，包括预处理方法和生成的模型；
    @param specs:array-光谱
    @param labels:array-每个特征对应的标签,可以是分类或回归
    @param task_type:str-任务类别,class代表分类,regre代表回归
    @param target_range:list-目标的范围,如果分类，则表示子类别列表,如[1,2,3];如果回归,则表示目标的范围,如[0,50]；
    @return:(pic, stats)模型，模型指标图，评估指标
    """
    spec_pos, band_type, bands, pre_methods, mean_spec = processor['preprocess']
    model = processor['model']
    features, labels = batch_preprocess(specs, labels, spec_pos, band_type, bands, pre_methods, {'mean_spec': mean_spec})
    scores = [model.score(features, labels)]
    y_pred = model.predict(features)
    if task_type == 'regre':
        scores.append(metrics.mean_absolute_error(labels, y_pred))
        scores.append(metrics.explained_variance_score(labels, y_pred))
        metric_img = drawer.show_result_regre(labels, y_pred)
    else:
        scores.append(metrics.precision_score(labels, y_pred, average='macro'))
        scores.append(metrics.recall_score(labels, y_pred, average='macro'))
        metric_img = drawer.show_confusion_matrix(labels, y_pred)[0]
    return metric_img, scores


def batch_test_new(processor, specs, task_type, target_range):
    """
    传入模型和无标签数据，用模型对数据进行测试，输出预测结果
    @param processor: 处理器，包括预处理方法和生成的模型；
    @param specs:array-光谱
    @param task_type:str-任务类别,class代表分类,regre代表回归
    @param target_range:list-目标的范围,如果分类，则表示子类别列表,如[1,2,3];如果回归,则表示目标的范围,如[0,50]；
    @return:result，预测结果
    """
    spec_pos, band_type, bands, pre_methods, mean_spec = processor['preprocess']
    model = processor['model']
    features, labels = batch_preprocess(specs, None, spec_pos, band_type, bands, pre_methods, {'mean_spec': mean_spec})
    y_pred = model.predict(features)
    return y_pred


if __name__ == '__main__':
    import sklearn

    print(sklearn.__version__)
    # 数据集的根目录，目录树结构需要参照定义的规范来组织
    data_root = 'samples/dataset/regre/nir1325/'
    data_root = 'samples/dataset/class/nir2'
    data_root = '/Users/gordon/data/近红外光谱/原子能所/'
    test_specs, test_names, spec_pos = load_nirs_N1(f'{data_root}/data/test', device_type='NIR-FIB-9017')
    test_labels = load_labels(f'{data_root}/labels.csv', test_names)
    data_root = '/Users/gordon/data/近红外光谱/原子能所/'
    specs, names, spec_pos = load_nirs_N1(f'{data_root}/data/train', device_type='NIR-FIB-9017')
    labels = load_labels(f'{data_root}/labels.csv', names)
    print(specs.shape, spec_pos.shape, )
    label_img = drawer.show_label_dist(labels)
    cv.imshow('标签统计图', label_img)
    cv.waitKey(0)
    spec_img = drawer.show_specs_regre(spec_pos, specs, labels)
    cv.imshow('光谱预览图', spec_img)
    cv.waitKey(0)
    # spec_img = drawer.show_specs_class(spec_pos, specs, labels)[0]
    # cv.imshow('光谱预览图', spec_img)
    # cv.waitKey(0)
    spec_img = drawer.show_specs_regre(spec_pos, specs[10], labels[10])
    cv.imshow('光谱预览图-单个', spec_img)
    cv.waitKey(0)
    # spec_img = drawer.show_specs_class(spec_pos, specs[5], labels[5])[0]
    # cv.imshow('光谱预览图-单个', spec_img)
    # cv.waitKey(0)
    # spec_img = drawer.show_specs_regre(spec_pos, specs[10:20], labels[10:20])
    # cv.imshow('光谱预览图-部分', spec_img)
    # cv.waitKey(0)
    # spec_img = drawer.show_specs_class(spec_pos, specs[:5], labels[:5])[0]
    # cv.imshow('光谱预览图-部分', spec_img)
    # cv.waitKey(0)
    spec_img = drawer.show_dimension_reduction(specs[:20], labels[:20], 1)
    cv.imshow('光谱特征图-部分', spec_img)
    cv.waitKey(0)
    spec_img = drawer.show_dimension_reduction(specs, labels, 1)
    cv.imshow('光谱特征图-全部', spec_img)
    cv.waitKey(0)
    # 回归
    band_type = 'self'
    bands = [1900, 2100]
    pre_methods = ['sg', 'msc']
    dim_reduction = {'method': 'none', 'num': 3}
    features, labels = batch_preprocess(specs[:], labels[:], spec_pos, band_type, bands, pre_methods)
    # features, labels = batch_preprocess(specs[:], labels[:], spec_pos, 'full', [], ['sg'],
    #                                     {'method': 'pca', 'num': 5})
    print('预处理后：', features.shape, labels.shape)
    # np.save('sample-features.npy', features)
    # np.save('sample-labels.npy', labels)
    # features = np.load('sample-features.npy')
    # labels = np.load('sample-labels.npy')
    # print(len(features), len(labels))
    imgs = preview_features(features, labels)
    cv.imshow('特征预览', imgs[0])
    cv.waitKey(0)
    cv.imshow('特征预览', imgs[1])
    cv.waitKey(0)

    # 分类
    # model, img, scores = generate_model(features, labels, 'class', ['a', 'b'], 'Random', 0.8, 'SVM')
    # 回归
    model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'PLS', dim_reduction,
                                        {'n_components': 5})
    print(f'scores: {scores}')
    # 将预处理和模型的信息字典保存到本地
    mean_spec = np.mean(specs, axis=0)
    processor = {'preprocess': (spec_pos, band_type, bands, pre_methods, mean_spec), 'model': model}
    img, scores = batch_test(processor, test_specs, test_labels, 'regre', [0, 100])
    print(scores)
    result = batch_test_new(processor, test_specs, 'regre', [0, 100])
    print(result)
    cv.imshow('img', img)
    cv.waitKey(0)

    # features, labels = batch_preprocess(specs[:], labels[:], spec_pos, 'self', [1867, 2019], ['sg' , 'msc'])
    # model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'PLS', {'method': 'spa', 'num': 0}, {'n_components': 2})
    # print(f'scores: {scores}')
    # model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'PLS', {'method': 'spa', 'num': 3}, {'n_components': 2})
    # print(f'scores: {scores}')
    # features, labels = batch_preprocess(specs[:], labels[:], spec_pos, band_type, bands, pre_methods)
    # model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'KNN', dim_reduction, {'n_neighbors': 3, 'weights': 'uniform', 'algorithm': 'auto'})
    # model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'DT', dim_reduction, {'criterion': 'squared_error', 'splitter': 'best'})
    # model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'SVM', dim_reduction, {'kernel': 'linear'})
    # model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'Linear', dim_reduction, {})
    # model, img, scores = generate_model(features, labels, 'regre', [0, 100], 'Cross', 1, 'RF', dim_reduction, {'n_estimators': 10})
    #
    # print('result: ', model, scores)
    # cv.imshow('img', img)
    # cv.waitKey(0)
    # import joblib
    # joblib.dump(processor, 'sample-model0.m')
    # # 加载模型
    # processor = joblib.load('sample-model0.m')
    # print(processor)
    # img, scores = batch_test(processor, specs, labels, 'regre', [0, 100])
    # print(scores)
    # cv.imshow('img', img)
    # cv.waitKey(0)
    # # 测试未知样品
    # result = batch_test_new(processor, specs, 'regre', [0, 100])
    # print(result)
    # img, scores = batch_test(processor, features, labels, 'class', [0, 20])
