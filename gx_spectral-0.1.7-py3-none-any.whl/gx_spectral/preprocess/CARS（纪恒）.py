import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib import font_manager as fm, rcParams
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
import copy
from numpy.linalg import matrix_rank as rank

data = pd.read_csv('.\TP.csv',header=None)
data=data.iloc[1:,1:]
name=['sample{}'.format(i+1) for i in range(data.shape[0])]
column_name=[i+1 for i in range(data.shape[1]-1)]
y=np.array(data)[:,-1] #浓度
#print(data.columns)
data_feature = pd.DataFrame(np.array(data)[:,:-1], index=name, columns=column_name) #去除最后一列

def CARS1_Cloud(X, y, N=50, f=20, cv=10): #总计N次采样
    p = 0.8
    m, n = X.shape                      #m：样品个数； n：特征维度
    u = np.power((n/2), (1/(N-1)))     #衰减系数a
    k = (1/(N-1)) * np.log(n/2)       #指数衰减系数k
    cal_num = np.round(m * p)
    # val_num = m - cal_num
    b2 = np.arange(n)                 #输出等差列表，from【0】，to【n_feature-1】
    x = X.copy()
    D = np.vstack((np.array(b2).reshape(1, -1), X))  #堆叠行，shape=【n_sample,n_feature+1】
    WaveData = []
    # Coeff = []
    WaveNum =[]
    RMSECV = []
    r = []
    COEF=[]
    count=[]
    for i in range(1, N+1):
        r.append(u*np.exp(-1*k*i))          #指数衰减函数，用于删减波长
        wave_num=int(np.round(r[i-1]*n))
        WaveNum.append(wave_num)
    for i in range(1, N+1):
        cal_index = np.random.choice    \
                (np.arange(m), size=int(cal_num), replace=False)  #随机抽取样本
        if i==1:  #步数1不筛选波长
            wave_num = WaveNum[i-1]  #某步剩下的波长数
            WaveNum = np.hstack((WaveNum, wave_num)) #所有步数对应的波长数目列表
            wave_index = b2[:wave_num].reshape(1, -1)[0]
            xcal = x.iloc[cal_index,:] #随机抽取样本
            #xcal = xcal[:,wave_index].reshape(-1,wave_num)
            ycal = y[cal_index]                                 #y也用相同的随机索引抽取
            count.append(data_feature.columns.values)
        else:     #从步数2开始筛选波长
            wave_num_now = WaveNum[i-1]  #某步对应的波长数
            wave_num_pre = WaveNum[i-2]  #上一步对应的波长数
            del_number=wave_num_pre-wave_num_now  #应该删去的波长数目
            liebiao=[i[0] for i in b2[:del_number]]
            #x=np.delete(x,b2[:del_number],1)      #删去相关系数小的波长，构造新的特征矩阵
            p=x.copy()
            count.append(p.drop(x.columns[liebiao], axis=1).columns.values) #列名
            x=x.drop(x.columns[liebiao], axis=1) #新的特征矩阵
            #print(b2[:del_number])
            #count.append(data.drop(data.columns[b2[:del_number]], axis=1).columns.values)
            #p=p.drop(p.columns[b2[:del_number]])
            xcal = x.iloc[cal_index,:]
            ycal = y[cal_index]
        #f = min([f, rank(x)])   #主成分数不能超过矩阵的特征数
        RMSECV.append(Cross_Validation(xcal,ycal,f,10)) #保存交叉验证的RMSECV数值
        pls = PLSRegression(n_components=f) #设定PLSR主成分
        pls.fit(xcal, ycal)                 #拟合回归
        beta = pls.coef_                    #输出系数
        b = np.abs(beta)                    #绝对值比较大小
        COEF.append(beta.reshape(-1))
        b2 = np.argsort(b, axis=0).tolist()         #所有元素从小到大排列
        coef = copy.deepcopy(beta)
    return COEF,count,x,RMSECV

def Cross_Validation(X, y, pc, cv):
    '''
    x :光谱矩阵 nxm
    y :浓度阵 （化学值）
    pc:最大主成分数
    cv:交叉验证数量
    return :
    RMSECV:各主成分数对应的RMSECV
    '''
    X=np.array(X)
    #pc = min([pc, rank(X)])
    #print(rank(X))
    pc=pc
    kf = KFold(n_splits=cv)
    RMSE = []
    for train_index, test_index in kf.split(X):
        x_train, x_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        pls = PLSRegression(n_components=pc)
        pls.fit(x_train, y_train)
        y_predict = pls.predict(x_test)
        RMSE.append(np.sqrt(mean_squared_error(y_test, y_predict)))
    RMSE_mean = np.mean(RMSE)
    return RMSE_mean

coef,count,x,rmse=CARS1_Cloud(data_feature,y)
arr = np.zeros((50,data.shape[1]-1))
out_coef_matrix = pd.DataFrame(arr,columns=column_name)  #初始化零矩阵
Normalization=out_coef_matrix.copy()
for i in range(50):#生成PLSR回归系数矩阵
    out_coef_matrix.iloc[i,[i-1 for i in count[i]]]=coef[i]
#归一化至【-1，1】之间
for i in range(50):
    aver=np.sum(np.abs(out_coef_matrix.iloc[i,:]))
    Normalization.iloc[i,:]=(out_coef_matrix.iloc[i,:]/aver) #输出归一化矩阵

x_number=np.linspace(0,50)
label=Normalization.columns.tolist()
number_of_sample=[]
for i in count:
    number_of_sample.append(len(i))
plt.figure(figsize=(8, 6), dpi=200)
plt.rcParams['font.sans-serif'] = ['SimHei']  # 输入中文
plt.rcParams['axes.unicode_minus'] = False
ax1 = plt.subplot(3,1,3)
for i in range(Normalization.shape[1]):
    ax1.plot(x_number,Normalization.iloc[:,i],label='band{}'.format(label[i]))
min_number = np.argsort(rmse)[0]
ax1.vlines(min_number,0.5,-0.5, color='black', linestyle='dashed')
plt.grid()
#plt.legend()
plt.ylabel('Regression coefficients path')
plt.xlabel('Number of sampling runs')
ax2 = plt.subplot(3,1,1)
ax2.plot(x_number,number_of_sample)
plt.ylabel('Number of sampled variables')
plt.xlabel('Number of sampling runs')
plt.xticks(range(0,55,5))
ax3 = plt.subplot(3,1,2)
ax3.plot(x_number,rmse)
ax3.vlines(min_number,0,2, color='black', linestyle='dashed')
plt.ylabel('RMSECV')
plt.xlabel('Number of sampling runs')
plt.xticks(range(0,55,5))
plt.tight_layout()
plt.show()
print(count)
