import numpy as np
import sklearn
from scipy.signal import savgol_filter
import pandas as pd


# 多元散射校正,Multiplicative Scatter Correction
def msc(ori_specs, me=None):
    """多元散射校正
    对多个光谱数据进行多元散射校正，理想光谱默认采用的是平均光谱
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @param me: Numpy数组,平均光谱,形状为[spec]
    @return: 多元散射校正后的光谱
    """
    if me is None:
        me = np.mean(ori_specs, axis=0)
    [m, p] = np.shape(ori_specs)
    msc_specs = np.zeros((m, p))
    for i in range(m):
        poly = np.polyfit(me, ori_specs[i], 1)  # 每个样本做一次一元线性回归
        for j in range(p):
            msc_specs[i, j] = (ori_specs[i, j] - poly[1]) / poly[0]
    return msc_specs


# 标准正态化,Standard Normal Variate
def snv(ori_specs):
    """标准正态化
    对多个光谱数据进行标准正态化校正，理想光谱采用的是平均光谱
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @return: 标准正态变化后的光谱
    """
    # Define v0.1.1-a new array and populate it with the corrected data
    snv_specs = np.zeros_like(ori_specs)
    for i in range(ori_specs.shape[0]):
        # Apply correction
        snv_specs[i, :] = (ori_specs[i, :] - np.mean(ori_specs[i, :])) / np.std(ori_specs[i, :])
    return snv_specs


def CT(data):  # 均值中心化
    """
    对光谱进行去平均值的中心化
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @return: 均值中心化后的光谱
    """
    for i in range(data.shape[1]):
        MEAN = np.mean(data[:, i])
        data[:, i] = data[:, i] - MEAN
    return data


# 移动平均平滑
def MA(data, WSZ=11):
    """
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @param WSZ: int，默认11
    @return: 移动平均平滑后的光谱
    """
    for i in range(data.shape[0]):
        out0 = np.convolve(data[i], np.ones(WSZ, dtype=int), 'valid') / WSZ  # WSZ是窗口宽度，是奇数
        r = np.arange(1, WSZ - 1, 2)
        start = np.cumsum(data[i, :WSZ - 1])[::2] / r
        stop = (np.cumsum(data[i, :-WSZ:-1])[::2] / r)[::-1]
        data[i] = np.concatenate((start, out0, stop))
    return data


def SG(data, w=11, p=2):  # SG平滑
    """
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @param W: int，奇数，默认11
    @param p: int，默认2
    @return: SG平滑后的光谱,参数w，参数p
    """
    return savgol_filter(data, w, p)


def D1(data):  # 一阶导数
    """
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @return: 取一阶导数后的光谱，形状为[n, spec-1]
    """
    n, p = data.shape
    Di = np.ones((n, p - 1))
    for i in range(n):
        Di[i] = np.diff(data[i])
    return Di


def D2(data):  # 二阶导数
    """
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @return: 取一阶导数后的光谱，形状为[n, spec-2]
    """
    from copy import deepcopy
    data = deepcopy(data)
    if isinstance(data, pd.DataFrame):
        data = data.values
    temp2 = (pd.DataFrame(data)).diff(axis=1)
    temp3 = np.delete(temp2.values, 0, axis=1)
    temp4 = (pd.DataFrame(temp3)).diff(axis=1)
    spec_D2 = np.delete(temp4.values, 0, axis=1)
    return spec_D2


def wave(data, para='db8'):
    """
    @param ori_specs: Numpy数组,原始光谱,形状为[n, spec]
    @param 小波选项，默认'db8'
    @return: 小波变换后的光谱，形状为[n, spec]
    """
    from copy import deepcopy
    import pywt
    import pandas as pd
    data = deepcopy(data)
    if isinstance(data, pd.DataFrame):
        data = data.values

    def wave_(data):  # 小波变换
        # 包括db,sym,coif,bior,rbio,dmey族等
        w = pywt.Wavelet(para)  # 选用Daubechies8小波，应该改成可选的
        maxlev = pywt.dwt_max_level(len(data), w.dec_len)
        coeffs = pywt.wavedec(data, para, level=maxlev)
        threshold = 0.04
        for i in range(1, len(coeffs)):
            coeffs[i] = pywt.threshold(coeffs[i], threshold * max(coeffs[i]))
        datarec = pywt.waverec(coeffs, para)
        return datarec

    tmp = None
    for i in range(data.shape[0]):
        if (i == 0):
            tmp = wave_(data[i])
        else:
            tmp = np.vstack((tmp, wave_(data[i])))

    return tmp


def DT(data):  # 去趋势校正,需要sklearn包
    lenth = data.shape[1]
    x = np.asarray(range(lenth), dtype=np.float32)
    out = np.array(data)
    l = sklearn.linear_model.LinearRegression()
    for i in range(out.shape[0]):
        l.fit(x.reshape(-1, 1), out[i].reshape(-1, 1))
        k = l.coef_
        b = l.intercept_
        for j in range(out.shape[1]):
            out[i][j] = out[i][j] - (j * k + b)
    return out


def _pre_specs(specs, methods, extra_param={}):
    if 'sg' in methods:
        specs = SG(specs)
    if 'msc' in methods:
        me = extra_param['mean_spec'] if 'mean_spec' in extra_param else None
        specs = msc(specs, me)
    if 'snv' in methods:
        specs = snv(specs)
    if 'D1' in methods:
        specs = D1(specs)
    if 'D2' in methods:
        specs = D2(specs)
    if 'ct' in methods:
        specs = CT(specs)
    if 'ma' in methods:
        specs = MA(specs)
    if 'dt' in methods:
        specs = DT(specs)
    if 'wave' in methods:
        specs = wave(specs)
    return specs


if __name__ == '__main__':
    root = '../../samples/nir'
    # root = '../samples/nir' 相对路径往上两级
    s1 = pd.read_csv(f'{root}/1.csv', header=None, names=['position', 'value'], sep='\t')
    print(s1)
    s2 = pd.read_csv(f'{root}/2.csv', header=None, names=['position', 'value'], sep='\t')
    specs = np.array([s1['value'].to_numpy(), s2['value'].to_numpy()])
    print(specs.shape)
    msc_specs = msc(specs)  # 多元散射校正
    print(msc_specs.shape)
    snv_specs = snv(specs)  # 标准正态变换
    print(snv_specs.shape)
    CT_specs = CT(specs)  # 均值中心化
    print(CT_specs.shape)
    MA_specs = MA(specs, WSZ=11)  # 移动平均平滑
    print(MA_specs.shape)
    SG_specs = SG(specs, w=11, p=2)  # SG平滑
    print(SG_specs.shape)
    D1_specs = D1(specs)  # 一阶导数
    print(D1_specs.shape)
    D2_specs = D2(specs)  # 二阶导数
    print(D2_specs.shape)
    # DT_specs = DT(specs)          # 去趋势校正
    # print(DT_specs.shape)
    wave_specs = wave(specs, 'db8')  # 小波变换
    print(wave_specs.shape)
