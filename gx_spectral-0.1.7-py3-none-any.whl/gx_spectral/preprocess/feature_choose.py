import numpy as np
import os
import statsmodels.api as sm
import statsmodels.formula.api as smf
import random
from scipy.stats import pearsonr
from pyswarms.single.global_best import GlobalBestPSO
from genetic_selection import GeneticSelectionCV
from sklearn import linear_model

def make_data(feature,nongdu,name,number=0):
    '''
    通过特征和浓度制表
    输入：feature,numpy,[sample,feature]
    输入：nongdu,numpy,[sample,feature]
    输入：name，numpy,[sample,test_quality_number]
    输入：number，int,待测物质
    '''
    d = {}                 #生成列名
    for i in range(feature.shape[1]):
        d['x' + str(i)] = i
    df=pd.DataFrame(feature,index=name)
    df.columns=d.keys()
    df['y']=nongdu[:,number]
    return df


class huigui(object):  # 创建Circle类
    def __init__(self, df):  # 初始化一个属性r（不要忘记self参数，他是类下面所有方法必须的参数）
        self.df = df  # 表示给我们将要创建的实例赋予属性r赋值
        self.variate = None
        self.x = None
        self.variate_add = None
        self.variate_del = None

    def shaixuanji(self, number):
        '''
        初始化添加集和删除集
        '''
        target = 'y'
        variate = self.df.columns.to_list()  # 获取列名
        variate.remove(target)  # 去除无关列
        x = []
        variate_add = []
        variate_del = variate.copy()
        # print(variate_del)
        y = random.sample(variate, number)  # 随机生成一个选模型，3为变量的个数
        # print(y)
        for i in y:
            variate_add.append(i)  # 提取出的特征波段
            x.append(i)
            variate_del.remove(i)  # 已将上面的特征波段消去的剩余波段
        # print(variate_del)
        return x, variate, variate_add, variate_del

    # 添加变量
    def forwark(self):
        '''
        添加变量
        '''
        score_add = []
        global best_add_score
        global best_add_c
        print("添加变量")
        for c in self.variate_del:
            formula = "{}~{}".format("y", "+".join(self.variate_add + [c]))
            score = smf.ols(formula=formula, data=self.df).fit().aic
            score_add.append((score, c))  # 将添加的变量，以及新的AIC值一起存储在数组中

            print('自变量为{}，对应的AIC值为：{}'.format("+".join(self.variate_add + [c]), score))

        score_add.sort(reverse=True)  # 对数组内的数据进行排序，选择出AIC值最小的
        best_add_score, best_add_c = score_add.pop()

        print("最小AIC值为：{}".format(best_add_score))
        print("\n")

    def back(self):
        '''
        删除变量
        '''
        score_del = []
        global best_del_score
        global best_del_c
        print("剔除变量")
        for i in self.x:
            select = self.x.copy()  # copy一个集合，避免重复修改到原集合
            select.remove(i)
            formula = "{}~{}".format("y", "+".join(select))
            score = smf.ols(formula=formula, data=self.df).fit().aic
            print('自变量为{}，对应的AIC值为：{}'.format("+".join(select), score))
            score_del.append((score, i))

        score_del.sort(reverse=True)  # 排序，方便将最小值输出
        best_del_score, best_del_c = score_del.pop()  # 将最小的AIC值以及对应剔除的变量分别赋值
        print("最小AIC值为：{}".format(best_del_score))
        print("\n")

    def zhubuhuigui(self, MAX, MIN):
        df = self.df
        x = self.x
        variate = self.variate
        variate_add = self.variate_add
        variate_del = self.variate_del
        global aic  # 设置全局变量 这里选择AIC值作为指标
        formula = "{}~{}".format("y", "+".join(variate_add))
        aic = smf.ols(formula=formula, data=df).fit().aic
        print("随机化选模型为：{}~{}，对应的AIC值为：{}".format("y", "+".join(variate_add), aic))
        print("\n")
        print("剩余变量为：{}".format(variate_del))
        self.forwark()
        self.back()
        while variate:
            if len(variate_add) > MAX:
                print("当前回归方程为最优回归方程，为{}~{}，AIC值为：{}".format("y", "+".join(variate_add), aic))
                break
            if len(variate_add) < MIN:
                print("当前回归方程为最优回归方程，为{}~{}，AIC值为：{}".format("y", "+".join(variate_add), aic))
                break
            if (aic < best_add_score < best_del_score or aic < best_del_score < best_add_score):
                print("当前回归方程为最优回归方程，为{}~{}，AIC值为：{}".format("y", "+".join(variate_add), aic))
                break
            elif (best_add_score < best_del_score < aic or best_add_score < aic < best_del_score):
                print("目前最小的aic值为{}".format(best_add_score))
                print('选择自变量：{}'.format("+".join(variate_add + [best_add_c])))
                print('\n')
                variate_del.remove(best_add_c)
                variate_add.append(best_add_c)
                x.append(best_add_c)
                print("剩余变量为：{}".format(variate_del))
                aic = best_add_score
                self.forwark()
                self.back()

            else:
                print('当前最小AIC值为：{}'.format(best_del_score))
                print('需要剔除的变量为：{}'.format(best_del_c))
                aic = best_del_score  # 将AIC值较小的选模型AIC值赋给aic再接着下一轮的对比
                x.remove(best_del_c)  # 在原集合上剔除选模型所对应剔除的变量
                variate_add.remove(best_del_c)
                variate_del.append(best_del_c)
                self.forwark()
                self.back()
        return best_add_score, variate_add



if __name__ == '__main__':
    import pandas as pd
    root = '../../samples/nir'
    #root = '../samples/nir' 相对路径往上两级
    s1 = pd.read_csv(f'{root}/1.csv', header=None, names=['position', 'value'], sep='\t')
    #print(s1)
    s2 = pd.read_csv(f'{root}/2.csv', header=None, names=['position', 'value'], sep='\t')
    specs = np.array([s1['value'].to_numpy(), s2['value'].to_numpy()])
    #print(specs.shape)
    nongdu=np.array([[1,4],[2,7]])             #测试用浓度
    print(nongdu.shape)
    name=np.array(['js01_', 'js02_'])
    print(name.shape)

    #逐步回归法 ,不建议太多特征，计算缓慢
    df = make_data(specs[:, 0:20], nongdu, name)  # 制表
    z_method=huigui(df)
    z_method.x, z_method.variate, z_method.variate_add, z_method.variate_del = z_method.shaixuanji(6)
    #print(z_method.x,z_method.variate,z_method.variate_add,z_method.variate_del)
    score, z_selection = z_method.zhubuhuigui(10, 3)  #score:赤池信息评分；z_selection：特征标签 #逐步回归

    #粒子群算法
    particles = 20                    # 设定粒子数，设定各维度边界，设定待处理特征数
    dimension = len(specs[0])      # 特征维数,此处接逐步回归算法的test
    x_max = [1] * len(specs[0])
    x_min = [-1] * len(specs[0])
    bounds = (x_min, x_max)
    print(len(x_max),len(x_min))
    def SelfDefinedFunc(x):  # 最优化函数，输出列表中元素个数与粒子数等同，最后将输出最优值对应的粒子位置，即最小值
        Sum = []
        for i in range(particles):
            j = x[i, :] * specs
            ero=-pearsonr((j[:,0]+j[:,1]+j[:,2]+j[:,3]+j[:,4]+j[:,5]),y)[0]   #皮尔森相关系数，由于该函数取变化的最小值，所以取负相关系数
            ero = -pearsonr(np.sum(j, axis=1), nongdu[:,0])[0]
            ero=pearsonr(k,y)
            Sum.append(ero)
        return Sum
    options = {'c1': 0.5, 'c2': 0.3, 'w': 0.9}  # 粒子群算法的参数
    optimizer = GlobalBestPSO(n_particles=particles, dimensions=dimension, options=options, bounds=bounds)
    # now run the optimization, pass a=1 and b=100 as a tuple assigned to args
    cost_lizi, pos_lizi = optimizer.optimize(SelfDefinedFunc, iters=500)  # a就是自定义函数的参数
    print(cost_lizi, pos_lizi)
    print(pos_lizi.shape)

    #遗传算法
    test = np.concatenate((specs, specs), axis=0)     #cv分割不够
    estimator_lin = linear_model.LinearRegression()
    selector_yichuan = GeneticSelectionCV(estimator_lin,cv=5)
    selector_yichuan = GeneticSelectionCV(estimator_lin, cv=2, scoring="r2",
    max_features=6,  n_jobs=1, n_population=300,crossover_proba=0.5, mutation_proba=0.2, n_generations=40,)
    selector_yichuan = selector_yichuan.fit(test, [1,12,3,9])
    print(selector_yichuan.support_)   #筛选掩膜
    print('有效变量的数量：', selector_yichuan.n_features_)
    print(selector_yichuan.generation_scores_)



