import cv2
import numpy as np

from gx_spectral.config import constant

"""
图像配准,采用orb算法
"""


def _homomorphic_filter(src, d0=2, r1=1.0, rh=2.0, c=4, h=2.0, l=0.5):
    """
    同态滤波,增强图像亮度
    :param src:
    :param d0:
    :param r1:
    :param rh:
    :param c:
    :param h:
    :param l:
    :return:
    """
    # 图像灰度化处理
    gray = src.copy()
    if len(src.shape) > 2:  # 维度>2
        gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)

    # 图像格式处理
    gray = np.float64(gray)
    # print(gray.dtype)
    # print(gray.max(), gray.min())

    # 对数域
    gray = np.log(gray + 1.0)
    gray = gray / np.log(256)  # 归一化
    # print(gray.max(), gray.min())

    # 傅里叶变换
    gray_fft = np.fft.fft2(gray)
    gray_fftshift = np.fft.fftshift(gray_fft)

    # arange函数用于创建等差数组
    rows, cols = gray.shape
    M, N = np.meshgrid(np.arange(-cols // 2, cols // 2),
                       np.arange(-rows // 2, rows // 2))  # 注意，//就是除法

    # 频率域滤波
    D = np.sqrt(M ** 2 + N ** 2)
    Z = (rh - r1) * (1 - np.exp(-c * (D ** 2 / d0 ** 2))) + r1  # filter
    dst_fftshift = Z * gray_fftshift
    # dst_fftshift = (h - l) * dst_fftshift + l

    # 傅里叶反变换（之前是正变换，现在该反变换变回去了）
    dst_ifftshift = np.fft.ifftshift(dst_fftshift)
    dst_ifft = np.fft.ifft2(dst_ifftshift)

    # 选取元素的模
    dst = np.abs(dst_ifft)
    # print(dst.min(), dst.max())

    # 对数反变换
    dst = np.exp(dst) - 1
    # print(dst.min(), dst.max())
    dst = (dst - dst.min()) / (dst.max() - dst.min())  # 归一化
    # print(dst.min(), dst.max())
    dst *= 255
    # print(dst.min(), dst.max())

    # dst中，比0小的都会变成0，比255大的都变成255
    # uint8是专门用于存储各种图像的（包括RGB，灰度图像等），范围是从0–255
    dst = np.uint8(np.clip(dst, 0, 255))
    return dst


# 根据算法创建对应的特征检测器
def _kp_detect(image):
    # gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray_image = image.copy()
    gray_image = _homomorphic_filter(gray_image)
    gray_image = cv2.GaussianBlur(gray_image, (5, 5), 0)
    detector = cv2.ORB_create()
    # 尝试用cv2.xfeatures2d.FREAK_create()
    kp, des = detector.detectAndCompute(gray_image, None)
    kp_image = cv2.drawKeypoints(gray_image, kp, None)
    if len(kp) < 4:
        print('Detected key points is too few')
    # cv_show('kpimg',kp_image)
    return kp_image, kp, des


# 特征匹配
def _BF_feature_match(des1, des2):
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = matcher.match(des1, des2)
    matches = sorted(matches, key=lambda x: x.distance)
    numGoodMatches = int(len(matches) * 0.7)
    matches = matches[:numGoodMatches]
    return matches


def _flann_feature_match(des1, des2):
    if des1.dtype != cv2.CV_32F:
        des1 = np.array(des1, dtype='float32')
    if des2.dtype != cv2.CV_32F:
        des2 = np.array(des2, dtype='float32')
    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)  # or pass empty dictionary
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(des1, des2, k=2)

    # Need to draw only good matches, so create v0.1.1-a mask
    matchesMask = [[0, 0] for i in range(len(matches))]

    for i, (m, n) in enumerate(matches):
        if m.distance < 0.8 * n.distance:
            matchesMask[i] = [1, 0]
    draw_params = dict(matchColor=(0, 255, 0),
                       singlePointColor=(255, 0, 0),
                       matchesMask=matchesMask,
                       flags=0)

    goodmatch = []
    for m, n in matches:
        if m.distance < 0.8 * n.distance:
            goodmatch.append(m)
    return goodmatch, np.array(matchesMask)


def _judge_kp(kp1, kp2):
    if kp1 is None:
        homo1 = np.array([[1, 0, 0],
                          [0, 1, 0],
                          [0, 0, 1]])
    elif kp1.__len__() < 4:
        x1 = 0
        y1 = 0
        x2 = 0
        y2 = 0
        for i in range(kp1.__len__()):
            x1 = x1 + kp1[i][0]
            y1 = y1 + kp1[i][1]
            x2 = x2 + kp2[i][0]
            y2 = y2 + kp2[i][1]
        x1 = x1 / kp1.__len__()
        x2 = x2 / kp1.__len__()
        y1 = y1 / kp1.__len__()
        y2 = y2 / kp1.__len__()
        dx = x2 - x1
        dy = y2 - y1

        homo1 = np.array([[1, 0, dx],
                          [0, 1, dy],
                          [0, 0, 1]])
    else:
        homo1, mask1 = cv2.findHomography(np.array(kp2), np.array(kp1), cv2.RANSAC, ransacReprojThreshold=4)

    # print('kp1 size: '+str(kp1.__len__()))

    return homo1


# 图像对齐
def _image_alignment(img1, img2):
    _, kp1, des1 = _kp_detect(img1)
    _, kp2, des2 = _kp_detect(img2)

    matches = _BF_feature_match(des1, des2)
    # matches,matchesMask = flann_feature_match(des1, des2)
    # print(len(matches))

    match_img = cv2.drawMatches(img1, kp1, img2, kp2, matches, None, flags=2)
    # cv_show('match_img', match_img)

    points1 = np.zeros((len(matches), 2), dtype=np.float32)
    points2 = np.zeros((len(matches), 2), dtype=np.float32)

    for i, match in enumerate(matches):
        points1[i, :] = kp1[match.queryIdx].pt
        points2[i, :] = kp2[match.trainIdx].pt

    # H, status = cv2.findHomography(points1, points2, cv2.RANSAC, ransacReprojThreshold=4)
    H = _judge_kp(points1, points2)
    # 其中H为求得的单应性矩阵,status则返回一个列表来表征匹配成功的特征点。
    # ptsA,ptsB为关键点
    # cv2.RANSAC, ransacReprojThreshold这两个参数与RANSAC有关
    imgOut = cv2.warpPerspective(img2, H, (img1.shape[1], img1.shape[0]),
                                 flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP)
    return imgOut, H


# 调用上述函数进行图像配准,传入png路径

def registration(ori_images, device_type=constant.DEVICE_TYPE_UNISPEC):
    """多光谱配准
    传入若干通道的图像，使用特征匹配的方式分别与第一张图片进行配准对齐
    Args:
        ori_images(np.array):原始图片，形状为(h,w,ch)
        device_type(int):设备类型
    Returns:
        res_images(np.array):配准后的图片，形状为(h,w,ch)
    """
    # 定义两个三维矩阵，分别用于存储配准后和配准前的图像
    res_img = np.zeros_like(ori_images, np.uint8)
    res_img[:, :, 0] = ori_images[:, :, 0]
    for i in range(1, ori_images.shape[2]):
        result, _ = _image_alignment(ori_images[:, :, 0], ori_images[:, :, i])
        res_img[:, :, i] = result
    # 用于对比配准前后图像差异
    # original = show_img = img1
    # for i in range(1, len(datanames)):
    #     original = cv2.addWeighted(original, 0.5, ori_img[:, :, i], 0.5, 0)
    #     show_img = cv2.addWeighted(show_img, 0.5, res_img[:, :, i], 0.5, 0)
    # cv2.imshow('original', original)
    # cv2.imshow('result', show_img)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    # for i in range(10):
    #     plt.imshow(ori_img[:,:,i],cmap='gray')
    # plt.show()
    # for i in range(10):
    #     plt.imshow(res_img[:,:,i],cmap='gray')
    # plt.show()

    # 保存配准后的10张图
    # for i in range(10):
    #     write_path = '../data/Multispectral jitter data/duiqi_png/'+str(i)+'.png'
    #     cv2.imwrite(write_path,res_img[:,:,i])
    #     print('done')

    # 返回存储对准后的10张图片的三维numpy矩阵，shape:(10, 1024,1280)
    return res_img


if __name__ == '__main__':
    from gx_spectral.utils import samples

    images = samples.read_unispec_sample()
    res = registration(images)
    for i in range(res.shape[2]):
        cv2.imwrite(f'../../tmp/{i}.png', res[:, :, i])
