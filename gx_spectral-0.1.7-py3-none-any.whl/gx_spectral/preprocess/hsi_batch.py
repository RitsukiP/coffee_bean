# 高光谱图像批量预处理(仅用于光谱分析软件)
# 包括如下相关配置:
# 配准registration, 标准化normalization, 裁剪cropping
# ROI类型roi_type, 纹理特征texture,
import glob
import os
import numpy as np
from gx_spectral.feature import roi
from gx_spectral.feature import spectrum as gx_spectrum
from gx_spectral.preprocess import spectrum as gx_preprocess
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.svm import SVC, SVR
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn import metrics

import cv2 as cv

from spectral import spectral

from gx_spectral.preprocess import normalization
from gx_spectral.preprocess.spectrum import _pre_specs
from gx_spectral.visualization import drawer


def _get_thresh_roi(msi, thresh):
    # 获取阈值分割后的roi
    img = msi[:, :, 2]
    mask = roi.seg_thresh(img, thresh)
    contours, hierarchy = cv.findContours(mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    preview_img = (img / img.max() * 255).astype(np.uint8)
    preview_img = cv.cvtColor(preview_img, cv.COLOR_GRAY2BGR)
    roi_masks = []
    for cont in contours:
        perimeter = cv.arcLength(cont, True)
        if perimeter < 100:
            # 过滤过小的单位
            continue
        approx = cv.approxPolyDP(cont, 0.02 * perimeter, True)  # 获取轮廓角点坐标
        if len(approx) == 4:
            # 矩形区域认为是白板
            continue
        roi_mask = np.zeros_like(np.squeeze(img))
        bx, by, bw, bh = cv.boundingRect(cont)
        cv.drawContours(roi_mask, [cont], 0, (255, 255, 255), -1)
        cv.drawContours(preview_img, [cont], 0, (0, 0, 255), 3)
        roi_masks.append((roi_mask.astype(bool), (bx, by, bw, bh)))
    return roi_masks, preview_img


def batch_preprocess(data_root, label_file, norm_mode, roi_param, features=['spec', 'texture'], pre_methods=[],
                     dim_reduction={}):
    """
    对数据集的样品进行批量的预处理，返回特征列表(n, features)
    @param data_root:str-数据集根目录
    @param label_file:str-标签文件路径
    @param norm_mode:int-标准化方法，1表示小白板同步(白板和样品一起拍摄)，2表示大白板分步(白板和样品分开拍摄),3表示小白板分步;
    @param roi_param:dict-roi的参数字典.
                    method字段为ROI提取方法,'fix'为固定区域,'thresh'为阈值分割；
                    rect字段为矩形ROI的坐标,int数组,格式为(x,y,w,h),method为fix才有效；
                    thresh字段为分割的阈值,int类型,method为thresh才有效；
    @param features:list-特征的内容,包括光谱spec和纹理texture
    @param pre_methods:list-光谱预处理方法,包括msc、snv等
    @param dim_reduction:dict-降维配置
                    method字段为降维的方法，支持none,pca；
                    num字段为目标维数;
    @return:特征列表，类型为float，形状为(n,feature_num+1),最后一列为标签;返回的特征列表应保存到文件中
    """
    features = []
    labels = []
    labels_dict = pd.read_csv(label_file, index_col=0)
    # 参考板图像
    ref = None
    # 0开头的表示白板
    if len(glob.glob(f'{data_root}/0*/*.hdr')) > 0:
        ref = spectral.open_image(glob.glob(f'{data_root}/0*/*.hdr')[0])
    msi_fs = glob.glob(f'{data_root}/[!0]*/*.hdr')
    for msi_f in msi_fs:
        msi = spectral.open_image(msi_f).load()
        norm_msi = normalization.normalization(msi, ref, norm_mode)
        if roi_param['method'] == 'fix':
            x, y, w, h = roi_param['rect']
            roi_msi = norm_msi[y:y + h, x:x + w]
            specs = [np.mean(roi_msi, axis=(0, 1))]
        elif roi_param['method'] == 'thresh':
            rois = _get_thresh_roi(norm_msi, roi_param['thresh'])[0]
            specs = gx_spectrum.calc_area_spectrum(norm_msi, rois)[0]
        features.extend(specs)
        name = msi_f.split(os.sep)[-2]
        label = labels_dict['label'][name]
        labels.extend([label] * len(specs))
    features = np.array(features)
    labels = np.array(labels)
    features = _pre_specs(features, pre_methods)
    if dim_reduction['method'] == 'pca':
        pca = PCA(n_components=dim_reduction['num'])
        features = pca.fit_transform(features, labels)

    return features, labels


def preview_thresh(data_group_root, thresh, page_num=1, page_size=1):
    """
    对阈值分割的结果进行预览
    @param data_group_root: str-数据集分组根目录
    @param thresh: int-分割阈值
    @param page_num: int-页数(主要是为了后期可能增加分页)
    @param page_size: int-每页大小
    @return: 分割的预览图像，可直接用于显示，类型为array
    """
    files = sorted(glob.glob(f'{data_group_root}/[!0]*/*.hdr'))
    offset = (page_num - 1) * page_size
    results = []
    for f in files[offset:offset + page_size + 1]:
        msi = spectral.open_image(f)
        preview_img = _get_thresh_roi(msi, thresh)[1]
        results.append(preview_img)
    return results


def preview_features(data_root, features, labels):
    """
    预览光谱特征，返回两张图片，总体光谱图和平均光谱图
    @param features:特征
    @param labels:标签
    @return:总体光谱图，平均光谱图
    """
    msi_f = glob.glob(f'{data_root}/*/*.hdr')[0]
    msi = spectral.open_image(msi_f)
    # spec_pos = np.array(msi.metadata['wavelength'], dtype=int)
    spec_pos = np.arange(1, len(features[0]) + 1)
    img1, img2 = drawer.show_specs_class(spec_pos, features, labels)
    # cv.imshow('img1', img1)
    # cv.waitKey(0)
    # cv.imshow('img2', img2)
    # cv.waitKey(0)
    return img1, img2


def _fetch_model(task_type, algorithm):
    if algorithm == 'SVM':
        return SVR() if task_type == 'regre' else SVC()
    if algorithm == 'Linear':
        return LinearRegression() if task_type == 'regre' else LogisticRegression()
    if algorithm == 'RF':
        return RandomForestRegressor() if task_type == 'regre' else RandomForestClassifier()


def generate_model(features, labels, task_type, target_range, split_method, train_ratio, algorithm):
    """
    传入数据和配置参数，生成算法模型,返回模型文件、评估指标等；
    @param features:array-预处理后的数据特征
    @param labels:array-每个特征对应的标签,可以是分类或回归
    @param task_type:str-任务类别,class代表分类,regre代表回归
    @param target_range:list-目标的范围,如果分类，则表示子类别列表,如[1,2,3];如果回归,则表示目标的范围,如[0,50]；
    @param split_method:str-数据划分的方法,支持'Random','K-S','LeaveOne'
    @param train_ratio:float-训练集的比例, 0~1
    @param algorithm:算法模型,支持'SVM','Linear','RF'
    @return:(model, pic, stats)模型，模型指标图，评估指标
    """
    model = _fetch_model(task_type, algorithm)
    # if split_method == 'Random':
    # TODO:补充不同数据划分方式
    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=(1 - train_ratio),
                                                        random_state=1)
    model = model.fit(X_train, y_train)
    scores = []
    scores.append(model.score(X_test, y_test))
    y_pred = model.predict(X_test)

    if task_type == 'regre':
        scores.append(metrics.mean_absolute_error(y_test, y_pred))
        scores.append(metrics.explained_variance_score(y_test, y_pred))
        metric_img = drawer.show_result_regre(y_test, y_pred)
    else:
        scores.append(metrics.precision_score(y_test, y_pred, average='macro'))
        scores.append(metrics.recall_score(y_test, y_pred, average='macro'))
        metric_img = drawer.show_confusion_matrix(y_test, y_pred)[0]
    return model, metric_img, scores


def batch_test(model, features, labels, task_type, target_range):
    """
    传入模型和数据，用模型对数据进行测试，输出评估结果
    @param model: 生成的模型；
    @param features:array-预处理后的数据特征
    @param labels:array-每个特征对应的标签,可以是分类或回归
    @param task_type:str-任务类别,class代表分类,regre代表回归
    @param target_range:list-目标的范围,如果分类，则表示子类别列表,如[1,2,3];如果回归,则表示目标的范围,如[0,50]；
    @return:(pic, stats)模型，模型指标图，评估指标
    """
    scores = []
    scores.append(model.score(features, labels))
    y_pred = model.predict(features)
    if task_type == 'regre':
        scores.append(metrics.mean_absolute_error(labels, y_pred))
        scores.append(metrics.explained_variance_score(labels, y_pred))
        metric_img = drawer.show_result_regre(labels, y_pred)
    else:
        scores.append(metrics.precision_score(labels, y_pred, average='macro'))
        scores.append(metrics.recall_score(labels, y_pred, average='macro'))
        metric_img = drawer.show_confusion_matrix(labels, y_pred)[0]
    return metric_img, scores


def preview_label_dist(labels, bins=5, title='标签统计分布'):
    # 预览标签的统计分布图
    img = drawer.show_label_dist(labels, bins, title)
    return img


if __name__ == '__main__':
    # 数据集的根目录，目录树结构需要参照定义的规范来组织
    # data_root = '/Users/gordon/data/光谱成像案例/chenpi/国创/data'
    data_root = '/Users/gordon/data/光谱分析软件/回归/data/train1/'
    img = preview_thresh(data_root, 40)
    # cv.imshow('thresh', img[0])
    # cv.waitKey(0)
    import pandas as pd

    label_file = '/Users/gordon/data/光谱分析软件/回归/labels.csv'
    # 分类
    # features, labels = batch_preprocess(data_root, label_file, 1, {'method': 'thresh', 'thresh': 40}, ['spec'], ['msc'],
    #                                     {'method': 'pca', 'num': 2})
    # 回归
    features, labels = batch_preprocess(data_root, label_file, 3, {'method': 'thresh', 'thresh': 40}, ['spec'], ['msc'],
                                        {'method': 'pca', 'num': 2})
    print(features.shape, labels.shape)
    print(labels)
    # np.save('sample-features.npy', features)
    # np.save('sample-labels.npy', labels)
    # features = np.load('sample-features.npy')
    # labels = np.load('sample-labels.npy')
    # print(len(features), len(labels))
    imgs = preview_features(data_root, features, labels)
    cv.imshow('spec', imgs[0])
    cv.waitKey(0)
    cv.imshow('mean', imgs[1])
    cv.waitKey(0)

    imgs = preview_label_dist(labels)
    cv.imshow('labels', imgs)
    cv.waitKey(0)
    # 分类
    # model, img, scores = generate_model(features, labels, 'class', [1, 3, 5], 'Random', 0.8, 'SVM')
    # 回归
    model, img, scores = generate_model(features, labels, 'regre', [0, 20], 'Random', 0.8, 'SVM')

    print('result: ', model, scores)
    cv.imshow('img', img)
    cv.waitKey(0)
    # 返回的模型可以保存到本地
    # import joblib

    # joblib.dump(model, 'sample-model0.m')
    # 加载模型
    # model = joblib.load('sample/model0.m')
    img, scores = batch_test(model, features, labels, 'regre', [0, 20])
    print(scores)
    cv.imshow('img', img)
    cv.waitKey(0)
