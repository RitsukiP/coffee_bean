import glob
import os

import cv2
import numpy as np

from gx_spectral.config import constant
from gx_spectral.utils.white_board import detect_white_board


def _norm_mode1(images, board_area=None, board_ref=0.5):
    """光谱校准模式一，小白板同步模式
    即小白板和样品放在一起拍，白板的选取：自动选取白板
    图像自动归一化处理，检测出图像中白板区域，取平均，再将所有像素点除以平均值
    :param images: 传入对准后的10张图片的三维numpy矩阵，shape:(1024,1280,10)
    :param board_area: 手动选定的白板区域
    :return: 归一化处理后的10张图片矩阵的三维numpy矩阵，shape:(1024,1280,10)
    """
    # 选取倒数第二张图像，检测白板区域，后续9张图均采用该区域
    # imgGray = images[:, :, -2].copy()
    imgGray = images[:, :, -2].copy()
    imgGray = (imgGray / imgGray.max() * 255).astype(np.uint8)

    if board_area is None:
        # 启动选取
        white_flag, board_ref, (x1, y1, w1, h1) = detect_white_board(imgGray)
    else:
        # 手动选取
        white_flag = True
        x1, y1, x2, y2 = board_area
        h1, w1 = abs(y2 - y1), abs(x2 - x1)
    if white_flag:
        # cv_show('img', imgGray)
        res_arr = np.zeros_like(images, dtype=np.float64)
        # 对每个波段图像的每个像素点除以白板平均值

        white_region = images[y1:y1 + h1, x1:x1 + w1, :]
        white_mean = white_region.mean(axis=(0, 1))
        # 将图像对白板区域进行归一化，在乘以白板反射率，最后将灰度值转为0-255
        res_arr = images / white_mean * board_ref * 255
        # 重新将图像变换到(0,255)内的uint8类型，大于255的部分变为255
        res_arr = np.uint8(np.clip(res_arr, 0, 255))
        return res_arr
    else:
        msg = 'white board not found'
        print(msg)
        raise Exception(msg)


"""
光谱校准模式二，非同步模式，即先拍大白板，获得大白板数据,再拍样品。
"""


def _norm_mode2(images, board_imgs, sample_expose, white_expose, board_ref=0.91):
    """
    传入保存大白板png图片的路径和样品png图片的路径，自动进行光谱校准。
    :param white_path: 大白板png图片的路径
    :param sample_path: 样品png图片的路径
    :param white_t: 拍摄白板时的曝光时间
    :param sample_t: 拍摄样品时的曝光时间
    :return: 校准后的样品矩阵，shape:[1024,1280,10]
    """
    res_arr = (images * float(white_expose)) / (board_imgs / board_ref * float(sample_expose))
    # 重新将图像变换到(0,255)内的uint8类型
    res_arr = res_arr * 255.0
    res_arr = np.uint8(np.clip(res_arr, 0, 255))
    return res_arr


"""
光谱校准模式三，非同步模式，先拍小白板，再拍样品。
"""


def _norm_mode3(images, board_imgs, sample_expose, white_expose, board_area=None, board_ref=0.5):
    """
    传入保存大白板png图片的路径和样品png图片的路径，自动进行光谱校准。
    :param white_path: 大白板png图片的路径
    :param sample_path: 样品png图片的路径
    :param white_t: 拍摄白板时的曝光时间
    :param sample_t: 拍摄样品时的曝光时间
    :return: 校准后的样品矩阵，shape:[1024,1280,10]
    """

    # 选取倒数第二张图像，检测白板区域，后续9张图均采用该区域
    imgGray = board_imgs[:, :, -2].copy()
    imgGray = (imgGray / imgGray.max() * 255).astype(np.uint8)
    if board_area is None:
        # 自动动选取
        white_flag, board_ref, (x1, y1, w1, h1) = detect_white_board(imgGray)
    else:
        # 手动选取
        white_flag = True
        x1, y1, x2, y2 = board_area
        h1, w1 = abs(y2 - y1), abs(x2 - x1)
    if white_flag:
        # cv_show('img', imgGray)
        # res_arr = np.zeros_like(images, dtype=np.float64)
        # 对每个波段图像的每个像素点除以白板平均值

        white_region = board_imgs[y1:y1 + h1, x1:x1 + w1, :]
        white_mean = white_region.mean(axis=(0, 1))
        # print('========== white mean ==========')
        # print(white_mean.shape)
        # print(white_mean)
        # 将图像对白板区域进行归一化，在乘以白板反射率，最后将灰度值转为0-255
        # res_arr = images / white_mean * board_ref * 255
        # print(images.max())
        res_arr = 255 * (images * float(white_expose)) / (white_mean / board_ref * float(sample_expose))
        # print(res_arr.max())
        # 重新将图像变换到(0,255)内的uint8类型，大于255的部分变为255
        res_arr = np.uint8(np.clip(res_arr, 0, 255))
        return res_arr
    else:
        msg = 'white board not found'
        print(msg)
        raise Exception(msg)


def normalization(ori_images, board_images=None, norm_mode=1, board_area=None, board_ref=None,
                  sample_expose=10, white_expose=10, device_type=constant.DEVICE_TYPE_UNISPEC):
    """多光谱标准化
    传入若干通道的图像，使用特征匹配的方式分别与第一张图片进行配准对齐
    Args:
        ori_images(np.array):原始图片，形状为(h,w,ch)
        board_images(np.array):非必须，白板图片，形状为(h,w,ch),分步拍摄需要传入
        norm_mode(int):标准化方法，1小白板同步，2大白板分步，3小白板分步
        board_area(tuple):非必须，白板区域，(x1,y1,x2,y2)
        board_ref(float):非必须，白板反射率
        sample_expose(float):样品曝光时间,分步拍摄时传入
        white_expose(float):白板曝光时间，分步拍摄时传入
        device_type(int):设备类型，1代表优尼科，暂时无用；
    Returns:
        res_images(np.array):标准化后的图片，形状为(h,w,ch)
    """
    if norm_mode == 1:
        return _norm_mode1(ori_images, board_area, board_ref)
    elif norm_mode == 2:
        return _norm_mode2(ori_images, board_images, sample_expose, white_expose, board_ref)
    elif norm_mode == 3:
        return _norm_mode3(ori_images, board_images, sample_expose, white_expose, board_area, board_ref)


if __name__ == '__main__':
    from gx_spectral.utils import samples

    images = samples.read_unispec_sample()

    dataRoot = '/Users/gordon/data/光源测试/test_0919/paishemoshi/fenbu'
    refRoot = '/Users/gordon/data/光源测试/test_0919/paishemoshi/fenbu/ref'
    # img_files = sorted(os.listdir(f'{dataRoot}/chenpi/'))
    img_files = glob.glob(f'{dataRoot}/chenpi/cube_20220919_154547/png/*')
    images = []
    img_files = sorted(img_files)
    for f in img_files:
        if not f.endswith('png'):
            continue
        img = cv2.imread(f, 0)
        images.append(img)
    images = np.array(images)
    ref_data, _ = read_data(refRoot, data_type=2)
    # ref = ref_data.mean(axis=0)
    ref = ref_data[0]
    ref = ref.transpose([1, 2, 0])
    images = images.transpose([1, 2, 0])

    res = normalization(images, ref, norm_mode=3, sample_expose=0.1, white_expose=0.1)
    for i in range(res.shape[2]):
        cv2.imwrite(f'tmp/{i}.png', res[:, :, i])
