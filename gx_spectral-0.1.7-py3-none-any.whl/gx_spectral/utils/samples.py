import os
import numpy as np

import cv2


def read_unispec_sample(data_type='png', subpath='chenpi/1/cube1/'):
    p = f'samples/{subpath}/{data_type}'
    images = []
    img_files = sorted(os.listdir(p))
    for f in img_files:
        img = cv2.imread(os.path.join(p, f), 0)
        images.append(img)
    images = np.array(images)
    # 改变通道顺序
    images = images.transpose([1, 2, 0])
    return images
