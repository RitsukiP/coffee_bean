import cv2
import numpy as np


def detect_white_board(img):
    """
    检测白板，支持小白板和小圆板
    """
    imgBlur = cv2.GaussianBlur(img, (5, 5), 1)  # 高斯模糊
    # cv_show('imgblur',imgBlur)
    # imgCanny = cv2.Canny(imgBl ur,60,60)  #Canny算子边缘检测

    # otsu_thresh_value = 0
    # thresh = cv2.threshold(imgBlur, otsu_thresh_value, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    # thresh = cv2.adaptiveThreshold(imgBlur,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,11,2)
    thresh = cv2.threshold(imgBlur, 0, 255, cv2.THRESH_TRIANGLE + cv2.THRESH_BINARY)[1]
    kernel = np.ones((11, 11), np.uint8)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    # cv_show('th', thresh)
    # 找出边缘和轮廓
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    # print("轮廓数量：%d" % len(contours))

    white_flag = False
    white_res = 1.0
    x1, y1, h1, w1 = 0, 0, 0, 0
    # 1）矩形白板检测
    for obj in contours:
        # area = cv2.contourArea(obj)  #计算轮廓内区域的面积
        # cv2.drawContours(imgGray, obj, -1, (0, 0, 0), 4)  # 绘制轮廓线
        perimeter = cv2.arcLength(obj, True)  # 计算轮廓周长
        approx = cv2.approxPolyDP(obj, 0.02 * perimeter, True)  # 获取轮廓角点坐标
        CornerNum = len(approx)  # 轮廓角点的数量
        x, y, w, h = cv2.boundingRect(approx)  # 获取坐标值和宽度、高度
        # 矩形轮廓对象检测
        if CornerNum == 4 and perimeter > 100:
            white_flag = True
            white_res = 0.52
            # 选取检测到的矩形中间50%区域，避免矩形边界黑色部分影响
            x1, y1 = int(x + 0.25 * w), int(y + 0.25 * h)
            w1, h1 = int(w / 2), int(h / 2)
            # cv2.rectangle(imgGray, (x, y), (x + w, y + h), (0, 0, 0), 2)  # 绘制边界框
            # cv2.rectangle(imgGray, (x1, y1), (x1 + w1, y1 + h1), (0, 0, 0), 2)  # 绘制边界框

    # 2）圆形白板检测
    circles = cv2.HoughCircles(imgBlur, cv2.HOUGH_GRADIENT, 1, 200,
                               param1=50, param2=150, minRadius=50, maxRadius=0)
    if circles is not None and circles.shape[1] == 1:
        white_flag = 1
        white_res = 0.98
        circles = np.uint16(np.around(circles))
        circle = circles[0][0]
        x, y, r = circle[0], circle[1], circle[2]
        x1, y1 = int(x - r / 1.8), int(y - r / 1.8)
        w1, h1 = int(r / 1.8 * 2), int(r / 1.8 * 2)
        # cv2.circle(imgGray, (x, y), r, (0, 0, 0), 2)
        # cv2.rectangle(imgGray, (x1, y1), (x1 + w1, y1 + h1), (0, 0, 0), 2)
    return white_flag, white_res, (x1, y1, h1, w1)
