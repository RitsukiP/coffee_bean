import glob
import os

import numpy as np
import pandas as pd
from spectral import spectral
import cv2 as cv

from gx_spectral.config import code_msg
from gx_spectral.config.api_exception import ApiException


def _read_label(data_root):
    # 读取标签文件
    # 设置name为str，避免数字名称的类型异常
    dtype = {'name': str}
    labels_dict = None
    # 回归任务才有标签文件
    label_path = glob.glob(f'{data_root}/labels*.csv') + glob.glob(f'{data_root}/labels*.xls') \
                 + glob.glob(f'{data_root}/labels*.xlsx')
    if len(label_path) != 1:
        raise ApiException(code_msg.COMMON_FILE_INVALID, '标签文件为空或太多')
    label_file = label_path[0]
    if label_file.endswith('.csv'):
        labels_dict = pd.read_csv(label_file, index_col=0, header=0, dtype=dtype)  # , names=[], dtype=dtype
    elif label_file.endswith('.xls') or label_file.endswith('.xlsx'):
        labels_dict = pd.read_excel(label_file, index_col=0, header=0, dtype=dtype)
    return labels_dict


def _load_hs(data_path, device_no, params={}):
    # 加载高光谱数据
    data = []
    metas = []
    spec_pos = None
    if device_no == 'HS0401':
        if 'data_type' not in params or params['data_type'] == 'reflectance':
            files = glob.glob(f'{data_path}/results/*.hdr')
        elif params['data_type'] == 'intensity':
            files = glob.glob(f'{data_path}/capture/20*.hdr')
        else:
            raise ApiException(code_msg.COMMON_PARAM_INVALID, 'data_type参数不合法')
        for file in files:
            hsi = spectral.open_image(file)
            d = hsi.load()
            data.append(d)
            metas.append(hsi.metadata)
            spec_pos = np.array(hsi.metadata['wavelength'], dtype=float)
    elif device_no == 'HS0402':
        files = glob.glob(f'{data_path}/*.hdr')
        for file in files:
            hsi = spectral.open_image(file)
            d = hsi.load()
            data.append(d)
            metas.append(hsi.metadata)
            # spec_pos = np.array(hsi.metadata['wavelength'], dtype=float)
    # 根据不同的设备类型，读取对应的光谱数据
    else:
        raise Exception('设备编号异常')
    return np.array(data), np.array(metas), spec_pos


def _load_sp(data_path, device_no, params={}):
    data = []
    metas = []
    spec_pos = None
    # 加载单点光谱数据
    if device_no == 'SP0201' or device_no == 'SP0202':  # 谱研近红外手持式光谱仪、谱研近红外透射光谱仪
        # 谱研手持式近红外光谱仪
        files = glob.glob(f'{data_path}/*.csv')
        for file in files:
            spec = pd.read_csv(file, names=['position', 'abs', 'ref', 'sam'], header=29)
            data.append(spec['abs'].values)
            metas.append({'ref': spec['ref'].values, 'sam': spec['sam'].values})
            spec_pos = spec['position'].values
    if device_no == 'SP0301':  # 奥谱天成光纤光谱仪
        files = glob.glob(f'{data_path}/*.csv')
        for file in files:
            spec = pd.read_csv(file, sep=',', header=8)
            data.append(spec['value'].values)
            metas.append({})
            spec_pos = spec['position'].values
    if device_no == 'SP0501':  # 迅捷光远光谱仪
        files = glob.glob(f'{data_path}/*.csv')
        for file in files:
            spec = pd.read_csv(file, names=['position', 'abs', 'ref', 'sam', 'ref0', 'sam0'], header=20)
            data.append(spec['abs'].values)
            metas.append({'ref': spec['ref'].values, 'sam': spec['sam'].values, 'sam0': spec['sam0'].values,
                          'ref0': spec['ref0'].values, })
            spec_pos = spec['position'].values
    if device_no == 'SP0203':  # 谱研水质检测仪（单光谱仪）
        file_type = params['file_type']
        l = params['l']
        if file_type == 'raw':
            files = glob.glob(f'{data_path}/specFile/*.raw')
            for file in files:
                arr = np.fromfile(file, dtype=np.float64)
                spec_pos = arr[0:l]
                spec_ref = arr[l:2 * l]
                spec_sample = arr[2 * l:3 * l]
                spec_dark = arr[3 * l:4 * l]
                d = [spec_ref, spec_sample, spec_dark]
                data.append(d)
                metas.append({})
        elif params['file_type'] == 'csv':
            files_ref = glob.glob(f'{data_path}/specFile/*reference*.csv')
            files_sample = glob.glob(f'{data_path}/specFile/*sample*.csv')
            files_dark = glob.glob(f'{data_path}/specFile/*dark*.csv')
            for file_ref, file_sample, file_dark in zip(files_ref, files_sample, files_dark):
                df_ref = pd.read_csv(file_ref, sep=',', header=0)
                df_sample = pd.read_csv(file_sample, sep=',', header=0)
                df_dark = pd.read_csv(file_dark, sep=',', header=0)
                spec_ref = np.array(df_ref['intensity'])
                spec_sample = np.array(df_sample['intensity'])
                spec_dark = np.array(df_dark['intensity'])
                spec_pos = np.array(df_ref['wavelengths'])
                d = [spec_ref, spec_sample, spec_dark]
                data.append(d)
                metas.append({})
    if device_no == 'SP0204':  # 谱研水质检测仪（双光谱仪）
        file_type = params['file_type']
        l = params['l']
        if file_type == 'raw':
            files = glob.glob(f'{data_path}/specFile/*.raw')
            for file in files:
                arr = np.fromfile(file, dtype=np.float64)
                spec_pos = arr[0:l]
                spec_sample_dark = arr[l:2 * l]  # Sample dark
                spec_sample = arr[2 * l:3 * l]  # Sample
                spec_ref_dark = arr[3 * l:4 * l]  # Reference dark
                spec_ref = arr[4 * l:5 * l]  # Reference
                d = [spec_ref, spec_sample, spec_ref_dark, spec_sample_dark]
                data.append(d)
                metas.append({})
        elif file_type == 'asc':
            files = glob.glob(f'{data_path}/specFile/*.asc')
            for file in files:
                df = pd.read_csv(file, skiprows=5, sep='\t', index_col=False, header=0)
                spec_pos = np.array(df['Wavelength(nm)'])
                spec_ref = np.array(df['Reference'])
                spec_sample = np.array(df['Sample'])
                spec_ref_dark = np.array(df['Reference dark'])
                spec_sample_dark = np.array(df['Sample dark'])
                d = [spec_ref, spec_sample, spec_ref_dark, spec_sample_dark]
                data.append(d)
                metas.append({})
    return np.array(data), np.array(metas), spec_pos


def _img_feature(data):
    h1 = 512 + 20  # 512
    w1 = 594
    h2 = 518 + 20  # 518
    w2 = 660
    dh = 18
    dw = 18
    calibrate = []
    for i, img in enumerate(data):
        baiban_roi = img[h1:h1 + dh, w1:w1 + dw]
        sample_roi = img[h2:h2 + dh, w2:w2 + dw]
        reflect = np.mean(sample_roi) / np.mean(baiban_roi) / 2
        calibrate.append(reflect)
    calibrate = np.array(calibrate)  # (10,)
    return calibrate


def _load_ms(data_path, device_no, params={}):
    data = []
    metas = []
    spec_pos = None
    # 加载多光谱数据
    if device_no == 'MS0101' or device_no == 'MS0102' or device_no == 'MS0402':
        if 'data_type' not in params or params['data_type'] == 'raw':
            hdr_file = glob.glob(f'{data_path}/*.hdr')
            if len(hdr_file) == 0:
                return None, None, None
            # assert len(hdr_file) == 1
            msi = spectral.open_image(hdr_file[0])
            metas.append(msi.metadata)
            spec_pos = np.array(msi.metadata['wavelength'], dtype=float)
            # 读取raw文件数据
            data.append(msi.load())
        elif params['data_type'] in ['png', 'pre_process', 'pretreatment']:
            # 读取子路径下的数据
            files = glob.glob(f'{data_path}/{params["data_type"]}/*.png')
            if len(files) == 0:
                return None, None, None
            # 根据数字顺序排序
            files.sort(key=lambda x: int(os.path.basename(x)[:-4]))
            imgs = []
            for file in files:
                imgs.append(cv.imread(file, 0))
            imgs = np.transpose(imgs, (1, 2, 0))
            data.append(imgs)
            if spec_pos is not None and (imgs.shape[2] > spec_pos.shape[0]):
                # 如果通道数大于raw文件(例如RGB+NIR双相机)则插入等间距的波长信息(方面画图)
                spec_pos = np.insert(spec_pos, 0, [spec_pos[0] - (spec_pos[1] - spec_pos[0]) * i for i in
                                                   np.arange(imgs.shape[2] - spec_pos.shape[0], 0, - 1)])
    elif device_no == 'MS0103':
        files = glob.glob(f'{data_path}/*.hdr')
        for file in files:
            msi = spectral.open_image(file).load()
            data.append(msi.load())
            metas.append(msi.metadata)
            spec_pos = np.array(msi.metadata['wavelength'], dtype=float)
    elif device_no == 'MS0401':
        files = glob.glob(f'{data_path}/*.raw')
        files = sorted(files)
        msi = []
        for f in files:
            img = np.fromfile(f, dtype='uint16')
            img = img.reshape(800, 1280)
            msi.append(img)
        msi = np.transpose(msi, (1, 2, 0))
        data.append(msi)
        # hdr文件不合规，无法通过spectral直接读取
        metas.append({})
        # 光谱波段未确定，一般是定制的
        spec_pos = np.arange(450, 541, 5)
    else:
        raise Exception('设备编号异常')
    return np.array(data), np.array(metas), spec_pos


def load_data(data_path, device_no, params={}):
    """
    加载光谱数据，传入路径和设备信息，返回数据
    @param data_path: 数据路径
    @param device_no: 设备编号，参照文档定义
    @param params: 扩展参数
    @return: data原始光谱(成像)数据,metadata元数据及扩展数据,spec_pos光谱波长位置
    """
    if device_no.startswith('HS'):
        return _load_hs(data_path, device_no, params=params)
    elif device_no.startswith('MS'):
        return _load_ms(data_path, device_no, params=params)
    elif device_no.startswith('SP'):
        return _load_sp(data_path, device_no, params=params)
    else:
        raise Exception('参数异常')


# 数据集数据加载器
def load_dataset(data_root, label_type=1, device_no='', params={}):
    """
    读取数据目录下的数据，返回数据列表，和标签数组
    @param data_root: 数据根目录，必须按照规范组织数据结构.名称为0的用于放置参考版样品
    @param label_type: 标签类型，1分类，2回归，3分割
    @param device_no:设备编号，不同设备的数据文件有差异.
    @param params: 扩展参数
    @return:data,labels,spec_pos,metas,data0; 返回数据、标签、光谱波段信息、元数据、参考板数据，numpy数组，维度相同
    """
    if label_type not in [1, 2, 3]:
        raise Exception('参数异常')
    if device_no not in ['SP0301', 'SP0201', 'SP0202', 'SP0203', 'SP0204', 'SP0401', 'MS0101', 'MS0102', 'MS0401',
                         'HS0401', 'SP0501']:
        raise Exception('设备编号异常')
    if device_no in ['SP0203', 'SP0204']:  # 谱研水质检测仪
        file_type = params['file_type']
        l = params['l']
        if file_type not in ['raw', 'csv', 'asc'] or l not in [2048, 912]:
            raise Exception('参数有误')
    # 数据
    data = []
    # 标签
    labels = []
    # 白板名称
    sample_name0 = []
    # 样品名称
    sample_names = []
    # 元数据或者其他扩展数据
    meta_data = []
    # 参考板
    refs = []
    # 光谱波段信息
    spec_pos = None
    if label_type == 1:
        paths = glob.glob(f'{data_root}/*/*')
    else:
        paths = glob.glob(f'{data_root}/*')
        label_dict = _read_label(data_root)
    for path in paths:
        if os.path.isfile(path):
            continue
        name = os.path.basename(path)
        # 以下划线之前的作为key
        key = name.split('_')[0]
        path_sp = path.split(os.sep)
        is_ref = (key == '0') or ('baiban' in name) or (path_sp[-2] == '0')
        d, meta, pos = load_data(path, device_no, params=params)
        if d is None or len(d) == 0:
            print('------ data is None --------')
            print(path)
            continue
        if is_ref:
            refs.extend(d)
        else:
            if label_type == 1:
                label = path_sp[-2]
            else:
                if key not in label_dict.index:
                    raise ApiException(code_msg.COMMON_DATASET_INVALID, '标签不存在！key=' + key)
                label = label_dict.loc[key]
            data.extend(d)
            meta_data.extend(meta)
            labels.extend([label] * len(d))
            sample_names.extend([name] * len(d))
        spec_pos = pos
    if device_no in ['SP0203', 'SP0204']:
        data, refs = reshape_data(device_no, data, refs)
    return np.squeeze(data), np.squeeze(labels), spec_pos, np.squeeze(sample_names), \
           np.squeeze(meta_data), np.squeeze(refs)


def get_calibrate(device_no, datas, datas0, params={}):
    if device_no in ['SP0201', 'SP0202', 'SP0301']:  # 谱研近红外手持式光谱仪、谱研近红外透射光谱仪、奥谱天成光纤光谱仪
        baiban_load = params['baiban_load']
        if baiban_load not in ['mean', 0, 1, 2]:
            raise Exception('参数有误')

        if baiban_load == 'mean':
            spec0 = np.mean(datas0, axis=0, keepdims=True)  # 白板多轮测量求均值，(1, 2048)
        elif isinstance(baiban_load, int):  # 指定取其中某个
            spec0 = datas0[[baiban_load], :]  # 指定取其中某个，(1, 2048)
        spec = datas
        # 计算吸光度，异常结果设为-99
        transmit_inv = np.divide(spec0, spec, out=-99 * np.ones_like(spec, dtype='float64'), where=spec != 0)
        calibrate = np.log10(transmit_inv, out=-99 * np.ones_like(transmit_inv, dtype='float64'),
                             where=((transmit_inv != -99) & (transmit_inv > 0)))  # (n_sample, 2048)
        return calibrate, spec, spec0
    if device_no in ['SP0203', 'SP0204']:  # 谱研水质检测仪
        position = params['position']
        baiban_load = params['baiban_load']
        verify_method = params['verify_method']
        if position not in [0, 1] or baiban_load not in ['mean', 0, 1, 2] or verify_method not in [0, 2]:
            raise Exception('参数有误')
        # 扣除暗背景
        if device_no == 'SP0203':
            spec0_ref_orig, spec0_sample_orig, spec0_dark_orig = datas0
            spec_ref, spec_sample, spec_dark = datas
            spec0_ref_orig = spec0_ref_orig - spec0_dark_orig
            spec0_sample_orig = spec0_sample_orig - spec0_dark_orig
            spec_ref = spec_ref - spec_dark
            spec_sample = spec_sample - spec_dark
        if device_no == 'SP0204':
            spec0_ref_orig, spec0_sample_orig, spec0_ref_dark_orig_, spec0_sample_dark_orig_ = datas0
            spec_ref, spec_sample, spec_ref_dark_, spec_sample_dark_ = datas
            spec0_ref_orig = spec0_ref_orig - spec0_ref_dark_orig_
            spec0_sample_orig = spec0_sample_orig - spec0_sample_dark_orig_
            spec_ref = spec_ref - spec_ref_dark_
            spec_sample = spec_sample - spec_sample_dark_
        # position：实际水样放置的位置。chan1：样品路，chan2：参比路
        if position == 0 and verify_method == 0:  # 单光路（纯水、样品都放在sample位）
            spec0_chan1_orig = spec0_sample_orig
            spec_chan1 = spec_sample
        elif position == 1 and verify_method == 0:  # 单光路（纯水、样品都放在reference位）
            spec0_chan1_orig = spec0_ref_orig
            spec_chan1 = spec_ref
        elif position == 0 and verify_method == 2:  # 双光路校正（样品放在sample位，纯水放在reference位）
            spec0_chan1_orig = spec0_sample_orig
            spec_chan1 = spec_sample
            spec0_chan2_orig = spec0_ref_orig
            spec_chan2 = spec_ref
        elif position == 1 and verify_method == 2:  # 双光路校正（样品放在reference位，纯水放在sample位）
            spec0_chan1_orig = spec0_ref_orig
            spec_chan1 = spec_ref
            spec0_chan2_orig = spec0_sample_orig
            spec_chan2 = spec_sample
        # 单光路校正
        if verify_method == 0:
            # 计算样品路吸光度
            # 多组白板求均值or取其中一个
            if baiban_load == 'mean':
                spec0 = np.mean(spec0_chan1_orig, axis=0, keepdims=True)  # 白板多轮测量求均值，(1, 2048)
            elif isinstance(baiban_load, int):  # 指定取其中某个
                spec0 = spec0_chan1_orig[[baiban_load], :]  # 指定取其中某个，(1, 2048)
            # 计算吸光度，异常结果设为-99
            transmit_inv = np.divide(spec0, spec_chan1, out=-99 * np.ones_like(spec_chan1, dtype='float64'),
                                     where=spec_chan1 != 0)
            calibrate = np.log10(transmit_inv, out=-99 * np.ones_like(transmit_inv, dtype='float64'),
                                 where=((transmit_inv != -99) & (transmit_inv > 0)))  # (n_sample, 2048)
        # 双光路校正
        if verify_method == 2:
            # 多组白板求均值or取其中一个
            if baiban_load == 'mean':
                spec0 = np.mean(spec0_chan1_orig, axis=0, keepdims=True)  # 白板多轮测量求均值，(1, 2048)
                spec0_chan2 = np.mean(spec0_chan2_orig, axis=0, keepdims=True)  # 白板多轮测量求均值，(1, 2048)
            elif isinstance(baiban_load, int):  # 指定取其中某个
                spec0 = spec0_chan1_orig[[baiban_load], :]  # 指定取其中某个，(1, 2048)
                spec0_chan2 = spec0_chan2_orig[[baiban_load], :]  # 指定取其中某个，(1, 2048)
            spec_chan1 = spec_chan1 / spec_chan2 * spec0_chan2  # 对原始光强进行双光路补偿，(n_sample, 2048)
            # 计算吸光度，异常结果设为-99
            transmit_inv = np.divide(spec0, spec_chan1, out=-99 * np.ones_like(spec_chan1, dtype='float64'),
                                     where=spec_chan1 != 0)
            calibrate = np.log10(transmit_inv, out=-99 * np.ones_like(transmit_inv, dtype='float64'),
                                 where=((transmit_inv != -99) & (transmit_inv > 0)))  # (n_sample, 2048)

        return calibrate, spec_chan1, spec0


def reshape_data(device_no, data, refs):
    if device_no == 'SP0203':  # 谱研水质检测仪（单光谱仪）
        spec_ref0 = []  # 白板
        spec_sample0 = []
        spec_dark0 = []
        spec_ref = []  # 样本
        spec_sample = []
        spec_dark = []
        for d in refs:
            data_ref, data_sample, data_dark = d
            spec_ref0.append(data_ref)
            spec_sample0.append(data_sample)
            spec_dark0.append(data_dark)
        for d in data:
            data_ref, data_sample, data_dark = d
            spec_ref.append(data_ref)
            spec_sample.append(data_sample)
            spec_dark.append(data_dark)
        refs = [spec_ref0, spec_sample0, spec_dark0]
        data = [spec_ref, spec_sample, spec_dark]
    if device_no == 'SP0204':  # 谱研水质检测仪（双光谱仪）
        spec_ref0 = []  # 白板
        spec_sample0 = []
        spec_ref_dark0 = []
        spec_sample_dark0 = []
        spec_ref = []  # 样本
        spec_sample = []
        spec_ref_dark = []
        spec_sample_dark = []
        for d in refs:
            data_ref, data_sample, data_ref_dark, data_sample_dark = d
            spec_ref0.append(data_ref)
            spec_sample0.append(data_sample)
            spec_ref_dark0.append(data_ref_dark)
            spec_sample_dark0.append(data_sample_dark)
        for d in data:
            data_ref, data_sample, data_ref_dark, data_sample_dark = d
            spec_ref.append(data_ref)
            spec_sample.append(data_sample)
            spec_ref_dark.append(data_ref_dark)
            spec_sample_dark.append(data_sample_dark)
        refs = [spec_ref0, spec_sample0, spec_ref_dark0, spec_sample_dark0]
        data = [spec_ref, spec_sample, spec_ref_dark, spec_sample_dark]
    return data, refs

# if __name__ == '__main__':
# 近红外
# root = 'samples/dataset/uvvis_regre_water'
# datas, labels, pos, metadata, refs = load_dataset(root, 2, 'SP0203', {'file_type': 'csv', 'l': 2048})
# 高光谱
# root = '/Users/gordon/data/高光谱相机/rubber'
# datas, labels, pos, metadata, refs = load_dataset(root, s1, 'HS0401')
# 多光谱
# root = '/Users/gordon/data/chenpi/国创/data'
# datas, labels, pos, metadata, refs = load_dataset(root, s1, 'MS0101', params={})
# print(datas.shape, labels.shape, datas[0].shape, pos.shape, refs.shape)
# print(pos)
# print(metadata[0])
# print(labels)

# 谱研水质检测仪
# # roots = [r'D:\works\water detect\uvvis_regre_water\real\7-18', r'D:\works\water detect\uvvis_regre_water\real\7-25']  # 单光谱仪
# # params = {'file_type': 'raw', 'l': 2048, 'position': s1, 'baiban_load': 'mean', 'verify_method': 0}  # 'baiban_load': 0
# roots = [r'D:\works\water detect\uvvis_regre_water\monitor\tourushi-COD']  # 双光谱仪
# params = {'file_type': 'asc', 'l': 912, 'position': 0, 'baiban_load': 'mean', 'verify_method': 0}
# label_type = s2_2
# device_no = 'SP0204'  # 'SP0203'、'SP0204'
# # 读取原始数据
# spec0 = []
# spec = []
# calibrate = []
# labels = []
# sample_name0 = []
# sample_name = []
# for i, root in enumerate(roots):  # 不同天数据分开校准
#     datas_, labels_, spec_pos, sample_name_, metadata_, datas0_, sample_name0_ = dataloader.load_dataset(root, label_type=label_type, device_no=device_no, params=params)
#     calibrate_, spec_, spec0_, sample_name0_ = dataloader.get_calibrate(device_no, datas_, datas0_, sample_name0_, params=params)
#     spec0 = spec0 + spec0_.tolist()
#     spec = spec + spec_.tolist()
#     calibrate = calibrate + calibrate_.tolist()
#     labels = labels + labels_.tolist()
#     sample_name0 = sample_name0 + sample_name0_.tolist()
#     sample_name = sample_name + sample_name_.tolist()
#
#     print(len(datas_), datas_[0].shape, labels_.shape, len(datas0_), datas0_[0].shape, len(sample_name_), len(spec_pos))
#     print(calibrate_.shape, len(sample_name0_), len(sample_name_))
#     print(sample_name0_, sample_name_)
# spec0 = np.array(spec0)
# spec = np.array(spec)
# calibrate = np.array(calibrate)
# labels = np.array(labels)
# print(calibrate.shape, len(sample_name0), len(sample_name))
# print(labels)

# 谱研近红外手持式光谱仪、谱研近红外透射光谱仪、奥谱天成光纤光谱仪
# roots = [r'D:\works\谱研近红外手持式光谱仪\数据', r'D:\works\谱研近红外手持式光谱仪\数据']
# # roots = [r'D:\works\谱研近红外透射光谱仪\数据', r'D:\works\谱研近红外透射光谱仪\数据']
# # roots = [r'D:\works\奥谱天成光纤光谱仪\数据', r'D:\works\奥谱天成光纤光谱仪\数据']
# # roots = [r'D:\works\谱研近红外手持式光谱仪\回归', r'D:\works\谱研近红外手持式光谱仪\回归']
# # roots = [r'D:\works\谱研近红外透射光谱仪\回归', r'D:\works\谱研近红外透射光谱仪\回归']
# # roots = [r'D:\works\奥谱天成光纤光谱仪\回归', r'D:\works\奥谱天成光纤光谱仪\回归']
# params = {'baiban_load': 'mean'}
# label_type = s1  # s1、s2_2
# device_no = 'SP0201'  # 'SP0201'、'SP0202'、'SP0301'
# # 读取原始数据
# spec0 = []
# spec = []
# calibrate = []
# labels = []
# sample_name0 = []
# sample_name = []
# for i, root in enumerate(roots):  # 不同天数据分开校准
#     datas_, labels_, spec_pos, sample_name_, metadata_, datas0_, sample_name0_ = dataloader.load_dataset(root, label_type=label_type, device_no=device_no, params=params)
#     calibrate_, spec_, spec0_, sample_name0_ = dataloader.get_calibrate(device_no, datas_, datas0_, sample_name0_, params=params)
#     spec0 = spec0 + spec0_.tolist()
#     spec = spec + spec_.tolist()
#     calibrate = calibrate + calibrate_.tolist()
#     labels = labels + labels_.tolist()
#     sample_name0 = sample_name0 + sample_name0_.tolist()
#     sample_name = sample_name + sample_name_.tolist()
# spec0 = np.array(spec0)
# spec = np.array(spec)
# calibrate = np.array(calibrate)
# labels = np.array(labels)
# print(calibrate.shape, len(sample_name0), len(sample_name), len(labels), len(spec_pos))
# print(sample_name0)
# print(sample_name)
# print(labels)

# 多光谱相机
# roots = [r'D:\works\便携式多光谱相机\数据', r'D:\works\便携式多光谱相机\数据']
# roots = [r'D:\works\water detect\s1.14', r'D:\works\water detect\s1.14']
# label_type = s2_2  # s1、s2_2
# device_no = 'MS0101'  # MS0101、MS0102
# params = {}
# # 读取原始数据
# metadata = []
# labels = []
# sample_name0 = []
# sample_name = []
# for i, root in enumerate(roots):  # 不同天数据分开校准，这里没提取光谱
#     datas_, labels_, spec_pos, sample_name_, metadata_, datas0_, sample_name0_ = dataloader.load_dataset(root,
#                                                                                                          label_type=label_type,
#                                                                                                          device_no=device_no,
#                                                                                                          params=params)
#     # ...
#     metadata = metadata + metadata_
#     labels = labels + labels_.tolist()
#     sample_name0 = sample_name0 + sample_name0_.tolist()
#     sample_name = sample_name + sample_name_.tolist()
# labels = np.array(labels)
# print(labels.shape, len(sample_name0), len(sample_name), len(spec_pos), len(metadata))
# print(sample_name0)
# print(sample_name)
# print(labels)
