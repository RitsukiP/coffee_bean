# KS、SPXY光谱样本集划分方法
# Ref: https://blog.csdn.net/qq_42629547/article/details/138381450
import numpy as np
from gx_spectral.preprocess.nir_batch import load_nirs_N1, load_labels


def spxy(data, label, test_size=0.3):
    """
    SPXY算法划分数据集

    参数:
    data: 特征数据,shape为(n_samples, n_features)
    label: 标签数据,shape为(n_samples,)
    test_size: 测试集比例,默认为0.3

    返回:
    X_train: 训练集特征,shape为(n_samples, n_features)
    X_test: 测试集特征,shape为(n_samples, n_features)
    y_train: 训练集标签,shape为(n_samples,)
    y_test: 测试集标签,shape为(n_samples,)
    """
    # 备份数据
    x_backup = data
    y_backup = label

    # 样本数量
    M = data.shape[0]
    # 训练样本数量
    N = round((1 - test_size) * M)
    # 样本索引
    samples = np.arange(M)

    # 标准化标签
    label = (label - np.mean(label)) / np.std(label)

    # 初始化距离矩阵
    D = np.zeros((M, M))
    Dy = np.zeros((M, M))

    # 计算样本之间的欧氏距离和标签差异
    for i in range(M - 1):
        xa = data[i, :]
        ya = label[i]
        for j in range((i + 1), M):
            xb = data[j, :]
            yb = label[j]
            D[i, j] = np.linalg.norm(xa - xb)
            Dy[i, j] = np.linalg.norm(ya - yb)

    # 归一化距离矩阵
    Dmax = np.max(D)
    Dymax = np.max(Dy)
    D = D / Dmax + Dy / Dymax

    # 选择距离最远的两个样本作为初始训练样本
    maxD = D.max(axis=0)
    index_row = D.argmax(axis=0)
    index_column = maxD.argmax()

    m = np.zeros(N)
    m[0] = index_row[index_column]
    m[1] = index_column
    m = m.astype(int)

    dminmax = np.zeros(N)
    dminmax[1] = D[m[0], m[1]]

    # 迭代选择训练样本
    for i in range(2, N):
        pool = np.delete(samples, m[:i])
        dmin = np.zeros(M - i)
        for j in range(M - i):
            indexa = pool[j]
            d = np.zeros(i)
            for k in range(i):
                indexb = m[k]
                if indexa < indexb:
                    d[k] = D[indexa, indexb]
                else:
                    d[k] = D[indexb, indexa]
            dmin[j] = np.min(d)
        dminmax[i] = np.max(dmin)
        index = np.argmax(dmin)
        m[i] = pool[index]

    # 测试集索引
    m_complement = np.delete(np.arange(data.shape[0]), m)

    # 划分训练集和测试集
    X_train = data[m, :]
    y_train = y_backup[m]
    X_test = data[m_complement, :]
    y_test = y_backup[m_complement]

    return X_train, X_test, y_train, y_test


def ks(data, label, test_size=0.3):
    """
    Kennard-Stone算法划分数据集

    参数:
    data: 特征数据,shape为(n_samples, n_features)
    label: 标签数据,shape为(n_samples,)
    test_size: 测试集比例,默认为0.3

    返回:
    X_train: 训练集特征,shape为(n_samples, n_features)
    X_test: 测试集特征,shape为(n_samples, n_features)
    y_train: 训练集标签,shape为(n_samples,)
    y_test: 测试集标签,shape为(n_samples,)
    """
    # 样本数量
    M = data.shape[0]
    # 训练样本数量
    N = round((1 - test_size) * M)
    # 样本索引
    samples = np.arange(M)

    # 初始化距离矩阵
    D = np.zeros((M, M))

    # 计算样本之间的欧氏距离
    for i in range((M - 1)):
        xa = data[i, :]
        for j in range((i + 1), M):
            xb = data[j, :]
            D[i, j] = np.linalg.norm(xa - xb)

    # 选择距离最远的两个样本作为初始训练样本
    maxD = np.max(D, axis=0)
    index_row = np.argmax(D, axis=0)
    index_column = np.argmax(maxD)

    m = np.zeros(N)
    m[0] = np.array(index_row[index_column])
    m[1] = np.array(index_column)
    m = m.astype(int)
    dminmax = np.zeros(N)
    dminmax[1] = D[m[0], m[1]]

    # 迭代选择训练样本
    for i in range(2, N):
        pool = np.delete(samples, m[:i])
        dmin = np.zeros((M - i))
        for j in range((M - i)):
            indexa = pool[j]
            d = np.zeros(i)
            for k in range(i):
                indexb = m[k]
                if indexa < indexb:
                    d[k] = D[indexa, indexb]
                else:
                    d[k] = D[indexb, indexa]
            dmin[j] = np.min(d)
        dminmax[i] = np.max(dmin)
        index = np.argmax(dmin)
        m[i] = pool[index]

    # 测试集索引
    m_complement = np.delete(np.arange(data.shape[0]), m)

    # 划分训练集和测试集
    X_train = data[m, :]
    y_train = label[m]
    X_test = data[m_complement, :]
    y_test = label[m_complement]

    return X_train, X_test, y_train, y_test

if __name__ == '__main__':

    data_root = 'samples/dataset/regre/nir1325/'
    # data_root = 'samples/dataset/class/nir2'
    # specs, names, spec_pos = load_nirs_N1(data_root, device_type='NIR-FIB-9017')
    specs, names, spec_pos = load_nirs_N1(data_root, device_type='NIR-REF-1325')
    labels = load_labels(f'{data_root}/labels.csv', names)
    print(specs.shape, spec_pos.shape, )
    X_train, X_test, y_train, y_test = ks(specs, labels)
    print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)
    X_train, X_test, y_train, y_test = spxy(specs, labels)
    print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)

