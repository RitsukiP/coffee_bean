import os

import numpy as np
from matplotlib import pyplot as plt
from scipy.interpolate import interp1d  # 导入 scipy 中的一维插值工具 interp1d

from gx_spectral.utils.samples import read_unispec_sample

fov = 30
spec_shift = 1.1
width = 1280
# 每像素偏移的波长
spec_shift_pixel = fov / width * spec_shift
# 网格大小
cell_size = 80
# 网格数量
grid_count = 7
target_pos = []
ms_pos = [713 + i * 23 for i in range(10)]
for i in ms_pos:
    for j in range(grid_count):
        pos = i - (grid_count - 1 - j) * cell_size * spec_shift_pixel
        target_pos.append(pos)


def spectral_feature(spec, cell_size=50, grid_count=1):  # 输入x为单个多光谱数据,10个波段
    shape0 = spec.shape[:2]
    # 特征波长，这里选用grid_count个网格，每个网格大小为grid_size*grid_size，取平均作为单个波长特征
    # 共有10个波段，所以特征大小应该为grid_count*10
    feature_spec = np.zeros([10, grid_count])
    x1, y1 = shape0[1] // 2 - cell_size, shape0[0] // 2 - cell_size
    x2, y2 = shape0[1] // 2 + cell_size, shape0[0] // 2 + cell_size
    for i in range(grid_count):
        grid = spec[y1:y2, x1:x2, :]
        #         ref_grid = xs['0'][1][:, y1:y2, x1:x2]
        x1 += cell_size
        x2 += cell_size
        #         aver_spec = np.log10(np.mean(grid/ref_grid,axis=(1,2)))
        aver_spec = np.mean(grid, axis=(0, 1))
        # 这里调转一下赋值顺序，因为越往外透过的波长越短，调转后保持波长的顺序
        feature_spec[:, grid_count - 1 - i] = aver_spec
    #         print(feature_spec)
    feature_spec = feature_spec.reshape(-1)
    return feature_spec


class Reconstructor:
    def __init__(self, param_file):
        """
        @param model_file: 算法模型文件,joblib格式
        """
        if not os.path.exists(param_file):
            raise Exception("file not exist!")
        self.recons_param = np.load(param_file)

    def reconstruct_spec(self, images):
        #     images shape: [10, 1024, 1280]
        spectral = spectral_feature(images, cell_size=80, grid_count=7)
        cons_spec = spectral * self.recons_param

        cons_func = interp1d(target_pos, cons_spec, kind='quadratic')  # 由已知数据 (x,y) 求出插值函数 fx
        xnew = np.linspace(700.625, 920, 310)  # 指定需插值的数据点集 xnew
        cons_spec_ex = cons_func(xnew)  # 由插值函数 fSpl1 计算插值点的函数值 y1
        fake_x = np.linspace(650, 950, 310)
        return fake_x, cons_spec_ex


if __name__ == '__main__':
    data = read_unispec_sample(data_type='png', subpath='white/1/')
    print(data.shape)
    constructor = Reconstructor('model/recons/recons_param.npy')
    x, y = constructor.reconstruct_spec(data)
    plt.plot(x, y)
    plt.show()
