import os
import time

from joblib import load

from gx_spectral.feature.image import read_common_roi
from gx_spectral.feature.spectrum import calc_spectrum
from gx_spectral.utils.samples import read_unispec_sample


class GrapeSugarMspecDetector:
    def __init__(self, model_file):
        if not os.path.exists(model_file):
            raise Exception("file not exist!")
        self.model = load(model_file)

    def read_roi(self, norm_images):
        """获取陈皮年份检测样本的ROI
        输入陈皮多光谱图像，根据阈值分割提取出ROI
        @param norm_images: 标准化后的图像
        @return: 对应的ROI区域,格式为x,y,w,h,如果找不到就返回None
        """
        return read_common_roi(norm_images)

    def predict(self, roi_images):
        """葡萄甜度预测
        传入多光谱葡萄样本的ROI区域,推测其甜度，指标通过标准糖度仪标定
        @param roi_images:提取过后的ROI多光谱图像
        @return:甜度信息,如{"result": 16.5}
        """
        spectral = calc_spectrum(roi_images)
        res = self.model.detect(spectral)
        det_result = {"result": res}
        return det_result


if __name__ == '__main__':
    detector = GrapeSugarMspecDetector('../../models/putao/v0.1.1/putao.joblib')
    images = read_unispec_sample(sample='putao')
    x, y, w, h = detector.read_roi(images)
    roi_images = images[y:y + h, x:x + w, :]
    print(roi_images.shape)
    t0 = time.time()
    result = detector.detect(roi_images)
    t = time.time() - t0
    print('time:', t)
    print('result:', result)
