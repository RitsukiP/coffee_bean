# 2022/08/31更新
# 检测1、2、3、8年份陈皮
# 改用自动设置阈值的阈值分割方法，且采用倒数第二个波长的图像制作掩膜，和预处理部分保持一致
# 兼容圆形白板校准
# 结果用彩色显示
# 改进特征提取和预处理方法
# 当前模型基于环境2下数据训练
# ROI区域范围由200*200(0.5*0.5)改成了160*160(0.4*0.4)
# 支持读取中文路径

import os
import time

import cv2 as cv
import joblib
import numpy as np

# 光谱特征
from gx_spectral.feature.image import calc_texture
from gx_spectral.feature.spectrum import calc_spectrum
from gx_spectral.utils.samples import read_unispec_sample


# 多光谱陈皮年份鉴别
class ChenpiYearMspecDetector:
    def __init__(self, model_file, class_file):
        """
        @param model_file: 算法模型文件,joblib格式
        @param class_file: 类别文件
        """
        if not (os.path.exists(model_file) and os.path.exists(class_file)):
            raise Exception("file not exist!")
        self.model = joblib.load(model_file)
        with open(class_file, 'r') as f:
            self.class_name = f.readlines()
        for i in range(len(self.class_name)):
            self.class_name[i] = self.class_name[i].strip("\n")

    def read_roi(self, norm_images):
        """获取陈皮年份检测样本的ROI
        输入陈皮多光谱图像，根据阈值分割提取出ROI
        @param norm_images: 标准化后的图像
        @return: 对应的ROI区域,格式为x,y,w,h,如果找不到就返回None
        """
        img_ = norm_images[:, :, -2]
        img_ = cv.GaussianBlur(img_, (5, 5), 1)  # 高斯模糊

        # 阈值化处理
        # ret, mask = cv.threshold(img_, 50, 255, cv.THRESH_BINARY)
        mask = cv.threshold(img_, 0, 255, cv.THRESH_TRIANGLE + cv.THRESH_BINARY)[1]

        # 去除噪声和干扰
        kernel = np.ones((11, 11), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)
        kernel = np.ones((5, 5), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, kernel)

        # 检测圆形白板区域并去除，防止在用圆形白板校准时误将圆形白板检测为陈皮
        circles = cv.HoughCircles(img_, cv.HOUGH_GRADIENT, 1, 200,
                                  param1=50, param2=150, minRadius=50, maxRadius=0)
        if circles is not None and circles.shape[1] == 1:
            circles = np.uint16(np.around(circles))
            circle = circles[0][0]
            x, y, r = circle[0], circle[1], circle[2]
            x2, y2 = int(x - r / 0.8), int(y - r / 0.8)
            w2, h2 = int(r / 0.8 * 2), int(r / 0.8 * 2)
            # 去除圆形白板区域，避免轮廓检测时误将圆形白板检测为样品
            mask[y2:y2 + h2, x2:x2 + w2] = 0

        img_ = cv.cvtColor(img_, cv.COLOR_GRAY2RGB)

        # 检测目标轮廓
        contours, hierarchy = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_NONE)
        for obj in contours:
            perimeter = cv.arcLength(obj, True)  # 计算轮廓周长
            approx = cv.approxPolyDP(obj, 0.02 * perimeter, True)  # 获取轮廓角点坐标
            CornerNum = len(approx)  # 轮廓角点的数量
            x_, y_, w_, h_ = 0, 0, 0, 0
            if CornerNum != 4 and perimeter > 500:
                x, y, w, h = cv.boundingRect(obj)
                cv.rectangle(img_, (x, y), (x + w, y + h), (0, 255, 0), 5)
                center_x = int(x + 0.5 * w)
                center_y = int(y + 0.5 * h)
                if w >= 400 and h >= 400:
                    w_, h_ = 160, 160
                    x_, y_ = int(center_x - 0.5 * w_), int(center_y - 0.5 * h_)
                elif w < 400 or h < 400:
                    w_, h_ = int(0.4 * w), int(0.4 * h)
                    x_, y_ = int(center_x - 0.5 * w_), int(center_y - 0.5 * h_)
                return x_, y_, w_, h_
        return None

    def detect(self, roi_images):
        """陈皮年份预测
        传入多光谱陈皮样本的ROI区域,推测其年份
        @param roi_images:提取过后的ROI多光谱图像
        @return:年份信息,如{"result": "1year"}
        """
        spectral = calc_spectrum(roi_images)
        print('spec shape:', spectral.shape)
        dissimilarity, homogeneity, correlation, ASM = calc_texture(
            roi_images[:, :, -2], ['dissimilarity', 'homogeneity', 'correlation', 'ASM'])
        feature = np.concatenate((spectral, dissimilarity, homogeneity, correlation, ASM))
        feature = feature.reshape(1, -1)

        print('feature shape:', feature.shape)
        res = self.model.detect(feature)
        res_name = self.class_name[res[0]]
        det_result = {"result": res_name}
        return det_result


if __name__ == '__main__':
    model_path = '../../models/chenpi/v0.1.2-a/svm_model.joblib'
    class_name = '../../models/chenpi/v0.1.2-a/class_name.txt'
    detector = ChenpiYearMspecDetector(model_path, class_name)
    images = read_unispec_sample('normalization')
    x, y, w, h = detector.read_roi(images)
    roi_images = images[y:y + h, x:x + w, :]
    print(roi_images.shape)
    t0 = time.time()
    result = detector.detect(roi_images)
    t = time.time() - t0
    print('time:', t)
    print('result:', result)

    # plt.figure()
    # # plt.imshow(result, cmap='gray', vmax=255, vmin=0)
    # plt.imshow(result)
    # plt.xticks([])
    # plt.yticks([])
    # plt.show()
