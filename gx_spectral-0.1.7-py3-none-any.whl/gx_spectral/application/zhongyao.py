import os

import cv2
import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np


class detection:
    def __init__(self):
        s = 1

    def predict(self, img_dir):
        # 读取多光谱图像
        imgs = []

        filename_list = os.listdir(img_dir)
        for filename in filename_list:
            filepath = os.path.join(img_dir, filename)
            # img = cv.imread(filepath, 0)
            img = cv2.imdecode(np.fromfile(filepath, dtype=np.uint8), -1)
            imgs.append(img)

        data = np.array(imgs)
        # print("shape of images", data.shape)
        # print("data type of images", data.dtype)

        # 取第i张图像，用于阈值化处理和制作掩膜
        img_i = np.copy(data[0])
        # plt.imshow(img_i, 'gray')
        # plt.xticks(())
        # plt.yticks(())
        # plt.show()

        # 阈值化处理(轮廓分割)
        ret, mask = cv.threshold(img_i, 50, 255, cv.THRESH_BINARY)
        # plt.imshow(mask, 'gray')
        # plt.show()

        # 去除噪声和干扰（使用膨胀腐蚀）
        kernel = np.ones((11, 11), np.uint8)
        opening = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)  # 膨胀填充区域
        # plt.figure()
        # plt.imshow(opening, 'gray')
        # plt.show()

        kernel = np.ones((5, 5), np.uint8)
        closing = cv.morphologyEx(opening, cv.MORPH_CLOSE, kernel)  # 腐蚀填充区域
        # plt.figure()
        # plt.imshow(closing, 'gray')
        # plt.show()

        mask = closing
        # 通过矩形检测的方法去除白板

        mask_h, mask_w = mask.shape[0], mask.shape[1]
        sample1 = img_i.copy()
        sample2 = img_i.copy()

        # 检测矩形白板区域并去除白板
        _, contours, hierarchy = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_NONE)
        # print("轮廓数量：%d" % len(contours))

        for obj in contours:
            # area = cv2.contourArea(obj)  #计算轮廓内区域的面积
            cv.drawContours(sample1, obj, -1, (255, 0, 0), 4)  # 绘制轮廓线
            perimeter = cv.arcLength(obj, True)  # 计算轮廓周长
            approx = cv.approxPolyDP(obj, 0.02 * perimeter, True)  # 获取轮廓角点坐标
            cv.drawContours(sample2, approx, -1, (255, 0, 0), 20)  # 绘制逼近轮廓线
            CornerNum = len(approx)  # 轮廓角点的数量
            if CornerNum == 4 and perimeter > 20:
                x, y, w, h = cv.boundingRect(approx)  # 获取坐标值和宽度、高度
                #         (x, y), (w, h), angle = cv.minAreaRect(approx)
                # 将矩形区域扩展一定比例，确保将白板区域完全涵盖
                x_, y_ = int(x - 0.2 * w), int(y - 0.2 * h)
                w_, h_ = int(w * 1.4), int(h * 1.4)
                cv.rectangle(sample2, (x_, y_), (x_ + w_, y_ + h_), (0, 0, 255), 4)  # 绘制边界框
                # 去除白板区域
                x1, y1, x2, y2 = x_, y_, x_ + w_, y_ + h_
                mask[y1:y2, x1:x2] = 0
        # show results after every step
        # plt.imshow(sample1, 'gray')
        # plt.title('contours')
        # plt.xticks(()), plt.yticks(())
        # plt.show()
        # plt.imshow(sample2, 'gray')
        # plt.title('approx')
        # plt.xticks(()), plt.yticks(())
        # plt.show()
        # plt.imshow(mask, 'gray')
        # plt.title('msak')
        # plt.xticks(()), plt.yticks(())
        # plt.show()

        # spec_arr = np.array(spectrals, dtype=np.float32)  # 光谱数据
        arr = np.mean(data, axis=0)
        new_image = cv.bitwise_and(arr.astype(np.uint8), mask)  # 识别到的物体区域图像

        codi = []  # 选取出的物体像素点坐标
        pixIntense = []  # 选取出的物体像素点强度
        # 从new_image中去除需要的像素点及坐标
        for i in range(new_image.shape[0]):  # shape[0]:1024
            for j in range(new_image.shape[1]):  # shape[1]:1280
                if new_image[i, j] != 0:
                    codi.append((j, i))
                    pixIntense.append(new_image[i, j])
        # print('坐标列表', codi)
        z = zip(pixIntense, codi)
        sz = sorted(z, reverse=True)
        spixIntense, sCodi = zip(*sz)  # zip函数默认返回数据类型为元组类型
        li_spixIntense = list(spixIntense)  # 排序后的像素强度值及其坐标转换为列表保存
        li_codi = list(sCodi)
        n_codi = len(li_codi)

        # '''
        # 方法一：
        # hiPixnum为重点像素点数量，根据图像强度排序选取其中5段区域获取重点像素坐标
        # 在所有像素数量的0.001%与7之间选最小值，如果前者取整后为0，则直接取7。
        # '''
        # hiPixnum = min(int(len(li_spixIntense) * 0.00001), 7)  # 按比例选出相应数量的重点值
        # if hiPixnum == 0:
        #     hiPixnum = max(int(len(li_spixIntense) * 0.00001), 7)
        # # pixlis1-pixlis5为五个选取像素点的区间
        # pixlis1 = li_codi[0:hiPixnum]
        # pixlis2 = li_codi[int(n_codi * 0.2):int(n_codi * 0.2) + hiPixnum]
        # pixlis3 = li_codi[int(n_codi * 0.5):int(n_codi * 0.5) + hiPixnum]
        # pixlis4 = li_codi[int(n_codi * 0.7):int(n_codi * 0.7) + hiPixnum]
        # pixlis5 = li_codi[int(n_codi * 0.9):int(n_codi * 0.9) + hiPixnum]
        # overPixcoordi = pixlis1 + pixlis2 + pixlis3 + pixlis4 + pixlis5  # 选出的像素点坐标
        # overPixvalue = []  # 获取坐标对应的像素强度：注意这里的像素强度可能存在“0”
        # for i in range(len(overPixcoordi)):
        #     overPixvalue.append(new_image[overPixcoordi[i]])
        #     # print('第', i + 1, '个高亮点坐标：', li_codi[i])
        # # print('所有高亮点坐标\n', overPixcoordi, '\nTotal:', len(overPixcoordi))
        # # print('所有高亮点强度\n', overPixvalue, '\nTotal:', len(overPixvalue))
        #
        # # 用x, y分别收集前面获得的像素点的横纵坐标，并画在原图上
        # x = []
        # y = []
        # for o in overPixcoordi:
        #     x.append(o[0])
        #     y.append(o[1])
        # # plt.imshow(new_image, 'gray')
        # # plt.plot(x, y, '^', markersize=0.5, color='r')
        # # plt.show()

        ''' 
        # 生成类热度图效果
        # 方法一：对new_image进行灰度反转后利用cv直接生成热力图
        # '''
        # dst = np.zeros((new_image.shape[0], new_image.shape[1], 3), np.uint8)
        # for i in range(new_image.shape[0]):
        #     for j in range(new_image.shape[1]):
        #         dst[i, j] = 240 - new_image[i, j]
        # # 生成热力图
        # heatmap = cv.applyColorMap(dst, cv.COLORMAP_JET)
        # # plt.imshow(heatmap)
        # # plt.plot(x, y, '^', markersize=0.5, color='r')
        # # plt.colorbar()
        # # plt.show()
        ''''''

        '''
        方法二： 
        将像素强度进行“区域——点”映射后根据映射上色
        '''
        # 根据强度变化范围获取强度变化步长,选取十个强度中心点
        intense_step = int((li_spixIntense[0] - li_spixIntense[-1]) / 10)  # 这里max=239，min=67，步长为17
        center_Intense = []  # 存放十个强度中心
        for i in range(10):
            center_Intense.append(min(li_spixIntense) + intense_step * i)
        # print("强度中心：\n", center_Intense)
        centerIntense_arg = np.argsort(center_Intense)  # 十个强度中心排序后的索引range(0,10)
        # 创建一个黑色->绿色的渐变RGB色表，(0,0,0)->(0,255,0)
        colors = []
        step = int(255 / 10)
        for i in range(10):
            green = (i + 1) * step
            colors.append(green)
        # print('颜色：\n', colors)
        # 新建一个全黑的三通道RGB图像数组
        result = np.full((1024, 1280), 0, dtype=np.uint8)
        '''
        根据聚类结果上色
        将各个像素点强度映射为0~9(与centerIntense_arg强度中心对应)，作为标签
        例如将67~239中的x映射到0~10，公式为：
        0+[(9-0)/(239-67)*(x-67)]
        '''
        labels = list(range(0, 10))  # 为每个像素点创建标签
        for i in range(len(codi)):
            a = codi[i][0]
            b = codi[i][1]
            # label的计算如上公式描述
            label = int(labels[0] + ((labels[-1] - labels[0]) / (li_spixIntense[0] - li_spixIntense[-1])) * (
                    pixIntense[i] - li_spixIntense[-1]))
            arg = (np.where(centerIntense_arg == label))
            arg = arg[0][0]
            result[b][a] = colors[arg] - 120
        # 绘制结果
        return result
        # plt.figure()
        # plt.imshow(result, cmap='jet')
        # plt.colorbar()
        # # plt.plot(x, y, '^', markersize=0.8, color='r')  # 画出方法一中的重点像素（可选）
        # # plt.title("Health indicators: {:.2f}".format(h))
        # plt.show()


if __name__ == '__main__':
    aaimg_dir = r'../data/cube_20220428_215210/png'
    de = detection()
    de.predict(aaimg_dir)
