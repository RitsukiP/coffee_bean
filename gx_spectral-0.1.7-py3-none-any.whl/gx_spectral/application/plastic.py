import os

import cv2 as cv
import joblib
import matplotlib.patches as mpatches
import numpy as np
from matplotlib import pyplot as plt

# 光谱特征
from gx_spectral.feature.spectrum import calc_spectrum
from gx_spectral.utils.samples import read_unispec_sample

"""
多光谱塑料分类检测
支持abs pc  pe  pet pp  ps  pvc七种消费性塑料的分类鉴别
拍摄模式：小白板同步
样品：7类白色塑料片
"""

roi_factor = 0.7
class_num = 7
color_interval = 230 / (class_num + 1)
class_map = ['bg', 'abs', 'pc', 'pe', 'pet', 'pp', 'ps', 'pvc']

label_map = ['背景', 'abs塑料', 'pc塑料', 'pe塑料', 'pet塑料', 'pp塑料', 'ps塑料', 'pvc塑料']

plt.rcParams['font.sans-serif'] = ['Heiti TC']  # 步骤一（替换sans-serif字体）
plt.rcParams['axes.unicode_minus'] = False  # 步骤二（解决坐标轴负数的负号显示问题）
plt.rcParams['font.family'] = ['Heiti TC']  # 关键是这句

class PlasticMspecDetector:
    def __init__(self, model_file):
        """
        @param model_file: 算法模型文件,joblib格式
        """
        if not os.path.exists(model_file):
            raise Exception("file not exist!")
        self.model = joblib.load(model_file)

    def read_roi(self, norm_images):
        """获取塑料片检测样本的ROI
        输入多光谱图像，根据阈值分割提取出ROI
        @param norm_images: 标准化后的图像
        @return: 对应的ROI区域数组,格式为x,y,w,h,如果找不到就返回None
        """
        img = norm_images[:, :, 3]
        ret, mask = cv.threshold(img, 30, 255, 0)
        kernel = np.ones((11, 11), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)
        kernel = np.ones((5, 5), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, kernel)
        cv.imshow('mask', mask)
        cv.waitKey(0)
        contours, hierarchy = cv.findContours(mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        max_w = 0
        plastic_rois = []
        for cont in contours:
            approx = cv.approxPolyDP(cont, 0.01 * cv.arcLength(cont, True), True)
            if len(approx) >= 4:
                # img = cv.drawContours(img, [cont], -1, (0, 255, 0), 10)  # 标记处编号为0的轮廓，此处img为三通道才能显示轮廓
                x, y, w, h = cv.boundingRect(cont)
                mask = np.zeros_like(img)
                cv.drawContours(mask, [cont], 0, (255, 255, 255), -1)
                x, y, w, h = int(x + w * (1 - roi_factor) / 2), int(y + h * (1 - roi_factor) / 2), int(
                    w * roi_factor), int(h * roi_factor)
                plastic_rois.append((x, y, w, h, mask))
                if max_w == 0 or w > max_w:
                    max_w = w
        # 这里排除掉最大的矩形，是因为采用白板+样品同步拍摄的方式，如果没有拍白板，需要注释掉
        for i, roi in enumerate(plastic_rois):
            if roi[2] == max_w:
                plastic_rois.pop(i)
        return plastic_rois

    def detect(self, norm_images, rois):
        """塑料类别预测
        传入多光谱塑料样本的ROI区域,推测其类别
        @param roi_images:提取过后的ROI多光谱图像
        @return:类别信息,如{"result": "pc"}
        """
        features = []
        for roi in rois:
            x, y, w, h, mask = roi
            target_img = norm_images[y:y + h, x:x + w, :]
            spectral = calc_spectrum(target_img)
            features.append(spectral)
        features = np.array(features)
        res = self.model.predict(features)
        # res_name = self.class_name[res[0]]
        return res

    def draw_img(self, images, rois, result):
        res_img = np.zeros_like(images[:, :, 0])
        values = set([0])
        for roi, label in zip(rois, result):
            print(roi[:4], label)
            mask = roi[4]
            idx = class_map.index(label)
            res_img[mask > 0] = idx
            values.add(idx)
        fig = plt.figure(figsize=(5, 4), dpi=256)
        im = plt.imshow(res_img, interpolation='none')
        colors = [im.cmap(im.norm(value)) for value in values]
        # create a patch (proxy artist) for every color

        patches = [mpatches.Patch(color=colors[i], label=f"{label_map[v]}".format(l=class_map[v])) for i, v in enumerate(values)]
        # put those patched as legend-handles into the legend
        plt.legend(handles=patches, bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
        plt.axis('off')
        fig.tight_layout(pad=1)
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        buf_ndarray = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
        res_img = buf_ndarray.reshape(h, w, 3)
        res_img = cv.cvtColor(res_img, cv.COLOR_BGR2RGB)
        return res_img


if __name__ == '__main__':
    model_path = 'model/plastic/svm_model.joblib'
    detector = PlasticMspecDetector(model_path)
    # images = read_unispec_sample('normalization', 'plastic/ps1')
    images = read_unispec_sample('pretreatment', 'plastic/cub_20230208_090945')
    rois = detector.read_roi(images)
    result = detector.detect(images, rois)
    img = detector.draw_img(images, rois, result)
    cv.imshow('im', img)
    cv.imwrite('plastic_demo.png', img)
    cv.waitKey(0)
    # cv.waitKey(0)
