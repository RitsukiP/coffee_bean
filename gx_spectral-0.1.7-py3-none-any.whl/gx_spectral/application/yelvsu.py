import os
from datetime import datetime

import cv2
import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt
from joblib import dump, load
import time


class Chlorophyll:
    def __init__(self, model_path='./k_means.joblib'):
        self.kmeans = load(model_path)

    def predict(self, data_dir, down_sampling=2):
        """
        预测叶绿素分布
        :param data_dir: 多光谱图像路径（文件夹）3

        :param down_sampling: 图像下采样次数，该值越大，图像压缩越多，处理速度越快
        :return:
            h：叶片综合健康度指标
            d_map：叶绿素分布图
        """

        # 从文件中读取png/jpg等图片格式数据
        imgs = []
        filename_list = os.listdir(data_dir)
        for filename in filename_list:
            filepath = os.path.join(data_dir, filename)
            # img = cv.imread(filepath, 0)
            img = cv2.imdecode(np.fromfile(filepath, dtype=np.uint8), -1)
            for i in range(down_sampling):
                img = cv.pyrDown(img)  # 对图像进行下采样，节省计算成本
            imgs.append(img)
        # data = np.array(imgs)
        print('a1')
        data = np.array([imgs[2], imgs[4], imgs[6], imgs[8]])
        print('a2')

        # 取其中一个波段的图像，用于阈值化处理和制作掩膜
        img_ = np.copy(data[0])
        print('a3')

        # 阈值化处理
        ret, mask = cv.threshold(img_, 50, 255, cv.THRESH_BINARY)
        print('a4')

        # 去除噪声和干扰
        kernel = np.ones((11, 11), np.uint8)
        opening = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)
        kernel = np.ones((5, 5), np.uint8)
        closing = cv.morphologyEx(opening, cv.MORPH_CLOSE, kernel)
        mask = closing
        print('a5')

        # 检测矩形白板区域并去除白板
        _, contours, hierarchy = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_NONE)
        # print("轮廓数量：%d" % len(contours))
        for obj in contours:
            perimeter = cv.arcLength(obj, True)  # 计算轮廓周长
            approx = cv.approxPolyDP(obj, 0.02 * perimeter, True)  # 获取轮廓角点坐标
            CornerNum = len(approx)  # 轮廓角点的数量
            if CornerNum == 4 and perimeter > 20:
                x, y, w, h = cv.boundingRect(approx)  # 获取坐标值和宽度、高度
                #         (x, y), (w, h), angle = cv.minAreaRect(approx)
                # 将矩形区域扩展一定比例，确保将白板区域完全涵盖
                x_, y_ = int(x - 0.2 * w), int(y - 0.2 * h)
                w_, h_ = int(w * 1.4), int(h * 1.4)
                # 去除白板区域
                x1, y1, x2, y2 = x_, y_, x_ + w_, y_ + h_
                mask[y1:y2, x1:x2] = 0
        print('a6')

        # 取出叶片所在区域像素点坐标和对应像素点的光谱
        coordinates = []  # 叶片区域坐标
        spectrals = []  # 叶片区域各像素点的光谱
        print('a61')
        for a in range(mask.shape[0]):
            for b in range(mask.shape[1]):
                if mask[a, b] == 255:
                    coordinates.append((a, b))
                    spectrals.append(data[:, a, b])
        print('a62')

        spec_arr = np.array(spectrals, dtype=np.float32)
        print('a63')
        print('a64: ' + str(len(spec_arr)))
        # 利用聚类中心计算各像素点光谱的标签
        labels = self.kmeans.detect(spec_arr)
        centers = self.kmeans.cluster_centers_
        print('a7')

        # 计算叶片健康度指标
        spec_arr = np.array(spectrals, dtype=np.float32)
        h_sum = np.sum(spec_arr)
        h_mean = h_sum / len(spectrals)
        # print(h_mean)
        h = h_mean / 8

        # 生成叶绿素分布图
        value = np.sum(centers, axis=1)  # 对各聚类中心的光谱进行求和
        args = np.argsort(value)  # 获取各聚类中心光谱求和后大小排序的索引顺序
        # 创建一个灰度值渐变色表，0——>255
        colors = []
        step = int(255 / 10)
        for i in range(10):
            green = (i + 1) * step
            colors.append(green)
        print('a8')

        # 新建一个全黑的三通道RGB图像数组
        d_map = np.full(mask.shape, 0, dtype=np.uint8)

        # 根据聚类结果上色
        for i in range(len(coordinates)):
            a = coordinates[i][0]
            b = coordinates[i][1]
            label = labels[i]
            arg = np.where(args == label)
            arg = arg[0][0]
            color = colors[arg]
            d_map[a][b] = color
        print('a9')

        return h, d_map


def show_result(h, d_map):
    """
    用热度图的方式显示叶绿素分布图
    :param h: 预测得到的健康度指标
    :param d_map: 叶绿素分布图
    :return:
    """
    d_map = d_map / np.max(d_map)
    fig = plt.figure()
    plt.imshow(d_map, cmap='jet')
    plt.colorbar()
    plt.title("Health indicators: {:.2f}".format(h))
    plt.show()


def save_result(h, d_map, output_dir, save_name='result.png'):
    """
    将叶绿素分布图保存至指定文件夹
    :param h: 预测得到的健康度指标
    :param d_map: 叶绿素分布图
    :param output_dir: 分析结果保存目录
    :param save_name: 分析结果文件名称（默认为 'result.png'）
    :return:
    """
    print(str(datetime.now()) + 'a1')
    save_path = os.path.join(output_dir, save_name)
    print(str(datetime.now()) + 'a2')
    d_map = d_map / np.max(d_map)
    print(str(datetime.now()) + 'a3')
    fig = plt.figure()
    print(str(datetime.now()) + 'a4')
    plt.imshow(d_map, cmap='jet')
    print(str(datetime.now()) + 'a5')
    plt.colorbar()
    print(str(datetime.now()) + 'a6')
    plt.title("Health indicators: {:.2f}".format(h))
    print(str(datetime.now()) + 'a7')
    # s1 = '硫含量合格'
    # s2 = '农药残留合格'
    # s3 = '重金属残留合格'
    # plt.annotate(s=s1, xy=(0, 0), xytext=(0, 0))
    # plt.annotate(s=s2, xy=(0, 20), xytext=(0, 20))
    # plt.annotate(s=s3, xy=(0, 40), xytext=(0, 40))
    fig.savefig(save_path)
    print(str(datetime.now()) + 'a8')


if __name__ == '__main__':
    model_path = '../modal/k_means.joblib'
    img_dir = r'E:\image\cube_20220607_151438\registration'
    output_dir = r'E:\image\cube_20220607_151438\chlorophyll'

    chlorophyll = Chlorophyll(model_path)
    t0 = time.time()
    h, d_map = chlorophyll.predict(data_dir=img_dir, down_sampling=2)
    save_result(h, d_map, output_dir)
    t = time.time() - t0
    print('t:{:.2f}s'.format(t))

