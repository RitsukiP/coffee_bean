import os

import cv2 as cv
import joblib
import matplotlib.patches as mpatches
import numpy as np
from matplotlib import pyplot as plt
from sklearn import preprocessing
import matplotlib as mpl

# 光谱特征
from gx_spectral.feature.spectrum import calc_spectrum
from gx_spectral.utils.samples import read_unispec_sample
import spectral

"""
多光谱橡胶分类检测
支持质监局给的4类天然橡胶以及1类人造橡胶的分类鉴别
拍摄模式：大白板分步
样品：5类橡胶
"""

class_num = 5
color_interval = 230 / (class_num + 1)
# class_map = ['背景', '天然橡胶', '天然橡胶', '天然橡胶', '合成橡胶', '合成橡胶']
class_map = ['背景', '天然1', '天然2', '天然3', '天然4', '合成5']
cmaps = plt.get_cmap()(np.linspace(0, 1, len(class_map)))



class RubberMspecDetector:
    def __init__(self, model_file, pca_file=None):
        """
        @param model_file: 算法模型文件,joblib格式
        """
        if not os.path.exists(model_file):
            raise Exception("file not exist!")
        self.model = joblib.load(model_file)
        if pca_file is not None:
            self.pca = joblib.load(pca_file)

    def read_roi(self, norm_images):
        """获取塑料片检测样本的ROI
        输入多光谱图像，根据阈值分割提取出ROI
        @param norm_images: 标准化后的图像
        @return: 对应的ROI区域数组,格式为x,y,w,h,如果找不到就返回None
        """
        img = norm_images[:, :, 3]
        img = (img / 4).astype(np.uint8)
        ret, mask = cv.threshold(img, 50, 255, 0)
        kernel = np.ones((11, 11), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)
        kernel = np.ones((5, 5), np.uint8)
        mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, kernel)
        contours, hierarchy = cv.findContours(mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        target_rois = []
        for cont in contours:
            length = cv.arcLength(cont, True)
            if length < 200:
                continue
            approx = cv.approxPolyDP(cont, 0.01 * length, True)
            mask = np.zeros_like(mask)
            x, y, w, h = cv.boundingRect(cont)
            # x = int(x+w/2-100)
            # y = int(y+h/2-100)
            # mask[y:y+100, x:x+100] = 255
            cv.drawContours(mask, [cont], 0, (255, 255, 255), -1)
            # cv.imshow('img_mask', mask)
            # cv.waitKey(0)
            target_rois.append(mask.astype(bool))

        return target_rois

    def detect(self, norm_images, rois):
        """橡胶类别预测
        传入多光谱橡胶样本的ROI区域,推测其类别
        @param roi_images:提取过后的ROI多光谱图像
        @return:类别信息,如{"result": "pc"}
        """
        features = []
        result = []
        for roi in rois:
            specs = []
            global angle_masks
            for i in range(6):
                spec = []
                for k in range(norm_images.shape[2]):
                    reflec = np.squeeze(norm_images[:, :, k])
                    target = (reflec * roi)[angle_masks[i]]
                    if len(target[target>0]) == 0:
                        print('-=！！！！！！！！ zero zero ！！！！！！！！--')
                        spec = None
                        break
                    spec.append(target[target > 0].mean())
                if spec is not None:
                    specs.append(spec)


            # for i in range(norm_images.shape[2]):
            #     target = np.squeeze(norm_images[:, :, i])
            #     target_spec = target[roi * center_mask]
            #     specs.append(target_spec[target_spec>0].mean())
            # cv.imshow('target', target * roi * center_mask)
            # cv.imwrite('demo2.png', img)
            # cv.imwrite('im.png', b)
            # cv.waitKey(0)
            print(len(specs))
            res = self.model.predict(specs)
            print(res)
            from collections import Counter
            value = Counter(res).most_common()[0][0]
            print(value)
            result.append(value)

            # features.append(specs)
        features = np.array(features)
        # print('========= pca process ==============')
        # print(features.shape)
        # features = self.pca.transform(features)
        # features = scaler.transform(features)
        # print(features.shape)
        # res = self.model.predict(features)
        return result

    def draw_img(self, images, rois, result):
        res_img = np.zeros_like(images[:, :, 0])
        values = [0]
        print(result)
        for roi, label in zip(rois, result):
            # idx = class_map.index(label)
            idx = int(label)
            # idx = 200 if idx == '5' else 30 + int(idx) * 15
            res_img[roi > 0] = idx
            values.append(idx)
        plt.rcParams['font.sans-serif'] = ['Heiti TC']  # 步骤一（替换sans-serif字体）
        plt.rcParams['axes.unicode_minus'] = False  # 步骤二（解决坐标轴负数的负号显示问题）
        plt.rcParams['font.family'] = ['Heiti TC']  # 关键是这句
        fig = plt.figure(figsize=(5, 4), dpi=256)
        im = plt.imshow(res_img, interpolation='none')
        # colors = [im.cmap(im.norm(int(value))) for value in range(len(class_map))]
        # create a patch (proxy artist) for every color
        patches = [mpatches.Patch(color=cmaps[v], label="{l}".format(l=class_map[v])) for i, v in enumerate(values)]
        # put those patched as legend-handles into the legend
        plt.legend(handles=patches, bbox_to_anchor=(1.05, 1), loc='best', borderaxespad=0.)
        plt.axis('off')
        plt.title('橡胶检测')
        fig.tight_layout(pad=1)
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        buf_ndarray = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
        res_img = buf_ndarray.reshape(h, w, 3)
        res_img = cv.cvtColor(res_img, cv.COLOR_BGR2RGB)
        return res_img


def demo2(images, rois, result):
    res_img = np.zeros_like(images[:, :, 0])
    for roi, label in zip(rois, result):
        tt = images[:, :, 0] * 255
        tt = (tt.clip(180) + 20).clip(0, 255) if label == '5' else tt.clip(180, 200) - 20
        res_img += roi * tt

    res_img = cv.applyColorMap(res_img.astype(np.uint8), cv.COLORMAP_JET);
    res_img = cv.cvtColor(res_img, cv.COLOR_BGR2RGB)
    # plt.colorbar()
    fig = plt.figure(figsize=(5, 4), dpi=256)
    im = plt.imshow(res_img, interpolation='none')
    plt.title('橡胶检测')
    data = np.random.randint(0, 2, size=(2, 2))
    h = plt.contourf(data)
    # ax = plt.axes()
    cmap = plt.get_cmap('jet')
    colors = [[255, 252, 0], [141, 0, 0], [1, 0, 134]]
    colors = np.divide(colors, 255)
    values = ['天然橡胶', '合成橡胶', '背景']
    # create a patch (proxy artist) for every color
    # put those patched as legend-handles into the legend
    plt.rcParams['font.sans-serif'] = ['Heiti TC']  # 步骤一（替换sans-serif字体）
    plt.rcParams['axes.unicode_minus'] = False  # 步骤二（解决坐标轴负数的负号显示问题）
    plt.rcParams['font.family'] = ['Heiti TC']  # 关键是这句
    import matplotlib.font_manager as fm

    for font in fm.fontManager.ttflist:
        print(font.name)
    patches = [mpatches.Patch(color=colors[i], label="{l}".format(l=v)) for i, v in enumerate(values)]
    plt.legend(handles=patches, bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    plt.xticks([])
    plt.yticks([])
    # plt.axis('off')
    fig.tight_layout(pad=1)
    fig.canvas.draw()
    w, h = fig.canvas.get_width_height()
    buf_ndarray = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    res_img = buf_ndarray.reshape(h, w, 3)
    res_img = cv.cvtColor(res_img, cv.COLOR_BGR2RGB)
    cv.imwrite('demoo.png', res_img)
    # norm = mpl.colors.BoundaryNorm([0, 3, 4, 'ss'], cmap.N)

    # plt.colorbar(mpl.cm.ScalarMappable(cmap=cmap, norm=norm))
    # plt.savefig('demo3.png')
    plt.show()
    return res_img

def generate_angle_mask(img_size=(1024,1280),n=6, r=50):
#     生成角度掩膜
    angle_masks = []
    center=int(img_size[1]/2),int(img_size[0]/2)
    for i in range(n):
        mask = np.zeros(img_size)
        cv.circle(mask,center = center,radius = (i+1)*r,color = (255,255, 255),thickness = -1)
        cv.circle(mask,center = center,radius = i*r,color = (0,0,0),thickness = -1)
        angle_masks.append(mask.astype(bool))
    return angle_masks
angle_masks = generate_angle_mask()

center_mask = np.zeros([1024, 1280])
# center_mask[384:640, 480:800] = 200
center_mask[256:768, 320:960] = 200

center_mask = center_mask.astype(bool)

pca_path = 'model/rubber/small/pca.joblib'
# model_path = 'model/rubber/small/rubber_pca.joblib'
model_path = 'model/rubber/big/rubber_pl_circle.joblib'
scaler = joblib.load('model/rubber/small/scaler.joblib')
detector = RubberMspecDetector(model_path)

if __name__ == '__main__':
    # model_path = 'model/rubber/rubber2.joblib'
    # images = read_unispec_sample('normalization', 'rubber/sample1')
    import glob

    # files = glob.glob(f'/Users/gordon/data/橡胶/20230331/*/*.hdr')
    files = glob.glob(f'/Users/gordon/data/橡胶/20230406/mix/*/*.hdr')
    # files = glob.glob(f'/Users/gordon/data/橡胶/20230329/5/*/*.hdr')
    # white_f = '/Users/gordon/data/橡胶/20230329/0/cube_20230329_172616/cube_20230329_172616.hdr'
    white_f = '/Users/gordon/data/橡胶/20230406/0/ref_20230316_172500/ref_20230316_172500.hdr'
    white_ref = spectral.open_image(white_f).load_dataset()
    for f in files:
        # f = '/Users/gordon/data/橡胶/20230331/2135_20230331_201610/2135_20230331_201610.hdr'
        images = spectral.open_image(f).load_dataset()
        rois = detector.read_roi(images)

        print(f.split('/')[-2][:5])
        # images /= white_ref[462:562, 590:690].mean()
        images /= white_ref
        result = detector.detect(images, rois)
        # result = ['2', '1', '3', '5']
        img = detector.draw_img(images, rois, result)
        # img = demo2(images, rois, result)

        cv.imshow('im', img)
        # cv.imwrite('demo2.png', img)
        # cv.imwrite('im.png', b)
        cv.waitKey(0)
        # break
    # cv.waitKey(0)
